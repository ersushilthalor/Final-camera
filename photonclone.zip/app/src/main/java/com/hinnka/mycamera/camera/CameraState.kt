package com.hinnka.mycamera.camera

import android.graphics.Rect
import android.util.Range
import android.util.Size
import com.hinnka.mycamera.processor.MgcRawMaxMode
import com.hinnka.mycamera.raw.RawCfaCorrection
import com.hinnka.mycamera.raw.RawMetadata
import com.hinnka.mycamera.video.CaptureMode
import com.hinnka.mycamera.video.VideoCapabilities
import com.hinnka.mycamera.video.VideoConfig
import com.hinnka.mycamera.video.VideoRecordingState
import kotlin.math.abs

object NoiseReductionLevel {
    const val OFF = 0
    const val FAST = 1
    const val HIGH_QUALITY = 2
    const val ZERO_SHUTTER_LAG = 3
    const val MINIMAL = 4
    const val DEFAULT = HIGH_QUALITY

    fun normalize(level: Int): Int = when (level) {
        OFF, FAST, HIGH_QUALITY, ZERO_SHUTTER_LAG, MINIMAL -> level
        else -> DEFAULT
    }
}

/**
 * 画面比例。内置比例使用稳定名称持久化，自定义比例使用 CUSTOM_宽_高。
 */
class AspectRatio private constructor(
    val name: String,
    val widthRatio: Int,
    val heightRatio: Int
) {
    override fun equals(other: Any?): Boolean {
        return other is AspectRatio && name == other.name
    }

    override fun hashCode(): Int {
        return name.hashCode()
    }

    override fun toString(): String {
        return name
    }


    fun getValue(isLandscape: Boolean): Float {
        return if (isLandscape) {
            widthRatio.toFloat() / heightRatio
        } else {
            heightRatio.toFloat() / widthRatio
        }
    }

    fun getDisplayName(): String {
        if (this == XPAN) {
            return "XPAN"
        }
        return "$widthRatio:$heightRatio"
    }

    companion object {
        const val TOP_SHEET_MAX_COUNT = 5
        private const val CUSTOM_PREFIX = "CUSTOM_"

        val RATIO_3_2 = AspectRatio("RATIO_3_2", 3, 2)
        val RATIO_4_3 = AspectRatio("RATIO_4_3", 4, 3)
        val RATIO_16_9 = AspectRatio("RATIO_16_9", 16, 9)
        val RATIO_1_1 = AspectRatio("RATIO_1_1", 1, 1)
        val RATIO_21_9 = AspectRatio("RATIO_21_9", 21, 9)
        val XPAN = AspectRatio("XPAN", 65, 24)

        val entries: List<AspectRatio> = listOf(
            RATIO_3_2,
            RATIO_4_3,
            RATIO_16_9,
            RATIO_1_1,
            RATIO_21_9,
            XPAN
        )

        val defaultTopSheetRatios: List<AspectRatio> = listOf(
            RATIO_3_2,
            RATIO_4_3,
            RATIO_16_9,
            RATIO_1_1,
            XPAN
        )

        fun fromString(string: String): AspectRatio {
            return valueOfOrNull(string) ?: entries.firstOrNull { it.getDisplayName() == string } ?: RATIO_4_3
        }

        fun valueOf(name: String): AspectRatio {
            return valueOfOrNull(name) ?: throw IllegalArgumentException("Unknown AspectRatio: $name")
        }

        fun valueOfOrNull(name: String): AspectRatio? {
            entries.firstOrNull { it.name == name }?.let { return it }
            if (!name.startsWith(CUSTOM_PREFIX)) return null
            val parts = name.removePrefix(CUSTOM_PREFIX).split("_")
            if (parts.size != 2) return null
            val width = parts[0].toIntOrNull() ?: return null
            val height = parts[1].toIntOrNull() ?: return null
            return custom(width, height)
        }

        fun custom(widthRatio: Int, heightRatio: Int): AspectRatio {
            val width = widthRatio.coerceIn(1, 999)
            val height = heightRatio.coerceIn(1, 999)
            val divisor = gcd(width, height)
            val normalizedWidth = width / divisor
            val normalizedHeight = height / divisor
            entries.firstOrNull {
                it.widthRatio == normalizedWidth && it.heightRatio == normalizedHeight
            }?.let { return it }
            return AspectRatio(
                name = "${CUSTOM_PREFIX}${normalizedWidth}_${normalizedHeight}",
                widthRatio = normalizedWidth,
                heightRatio = normalizedHeight
            )
        }

        fun sanitizeTopSheetRatios(ratios: List<AspectRatio>): List<AspectRatio> {
            val sanitized = ratios
                .distinct()
                .take(TOP_SHEET_MAX_COUNT)
            return sanitized.ifEmpty { defaultTopSheetRatios }
        }

        fun sanitizeCustomRatios(ratios: List<AspectRatio>): List<AspectRatio> {
            return ratios
                .map { custom(it.widthRatio, it.heightRatio) }
                .filter { ratio -> entries.none { it.name == ratio.name } }
                .distinctBy { it.name }
        }

        private tailrec fun gcd(a: Int, b: Int): Int {
            return if (b == 0) kotlin.math.abs(a) else gcd(b, a % b)
        }
    }
}

/**
 * 相机镜头类型
 */
enum class LensType {
    FRONT,
    BACK_MAIN,
    BACK_ULTRA_WIDE,
    BACK_TELEPHOTO,
    BACK_MACRO
}

/**
 * 测光模式
 */
enum class MeteringMode {
    SYSTEM_DEFAULT,    // 系统默认 - 不设置 AE 测光区域
    CENTER_WEIGHTED,   // 中央重点 - 中等区域，中心加权
    SPOT,              // 点测光 - 对焦点附近小区域
    AVERAGE,           // 平均测光 - 全画面均匀
    HIGHLIGHT_PRIORITY; // 高光优先 - 亮部加权，防止过曝
}

/**
 * 相机信息数据类
 */
data class CameraInfo(
    val cameraId: String,
    val logicalCameraId: String? = null,
    val outputPhysicalCameraId: String? = null,
    val physicalCameras: List<CameraPhysicalInfo> = emptyList(),
    val lensFacing: Int,
    val lensType: LensType,
    val physicalCameraIds: List<String>,
    val isoRange: Range<Int>?,
    val exposureTimeRange: Range<Long>?,
    val exposureCompensationRange: Range<Int>,
    val exposureCompensationStep: Float,
    val maxZoom: Float,
    val minZoom: Float = 1f,  // 最小变焦（广角时 < 1.0）
    val sensorOrientation: Int,
    val activeArraySize: Rect?,
    val focalLength: Float = 0f,  // 物理焦距 (mm)
    val focalLength35mmEquivalent: Float = 0f,  // 35mm等效焦距
    val zoomSteps: List<Float> = listOf(1f),  // 可用的变焦档位 (如 [0.5, 1.0, 2.0])
    val intrinsicZoomRatio: Float = 1f,  // 固有变焦比例 (CameraX 1.3.0+)
    val displayIntrinsicZoomRatio: Float = intrinsicZoomRatio, // 用户可见固有倍率，ISZ 虚拟镜头会高于底层提交倍率
    val hardwareLevel: Int = -1,  // 硬件支持级别
    val supportsManualProcessing: Boolean = false, // 是否支持手动处理（关闭系统锐化/降噪）
    val supportsRaw: Boolean = false, // 是否支持 RAW 格式
    val isCustomLensId: Boolean = false, // 是否来自用户手动添加的镜头 ID
    val isVirtualIszLens: Boolean = false, // 是否为用户创建的 ISZ 虚拟镜头
    val isVirtualIszMacroLens: Boolean = false, // ISZ 虚拟镜头是否强制识别为微距
    val baseCameraId: String? = null, // 虚拟镜头对应的真实物理镜头 ID
    val iszZoomRatio: Float = 1f, // ISZ 虚拟倍率
    val rawBlackBorderCrop: RawBlackBorderCrop = RawBlackBorderCrop(), // RAW 原始分辨率黑边裁切像素
    val minimumFocusDistance: Float = 0f // 最小对焦距离 (diopters, 0 = infinity only)
) {
    fun getOpenCameraId(): String {
        if (!isVirtualIszLens) return logicalCameraId ?: cameraId
        return requireNotNull(logicalCameraId ?: baseCameraId) {
            "ISZ virtual lens $cameraId has no Camera2 device ID"
        }
    }

    fun getBoundPhysicalCameraId(): String? = outputPhysicalCameraId

    fun getBoundPhysicalCameraId(zoomRatioByMain: Float): String? {
        if (physicalCameras.isEmpty()) return outputPhysicalCameraId
        return physicalCameras.minByOrNull {
            abs(it.intrinsicZoomRatio - zoomRatioByMain)
        }?.cameraId ?: outputPhysicalCameraId
    }

    /**
     * 获取镜头类型显示名称
     */
    fun getLensDisplayName(): String {
        val name = when (lensType) {
            LensType.FRONT -> "前置"
            LensType.BACK_MAIN -> "主摄 (1x)"
            LensType.BACK_ULTRA_WIDE -> "广角 (0.5x)"
            LensType.BACK_TELEPHOTO -> "长焦 (${String.format("%.1f", focalLength35mmEquivalent / 24f)}x)"
            LensType.BACK_MACRO -> "微距"
        }
        return if (isCustomLensId) "$name *" else name
    }

    /**
     * 是否支持广角（minZoom < 1）
     */
    fun hasWideAngle(): Boolean = minZoom < 0.9f

    /**
     * 是否支持长焦（maxZoom > 2）
     */
    fun hasTelephoto(): Boolean = maxZoom > 2f

    /**
     * 获取硬件支持级别的可读名称
     */
    fun getHardwareLevelName(): String {
        return when (hardwareLevel) {
            0 -> "LIMITED"
            1 -> "FULL"
            2 -> "LEGACY"
            3 -> "LEVEL_3"
            4 -> "EXTERNAL"
            else -> "UNKNOWN"
        }
    }
}

data class CameraPhysicalInfo(
    val cameraId: String,
    val intrinsicZoomRatio: Float,
    val focalLength35mmEquivalent: Float = 0f,
    val focalLength: Float = 0f
)

enum class FocusPointSource {
    MANUAL,
    EYE,
}

data class WhiteBalanceGains(
    val red: Float,
    val greenEven: Float,
    val greenOdd: Float,
    val blue: Float
)

/**
 * 相机状态数据类
 */
data class CameraState(
    // 当前相机
    val currentCameraId: String = "",
    val currentLensType: LensType = LensType.BACK_MAIN,
    val availableCameras: List<CameraInfo> = emptyList(),
    val currentPreviewSize: Size = Size(1440, 1080),
    val currentCaptureSize: Size = Size(1440, 1080),

    // 曝光控制
    val exposureCompensation: Int = 0,
    val isIsoAuto: Boolean = true,
    val isShutterSpeedAuto: Boolean = true,
    val iso: Int = 100,
    val shutterSpeed: Long = 1_000_000_000L / 60, // 1/60s in nanoseconds
    val exposureBias: Float = 0f,

    val awbMode: Int = 1, // 自动白平衡模式
    val awbTemperature: Int = 5000, // 色温 (K)
    val actualAwbTemperature: Int? = null, // 相机当前实际/估算色温 (K)
    val actualAwbTint: Int? = null,
    val actualAwbGains: WhiteBalanceGains? = null,
    val canAdjustWhiteBalance: Boolean = false,
    val supportsCctWhiteBalance: Boolean = false,
    val awbTemperatureMin: Int = 2000,
    val awbTemperatureMax: Int = 8000,

    // 测光模式
    val meteringMode: MeteringMode = MeteringMode.SYSTEM_DEFAULT,

    val isVirtualApertureEnabled: Boolean = false,
    val physicalAperture: Float = 2.0f, // 物理光圈值
    val virtualAperture: Float = 2.0f,  // 虚拟光圈值 (f-number)
    // 对焦
    val isAutoFocus: Boolean = true,
    val focusDistance: Float = 0f, // 自动对焦时为镜头回报值，手动对焦时为用户目标值（屈光度）
    val isHyperfocalFocusEnabled: Boolean = false,
    val hyperfocalDistanceMeters: Float = 0f,
    val minimumFocusDistance: Float = 0f, // 最小对焦距离
    val supportsPointAutoFocus: Boolean = false,
    val focusPoint: Pair<Float, Float>? = null, // normalized coordinates (0-1)
    // 非空表示用户拖出了独立测光点；为空时测光遵循所选模式和对焦点。
    val meteringPoint: Pair<Float, Float>? = null,
    val supportsPointMetering: Boolean = false,
    val focusPointSource: FocusPointSource = FocusPointSource.MANUAL,
    val isFocusLocked: Boolean = false,
    val isFocusing: Boolean = false,
    val focusSuccess: Boolean? = null,
    val currentAfMode: Int? = null, // 当前的 AF 模式

    //闪光灯
    val flashMode: Int = 0, // 0: off, 1: forced flash, 2: torch

    // 变焦
    val zoomRatio: Float = 1.0f,

    // 画面比例
    val aspectRatio: AspectRatio = AspectRatio.RATIO_4_3,

    // 设备方向
    val deviceRotation: Int = 0, // 0, 90, 180, 270

    // 是否处于预览状态
    val isPreviewActive: Boolean = false,
    // 当前预览会话首个 CaptureResult 的传感器时间戳，用于等待对应画面真正渲染。
    val previewFirstFrameTimestampNs: Long? = null,

    // 是否正在拍照
    val isCapturing: Boolean = false,
    val photoCaptureProgress: PhotoCaptureProgress? = null,

    // LUT 设置
    val currentLutName: String? = null,
    val lutEnabled: Boolean = false,
    val isLogLutActive: Boolean = false,
    val availableLuts: List<String> = emptyList(),

    // 直方图数据 (256个灰度值)
    val histogram: IntArray? = null,

    // 延时拍摄
    val timerSeconds: Int = 0, // 延时拍摄秒数 (0/3/5/10)
    val countdownValue: Int = 0, // 当前倒计时值

    // 网格线
    val showGrid: Boolean = false, // 是否显示网格线
    val gridStyle: GridStyle = GridStyle.THIRDS,

    // 降噪等级 (0=Off, 1=Fast, 2=High Quality, 3=ZSL, 4=Minimal)
    val nrLevel: Int = NoiseReductionLevel.OFF,
    val availableNrModes: IntArray = intArrayOf(),
    val vendorCaptureSettingsByLens: VendorCaptureSettingsByLens = VendorCaptureSettingsByLens.Empty,
    val customVendorKeySettings: CustomVendorKeySettings = CustomVendorKeySettings.Empty,

    val isRawSupported: Boolean = false,
    val rawCfaCorrectionModes: Map<String, String> = emptyMap(),
    val multiFrameOutputScale: Float? = null,
    val jpgMultiFrameDenoiseFrameCount: Int = MultiFrameConfig.DEFAULT_DENOISE_FRAME_COUNT,
    val hdrPlusFrameCount: Int = MultiFrameConfig.DEFAULT_HDR_PLUS_FRAME_COUNT,
    val hdrPlusMergeMode: MgcRawMaxMode = MgcRawMaxMode.DEFAULT,
    val useJpgMaxHdrComposition: Boolean = false,
    val hdrPlusBracketExposureEnabled: Boolean = MultiFrameConfig.DEFAULT_HDR_PLUS_BRACKET_EXPOSURE,
    val hdrPlusLongFrameExposureEv: Float = MultiFrameConfig.LONG_FRAME_EXPOSURE_EV.toFloat(),
    val hdrPlusShortFrameExposureEv: Float = MultiFrameConfig.DEFAULT_SHORT_FRAME_EXPOSURE_EV,
    val useRaw: Boolean = false,
    val useMultipleExposure: Boolean = false,
    val rawMinShutterSpeedNs: Long = 0L,
    val useLivePhoto: Boolean = false,
    val droMode: String = "OFF",
    // 是否正在拍摄 Live Photo (用于 UI 动画)
    val isCapturingLivePhoto: Boolean = false,
    val applyUltraHDR: Boolean = true,
    val useP010: Boolean = false,
    val useP3ColorSpace: Boolean = false,
    val isP010Supported: Boolean = false,
    val burstCapturing: Boolean = false,
    val hdrBracketCapturing: Boolean = false,
    val hdrBracketFrameCount: Int = 0,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val isP3Supported: Boolean = false,
    val captureMode: CaptureMode = CaptureMode.PHOTO,
    val photoPreviewStabilizationEnabled: Boolean = false,
    val videoConfig: VideoConfig = VideoConfig(),
    val videoCapabilities: VideoCapabilities = VideoCapabilities(),
    val videoRecordingState: VideoRecordingState = VideoRecordingState(),
) {
    val effectiveMeteringMode: MeteringMode
        get() = if (meteringPoint != null) MeteringMode.SPOT else meteringMode

    val meteringReferencePoint: Pair<Float, Float>?
        get() = meteringPoint ?: focusPoint?.takeIf { focusPointSource == FocusPointSource.MANUAL }

    companion object {
        const val MAX_PHOTO_PREVIEW_SHUTTER_SPEED_NS = 1_000_000_000L / 15
        const val MAX_VIDEO_MANUAL_SHUTTER_SPEED_NS = 1_000_000_000L / 6
    }

    /**
     * 是否全自动曝光
     */
    val isAutoExposure: Boolean
        get() = isIsoAuto && isShutterSpeedAuto

    val isMultiFrameEnabled: Boolean
        get() = multiFrameOutputScale != null &&
            (!useRaw || (isRawSupported && isRawMultiFrameSupported && normalizedHdrPlusFrameCount > 1))

    // A single RAW frame uses the ordinary capture and development path.
    // Resolve the configured count without depending on the multi-frame enablement above.
    private val normalizedHdrPlusFrameCount: Int
        get() = MultiFrameConfig.normalizeHdrPlusFrameCount(
            hdrPlusFrameCount,
            bracketExposureEnabled = hdrPlusMergeMode.supportsBracketExposure &&
                hdrPlusBracketExposureEnabled,
        )

    // The RAW stacker only supports the standard 2x2 Bayer lattice. Resolve this
    // from the current lens so lens switches retain the user's multi-frame settings.
    val isRawMultiFrameSupported: Boolean
        get() = RawCfaCorrection.patternFromMode(rawCfaCorrectionModes[currentCameraId])
            ?.let { !RawMetadata.isQuadBayer(it) } ?: true

    /** Whether capture itself needs a Camera2 multi-request sequence. */
    val requiresMultiFrameCaptureSequence: Boolean
        get() = isMultiFrameEnabled && activeMultiFrameCount > 1

    val isJpgMaxEnabled: Boolean
        get() = isMultiFrameEnabled && !useRaw

    val isJpgMaxHdrEnabled: Boolean
        get() = isJpgMaxEnabled && useJpgMaxHdrComposition

    val isRawMaxEnabled: Boolean
        get() = isMultiFrameEnabled && useRaw

    val isHdrPlusBracketExposureEnabled: Boolean
        get() = isRawMaxEnabled && hdrPlusMergeMode.supportsBracketExposure &&
            hdrPlusBracketExposureEnabled

    val activeMultiFrameCount: Int
        get() = when {
            isJpgMaxEnabled -> MultiFrameConfig.normalizeDenoiseFrameCount(
                jpgMultiFrameDenoiseFrameCount
            )
            isRawMaxEnabled -> normalizedHdrPlusFrameCount
            else -> 1
        }

    /**
     * 获取当前相机信息
     */
    fun getCurrentCameraInfo(): CameraInfo? {
        return availableCameras.find { it.cameraId == currentCameraId }
    }

    /**
     * 获取曝光补偿范围
     */
    fun getExposureCompensationRange(): Range<Int> {
        return getCurrentCameraInfo()?.exposureCompensationRange ?: Range(0, 0)
    }

    fun getExposureCompensationStep(): Float {
        return getCurrentCameraInfo()?.exposureCompensationStep ?: 0.333f
    }

    /**
     * 获取 ISO 范围
     */
    fun getIsoRange(): Range<Int> {
        return getCurrentCameraInfo()?.isoRange ?: Range(100, 3200)
    }

    /**
     * 获取快门速度范围
     */
    fun getShutterSpeedRange(): Range<Long> {
        return getCurrentCameraInfo()?.exposureTimeRange ?: Range(1_000_000L, 1_000_000_000L)
    }

    fun getManualShutterSpeedRange(): Range<Long> {
        val sensorRange = getShutterSpeedRange()
        val upper = when (captureMode) {
            CaptureMode.VIDEO -> sensorRange.upper.coerceAtMost(MAX_VIDEO_MANUAL_SHUTTER_SPEED_NS)
            CaptureMode.PHOTO -> sensorRange.upper
        }.coerceAtLeast(sensorRange.lower)
        return Range(sensorRange.lower, upper)
    }

    fun getPreviewExposureTimeLimitNs(): Long {
        return when (captureMode) {
            CaptureMode.VIDEO -> MAX_VIDEO_MANUAL_SHUTTER_SPEED_NS
            CaptureMode.PHOTO -> MAX_PHOTO_PREVIEW_SHUTTER_SPEED_NS
        }
    }

    fun isPreviewExposureLimited(): Boolean {
        return shutterSpeed >= getPreviewExposureTimeLimitNs()
    }

    /**
     * 获取最大变焦倍数
     */
    fun getMaxZoom(): Float {
        return getCurrentCameraInfo()?.maxZoom ?: 1.0f
    }

    /**
     * 获取最小变焦倍数
     */
    fun getMinZoom(): Float {
        return getCurrentCameraInfo()?.minZoom ?: 1.0f
    }

    /**
     * 获取可用的变焦档位
     */
    fun getZoomSteps(): List<Float> {
        return getCurrentCameraInfo()?.zoomSteps ?: listOf(1f)
    }

    fun getAvgLuma(): Float {
        val histogram = histogram ?: return 0.18f
        var totalCount = 0L
        var weightedSum = 0L
        for (i in histogram.indices) {
            val count = histogram[i].toLong()
            weightedSum += i * count
            totalCount += count
        }
        if (totalCount == 0L) return 0.18f
        return (weightedSum.toFloat() / totalCount) / 255f
    }

    fun getPreviewAspectRatio(): Float {
        return when (captureMode) {
            CaptureMode.PHOTO -> aspectRatio.getValue(isLandscape = false)
            CaptureMode.VIDEO -> videoConfig.aspectRatio.getPortraitAspectRatio(
                videoCapabilities.openGatePortraitAspectRatio
            )
        }
    }
}
