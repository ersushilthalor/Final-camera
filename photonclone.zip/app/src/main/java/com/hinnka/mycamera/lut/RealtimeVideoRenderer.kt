package com.hinnka.mycamera.lut

import android.content.Context
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.opengl.Matrix
import android.util.Size
import android.view.Surface
import com.hinnka.mycamera.model.ColorRecipeParams
import com.hinnka.mycamera.stabilization.DEFAULT_VIDEO_STABILIZATION_LOOKAHEAD
import com.hinnka.mycamera.stabilization.RealtimeStabilizationCoordinator
import com.hinnka.mycamera.stabilization.StabilizationUseCase
import com.hinnka.mycamera.utils.PLog
import com.hinnka.mycamera.video.VideoEncoderColorConfig
import com.hinnka.mycamera.video.VideoEncodedColorPipeline
import com.hinnka.mycamera.video.VideoLogProfile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max

/**
 * Camera2 录像专用实时渲染器。
 *
 * 普通录像从独立 [SurfaceTexture] 取 OES 帧；MGC 防抖录像改取与 CaptureResult 精确
 * 对时的共享 YUV 图像。两条路径最终都在专用 EGL context 中写入 MediaCodec surface，
 * 因而录像帧率不受 GLSurfaceView 调度影响。
 */
class RealtimeVideoRenderer(
    context: Context,
    private val cameraInputSize: Size,
    private val encoderOutputSize: Size,
    private val sensorOrientationDegrees: Int,
    colorLayers: List<VideoColorEffectLayer>,
    private val videoLogProfile: VideoLogProfile,
    private val mirrorHorizontally: Boolean,
    private val mirrorVertically: Boolean,
    private val encoderColorConfig: VideoEncoderColorConfig,
    private val stabilizationCoordinator: RealtimeStabilizationCoordinator?,
    private val enhancedStabilizationEnabled: Boolean,
    private val enhancedStabilizationStrength: Float,
    private val enhancedStabilizationLookahead: Int = DEFAULT_VIDEO_STABILIZATION_LOOKAHEAD,
    cameraInputIsHlg10: Boolean = false,
) {
    companion object {
        private const val TAG = "RealtimeVideoRenderer"
        private const val EGL_RECORDABLE_ANDROID = 0x3142
        private const val EGL_OPENGL_ES3_BIT_KHR = 0x0040
    }

    private data class LayerResources(
        val lutConfig: LutConfig?,
        val params: ColorRecipeParams,
        var lutTextureId: Int = 0,
        var curveTextureId: Int = 0,
    )

    private val appContext = context.applicationContext
    @Volatile private var cameraInputAlreadyHlg10 = cameraInputIsHlg10
    private val layers = colorLayers
        .map { layer ->
            LayerResources(
                lutConfig = layer.lutConfig,
                params = layer.recipeParams ?: ColorRecipeParams.DEFAULT,
            )
        }
        .ifEmpty {
            listOf(LayerResources(lutConfig = null, params = ColorRecipeParams.DEFAULT))
        }
        .also { resolved ->
            require(resolved.size <= 2) {
                "Realtime video supports the baseline and creative color layers only"
            }
        }
    private val colorProgramCache = PreviewColorProgramCache()
    private val basicToneTextures = BasicToneGlTextures()
    private val filmGrainGl = FilmGrainGl(TAG)
    private val mgcEisHardwareBufferRenderer = MgcEisHardwareBufferRenderer(TAG)
    private val mgcEisYuvRenderer = MgcEisYuvRenderer(TAG)
    private val filmGrainAmount: Float
        get() = layers.lastOrNull { it.params.filmGrain > 0.001f }?.params?.filmGrain ?: 0f
    private val finalFilmGrainEnabled: Boolean
        get() = filmGrainAmount > 0.001f &&
            encoderColorConfig.pipeline != VideoEncodedColorPipeline.CUSTOM_LOG &&
            encoderColorConfig.pipeline != VideoEncodedColorPipeline.HLG10
    private val identityMatrix = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val firstPassMvpMatrix = FloatArray(16).also {
        Matrix.setIdentityM(it, 0)
        if (mirrorHorizontally || mirrorVertically) {
            Matrix.scaleM(
                it,
                0,
                if (mirrorHorizontally) -1f else 1f,
                if (mirrorVertically) -1f else 1f,
                1f,
            )
        }
    }
    private val fullCropRect = floatArrayOf(0f, 0f, 1f, 1f)
    private var cameraCropRect = fullCropRect
    private var cameraTransformAxesSwapped: Boolean? = null
    private val stMatrix = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val mgcEisPresentationTransform = MgcEisPresentationTransform()

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var encoderEglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var cameraTextureId = 0
    private var cameraSurfaceTexture: SurfaceTexture? = null
    private var cameraSurface: Surface? = null
    // A second OES input stays attached to the same GL/encoder pipeline. Camera2 can keep
    // the other rear lens streaming into it while the active input changes without resetting
    // MediaCodec, EGL, the muxer, audio capture, or presentation-time mapping.
    private var standbyCameraTextureId = 0
    private var standbyCameraSurfaceTexture: SurfaceTexture? = null
    private var standbyCameraSurface: Surface? = null
    @Volatile private var activeCameraInputIndex = 0
    private var requestFrameAvailable: (() -> Unit)? = null
    private var intermediateTextureId = 0
    private var intermediateFboId = 0
    private var finalColorTextureId = 0
    private var finalColorFboId = 0
    private var vertexBuffer: FloatBuffer? = null
    private var textureCoordinateBuffer: FloatBuffer? = null
    private var indexBuffer: ShortBuffer? = null
    private var initialized = false
    private val cameraFramePending = AtomicBoolean(false)
    @Volatile
    private var stabilizationSession: RealtimeStabilizationCoordinator.Session? = null
    @Volatile
    private var stabilizationSessionStarted = false

    val inputSurface: Surface?
        get() = cameraSurface

    /** Independent Camera2 output used by the pre-warmed second lens during ordinary video. */
    val standbyInputSurface: Surface?
        get() = standbyCameraSurface?.takeIf { it.isValid && initialized }

    val isStandbyInputReady: Boolean
        get() = standbyInputSurface != null

    /**
     * Selects which already-running camera stream feeds the existing encoder pipeline.
     * Enhanced stabilization uses a single synchronized source, so it intentionally rejects
     * dual-input switching and lets the caller use the safe legacy handoff instead.
     */
    fun setActiveCameraInput(useStandby: Boolean): Boolean {
        if (useStandby && enhancedStabilizationEnabled) return false
        val next = if (useStandby) 1 else 0
        if (activeCameraInputIndex == next) return true
        if (next == 1 && standbyInputSurface == null) return false
        activeCameraInputIndex = next
        cameraFramePending.set(true)
        requestFrameAvailable?.invoke()
        return true
    }

    fun setCameraInputHlg10Source(enabled: Boolean) {
        cameraInputAlreadyHlg10 = enabled
    }

    fun initialize(
        encoderSurface: Surface,
        onFrameAvailable: () -> Unit,
    ) {
        check(!initialized) { "Realtime video renderer is already initialized" }
        requestFrameAvailable = onFrameAvailable
        initializeEgl(encoderSurface)
        check(makeCurrent()) { "Cannot make realtime video EGL context current" }
        initializeGeometry()
        initializeLayerTextures()
        if (layers.size > 1 || finalFilmGrainEnabled) {
            initializeIntermediateFramebuffer()
        }
        if (layers.size > 1 && finalFilmGrainEnabled) {
            val finalTarget = createColorFramebuffer("final color")
            finalColorTextureId = finalTarget.first
            finalColorFboId = finalTarget.second
        }
        if (finalFilmGrainEnabled) {
            check(filmGrainGl.prepare()) { "Cannot create realtime video film grain program" }
        }

        cameraTextureId = GlUtils.createOESTexture()
        check(cameraTextureId != 0) { "Cannot create realtime video OES texture" }
        cameraSurfaceTexture = SurfaceTexture(cameraTextureId).apply {
            setDefaultBufferSize(cameraInputSize.width, cameraInputSize.height)
            setOnFrameAvailableListener {
                cameraFramePending.set(true)
                if (!enhancedStabilizationEnabled ||
                    stabilizationCoordinator?.isCurrentCameraSupported != true
                ) {
                    onFrameAvailable()
                }
            }
        }
        cameraSurface = Surface(cameraSurfaceTexture)

        // The standby input deliberately uses the same EGL context, transform pipeline and
        // encoder target. The camera sessions own their own stream timing; only the selected
        // source is advanced by renderLatestFrame().
        standbyCameraTextureId = GlUtils.createOESTexture()
        check(standbyCameraTextureId != 0) { "Cannot create standby camera OES texture" }
        standbyCameraSurfaceTexture = SurfaceTexture(standbyCameraTextureId).apply {
            setDefaultBufferSize(cameraInputSize.width, cameraInputSize.height)
            setOnFrameAvailableListener {
                cameraFramePending.set(true)
                if (activeCameraInputIndex == 1 && !enhancedStabilizationEnabled) {
                    onFrameAvailable()
                }
            }
        }
        standbyCameraSurface = Surface(standbyCameraSurfaceTexture)

        if (enhancedStabilizationEnabled) {
            check(
                mgcEisPresentationTransform.captureFromSensorOrientation(
                    sensorOrientationDegrees,
                )
            ) {
                "Camera reported non-cardinal sensor orientation $sensorOrientationDegrees"
            }
            updateCameraTransformGeometry(mgcEisPresentationTransform.matrix)
            stabilizationSession = stabilizationCoordinator?.createSession(
                useCase = StabilizationUseCase.VIDEO,
                strength = enhancedStabilizationStrength,
                frameWidth = cameraInputSize.width,
                frameHeight = cameraInputSize.height,
                lookaheadFrames = enhancedStabilizationLookahead,
                onFrameAvailable = onFrameAvailable,
            )
        }
        initialized = true
        PLog.i(
            TAG,
            "Initialized: camera=${cameraInputSize.width}x${cameraInputSize.height}, " +
                "encoder=${encoderOutputSize.width}x${encoderOutputSize.height}, " +
                "sensorOrientation=$sensorOrientationDegrees, " +
                "layers=${layers.size}, log=${videoLogProfile.name}, " +
                "cameraInputHlg10=$cameraInputAlreadyHlg10, " +
                "enhancedStabilization=$enhancedStabilizationEnabled, " +
                "stabilizationStrength=$enhancedStabilizationStrength, " +
                "mirrorH=$mirrorHorizontally, mirrorV=$mirrorVertically, " +
                "color=${encoderColorConfig.debugName}"
        )
    }

    /**
     * 消费 SurfaceTexture 中最新的一帧并写入编码器。必须在初始化所用的录像 GL 线程调用。
     *
     * [mapPresentationTimeNs] 将相机时间轴映射到编码器使用的公共时间轴。
     *
     * @return 写入编码器的帧时间戳（纳秒）；没有有效帧时返回 null。
     */
    fun renderLatestFrame(
        mapPresentationTimeNs: (cameraTimestampNs: Long) -> Long,
    ): Long? {
        if (!initialized || !makeCurrent()) return null
        val sourceIndex = activeCameraInputIndex
        val surfaceTexture = if (sourceIndex == 1) {
            standbyCameraSurfaceTexture
        } else {
            cameraSurfaceTexture
        } ?: return null
        // When the lens source changes, consume the newest frame from that source immediately.
        // No encoder/muxer restart is involved, and the existing timestamp mapper keeps the output
        // timeline monotonic across the two independent sensor clock domains.
        val cameraFrameUpdated = cameraFramePending.getAndSet(false) &&
            acquireLatestCameraFrame(surfaceTexture)
        val cameraTimestampNs = surfaceTexture.timestamp

        var sourceTextureSource = PreviewColorTextureSource.EXTERNAL_OES
        var sourceTextureTarget = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
        var sourceTextureId = cameraTextureId
        var sourceStMatrix = stMatrix
        var sourceCropRect = cameraCropRect
        var timestampNs = cameraTimestampNs

        val session = stabilizationSession
        val stabilizationOperational = enhancedStabilizationEnabled &&
            stabilizationSessionStarted && session?.isOperational == true
        if (stabilizationSessionStarted && !stabilizationOperational) {
            session?.stop()
            stabilizationSessionStarted = false
            mgcEisPresentationTransform.reset()
        }
        if (stabilizationOperational) {
            val frame = session.dequeueFrame() ?: return null
            val rendered = renderMgcEisFrame(frame) ?: return null
            sourceTextureSource = PreviewColorTextureSource.TEXTURE_2D
            sourceTextureTarget = GLES30.GL_TEXTURE_2D
            sourceTextureId = rendered.textureId
            sourceStMatrix = mgcEisPresentationTransform.matrix
            sourceCropRect = resolveCameraCropRect(
                presentationMatrix = mgcEisPresentationTransform.matrix,
                inputWidth = rendered.width,
                inputHeight = rendered.height,
            )
            timestampNs = rendered.timestampNs
        } else {
            if (!cameraFrameUpdated || cameraTimestampNs <= 0L) return null
        }
        if (timestampNs <= 0L) return null
        val presentationTimeNs = mapPresentationTimeNs(timestampNs)
        if (presentationTimeNs <= 0L) return null

        val firstLayer = layers.first()
        val grainEnabled = finalFilmGrainEnabled
        val firstTargetFbo = if (layers.size > 1 || grainEnabled) intermediateFboId else 0
        drawLayer(
            layer = firstLayer,
            targetFboId = firstTargetFbo,
            textureSource = sourceTextureSource,
            textureTarget = sourceTextureTarget,
            textureId = sourceTextureId,
            sourceStMatrix = sourceStMatrix,
            cropRect = sourceCropRect,
            mvpMatrix = firstPassMvpMatrix,
            enableVideoLog = videoLogProfile.isEnabled && !cameraInputAlreadyHlg10,
            presentationTimeNs = timestampNs,
        )

        if (layers.size > 1) {
            layers.drop(1).forEachIndexed { index, layer ->
                val isLast = index == layers.lastIndex - 1
                drawLayer(
                    layer = layer,
                    targetFboId = if (isLast) {
                        if (grainEnabled) finalColorFboId else 0
                    } else {
                        intermediateFboId
                    },
                    textureSource = PreviewColorTextureSource.TEXTURE_2D,
                    textureTarget = GLES30.GL_TEXTURE_2D,
                    textureId = intermediateTextureId,
                    sourceStMatrix = identityMatrix,
                    cropRect = fullCropRect,
                    mvpMatrix = identityMatrix,
                    enableVideoLog = false,
                    presentationTimeNs = timestampNs,
                )
            }
        }

        if (grainEnabled) {
            val sourceTextureId = if (layers.size > 1) finalColorTextureId else intermediateTextureId
            check(
                filmGrainGl.drawToFramebuffer(
                    targetFramebufferId = 0,
                    sourceTextureId = sourceTextureId,
                    width = encoderOutputSize.width,
                    height = encoderOutputSize.height,
                    amount = filmGrainAmount,
                    frameSeed = FilmGrainShaders.frameSeed(timestampNs),
                    drawQuad = ::drawSimpleQuad,
                )
            ) {
                "Realtime video film grain pass failed"
            }
        }

        EGLExt.eglPresentationTimeANDROID(eglDisplay, encoderEglSurface, presentationTimeNs)
        if (!EGL14.eglSwapBuffers(eglDisplay, encoderEglSurface)) {
            throw IllegalStateException(
                "Realtime video eglSwapBuffers failed: 0x${Integer.toHexString(EGL14.eglGetError())}"
            )
        }
        return presentationTimeNs
    }

    private fun acquireLatestCameraFrame(surfaceTexture: SurfaceTexture): Boolean {
        return try {
            surfaceTexture.updateTexImage()
            surfaceTexture.getTransformMatrix(stMatrix)
            if (enhancedStabilizationEnabled &&
                !mgcEisPresentationTransform.captureFromOes(stMatrix)
            ) {
                PLog.w(TAG, "MGC cannot derive a cardinal presentation orientation yet")
            }
            updateCameraTransformGeometry(
                if (enhancedStabilizationEnabled) {
                    mgcEisPresentationTransform.matrix
                } else {
                    stMatrix
                },
            )
            true
        } catch (error: RuntimeException) {
            PLog.e(TAG, "Failed to acquire realtime video frame", error)
            false
        }
    }

    private fun renderMgcEisFrame(
        frame: com.hinnka.mycamera.stabilization.StabilizationFrame,
    ): MgcEisHardwareBufferRenderer.Frame? {
        val hardwareRendered = mgcEisHardwareBufferRenderer.render(frame)
        if (hardwareRendered != null) {
            frame.image.close()
            return hardwareRendered
        }
        return mgcEisYuvRenderer.render(frame)?.let { rendered ->
            MgcEisHardwareBufferRenderer.Frame(
                timestampNs = rendered.timestampNs,
                textureId = rendered.textureId,
                width = rendered.width,
                height = rendered.height,
            )
        }
    }

    private fun resolveCameraCropRect(
        presentationMatrix: FloatArray,
        inputWidth: Int,
        inputHeight: Int,
    ): FloatArray {
        val safeWidth = inputWidth.coerceAtLeast(1)
        val safeHeight = inputHeight.coerceAtLeast(1)
        val axesSwapped = isTextureTransformAxesSwapped(presentationMatrix)
        val orientedInputSize = if (axesSwapped) {
            Size(safeHeight, safeWidth)
        } else {
            Size(safeWidth, safeHeight)
        }
        return resolveCenterCropRect(orientedInputSize, encoderOutputSize)
    }

    private fun updateCameraTransformGeometry(presentationMatrix: FloatArray) {
        val axesSwapped = isTextureTransformAxesSwapped(presentationMatrix)
        if (cameraTransformAxesSwapped == axesSwapped) return

        cameraTransformAxesSwapped = axesSwapped
        cameraCropRect = resolveCameraCropRect(
            presentationMatrix = presentationMatrix,
            inputWidth = cameraInputSize.width,
            inputHeight = cameraInputSize.height,
        )
        PLog.i(
            TAG,
            "Camera texture transform: axesSwapped=$axesSwapped, " +
                "effectiveInput=${if (axesSwapped) cameraInputSize.height else cameraInputSize.width}x" +
                "${if (axesSwapped) cameraInputSize.width else cameraInputSize.height}, " +
                "crop=${cameraCropRect.joinToString(prefix = "[", postfix = "]")}, " +
                "matrix=${presentationMatrix.joinToString(prefix = "[", postfix = "]")}"
        )
    }

    private fun drawLayer(
        layer: LayerResources,
        targetFboId: Int,
        textureSource: PreviewColorTextureSource,
        textureTarget: Int,
        textureId: Int,
        sourceStMatrix: FloatArray,
        cropRect: FloatArray,
        mvpMatrix: FloatArray,
        enableVideoLog: Boolean,
        presentationTimeNs: Long,
    ) {
        val lutEnabled = layer.lutConfig != null && layer.lutTextureId != 0
        val variant = PreviewColorShaderVariant.forPass(
            textureSource = textureSource,
            params = layer.params,
            lutConfig = layer.lutConfig,
            lutEnabled = lutEnabled,
            videoLogEnabled = enableVideoLog,
        )
        val locations = colorProgramCache.get(variant)
            ?: throw IllegalStateException("Cannot create realtime video color shader: $variant")

        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, targetFboId)
        GLES30.glViewport(0, 0, encoderOutputSize.width, encoderOutputSize.height)
        GLES30.glClearColor(0f, 0f, 0f, 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        GLES30.glUseProgram(locations.programId)
        colorProgramCache.bindLogInput(locations)

        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(textureTarget, textureId)
        GLES30.glUniform1i(locations.uCameraTextureLocation, 0)

        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(
            GLES30.GL_TEXTURE_3D,
            if (lutEnabled) layer.lutTextureId else 0,
        )
        GLES30.glUniform1i(locations.uLutTextureLocation, 1)

        GLES30.glUniformMatrix4fv(locations.uMVPMatrixLocation, 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(locations.uSTMatrixLocation, 1, false, sourceStMatrix, 0)
        GLES30.glUniform4f(
            locations.uCropRectLocation,
            cropRect[0],
            cropRect[1],
            cropRect[2],
            cropRect[3],
        )
        GLES30.glUniform1f(
            locations.uLutSizeLocation,
            layer.lutConfig?.size?.toFloat() ?: 1f,
        )
        GLES30.glUniform1f(locations.uLutIntensityLocation, layer.params.lutIntensity)
        GLES30.glUniform1i(locations.uLutEnabledLocation, if (lutEnabled) 1 else 0)
        GLES30.glUniform1i(locations.uLutMaskTypeLocation, 0)
        GLES30.glUniform1i(
            locations.uLutCurveLocation,
            LutShaderMappings.transferCurveId(layer.lutConfig?.curve),
        )
        GLES30.glUniform1i(
            locations.uLutColorSpaceLocation,
            LutShaderMappings.colorSpaceId(
                layer.lutConfig?.colorSpace ?: com.hinnka.mycamera.raw.ColorSpace.SRGB
            ),
        )
        GLES30.glUniform1i(
            locations.uVideoLogEnabledLocation,
            if (enableVideoLog && videoLogProfile.isEnabled) 1 else 0,
        )
        GLES30.glUniform1i(
            locations.uVideoLogCurveLocation,
            LutShaderMappings.transferCurveId(videoLogProfile.logCurve),
        )
        GLES30.glUniform1i(
            locations.uVideoColorSpaceLocation,
            LutShaderMappings.colorSpaceId(videoLogProfile.colorSpace),
        )
        bindRecipeUniforms(
            locations = locations,
            params = layer.params,
            presentationTimeNs = presentationTimeNs,
        )

        val curveEnabled = layer.curveTextureId != 0
        GLES30.glActiveTexture(GLES30.GL_TEXTURE2)
        GLES30.glBindTexture(
            GLES30.GL_TEXTURE_2D,
            if (curveEnabled) layer.curveTextureId else 0,
        )
        GLES30.glUniform1i(locations.uCurveTextureLocation, 2)
        GLES30.glUniform1i(locations.uCurveEnabledLocation, if (curveEnabled) 1 else 0)

        basicToneTextures.bind(
            context = appContext,
            textureUnit = 3,
            samplerLocation = locations.uBasicToneLutLocation,
            intensityLocation = locations.uBasicToneIntensityLocation,
            amount = layer.params.tonality,
        )

        GLES30.glUniform2f(
            locations.uTexelSizeLocation,
            1f / max(1, encoderOutputSize.width).toFloat(),
            1f / max(1, encoderOutputSize.height).toFloat(),
        )

        val positions = vertexBuffer ?: return
        val textureCoordinates = textureCoordinateBuffer ?: return
        val indices = indexBuffer ?: return
        positions.position(0)
        textureCoordinates.position(0)
        indices.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)
        GLES30.glEnableVertexAttribArray(locations.aPositionLocation)
        GLES30.glVertexAttribPointer(
            locations.aPositionLocation, 2, GLES30.GL_FLOAT, false, 0, positions,
        )
        GLES30.glEnableVertexAttribArray(locations.aTexCoordLocation)
        GLES30.glVertexAttribPointer(
            locations.aTexCoordLocation, 2, GLES30.GL_FLOAT, false, 0, textureCoordinates,
        )
        GLES30.glDrawElements(
            GLES30.GL_TRIANGLES,
            Shaders.DRAW_ORDER.size,
            GLES30.GL_UNSIGNED_SHORT,
            indices,
        )
        GLES30.glDisableVertexAttribArray(locations.aPositionLocation)
        GLES30.glDisableVertexAttribArray(locations.aTexCoordLocation)
        GlUtils.checkGlError("RealtimeVideoRenderer.drawLayer")
    }

    private fun bindRecipeUniforms(
        locations: ColorPassLocations,
        params: ColorRecipeParams,
        presentationTimeNs: Long,
    ) {
        val enabled = !params.isDefault()
        GLES30.glUniform1i(locations.uColorRecipeEnabledLocation, if (enabled) 1 else 0)
        // 低像素和色散采样位于 shader 的 recipeEnabled 分支之前，必须每个 pass
        // 都显式赋值，避免复用同一 program 时继承上一层的 uniform。
        GLES30.glUniform1f(locations.uChromaticAberrationLocation, params.chromaticAberration)
        GLES30.glUniform1f(locations.uLowResLocation, params.lowRes)
        GLES30.glUniform1f(
            locations.uAspectRatioLocation,
            encoderOutputSize.width.toFloat() / max(1, encoderOutputSize.height).toFloat(),
        )
        if (!enabled) return

        GLES30.glUniform1f(locations.uExposureLocation, params.exposure)
        GLES30.glUniform1f(locations.uContrastLocation, params.contrast)
        GLES30.glUniform1f(locations.uSaturationLocation, params.saturation)
        GLES30.glUniform1f(locations.uTemperatureLocation, params.temperature)
        GLES30.glUniform1f(locations.uTintLocation, params.tint)
        GLES30.glUniform1f(locations.uFadeLocation, params.fade)
        GLES30.glUniform1f(locations.uVibranceLocation, params.color)
        ShadowsHighlightsShader.bindUniformLocations(
            highlightsLocation = locations.uHighlightsLocation,
            shadowsLocation = locations.uShadowsLocation,
            highlights = params.highlights,
            shadows = params.shadows,
        )
        GLES30.glUniform1f(locations.uSharpeningLocation, params.sharpness.coerceIn(-1f, 1f))
        GLES30.glUniform1f(locations.uFilmGrainLocation, params.filmGrain)
        GLES30.glUniform1f(
            locations.uFilmGrainSeedLocation,
            FilmGrainShaders.frameSeed(presentationTimeNs),
        )
        GLES30.glUniform1f(
            locations.uFilmGrainPixelScaleLocation,
            FilmGrainShaders.pixelScale(encoderOutputSize.width, encoderOutputSize.height),
        )
        GLES30.glUniform1f(locations.uVignetteLocation, params.vignette)
        GLES30.glUniform1f(locations.uFlashLocation, params.flash)
        GLES30.glUniform1f(locations.uBleachBypassLocation, params.bleachBypass)
        GLES30.glUniform1f(locations.uNoiseLocation, params.noise)
        GLES30.glUniform1f(
            locations.uNoiseSeedLocation,
            (presentationTimeNs % 10_000_000_000L) / 1_000_000_000f,
        )
        GLES30.glUniform3f(
            locations.uGradingHuesLocation,
            params.gradingShadowHue,
            params.gradingMidtoneHue,
            params.gradingHighlightHue,
        )
        GLES30.glUniform3f(
            locations.uGradingAmountsLocation,
            params.gradingShadowAmount,
            params.gradingMidtoneAmount,
            params.gradingHighlightAmount,
        )
        GLES30.glUniform3f(
            locations.uGradingLuminancesLocation,
            params.gradingShadowLuminance,
            params.gradingMidtoneLuminance,
            params.gradingHighlightLuminance,
        )
        GLES30.glUniform1f(locations.uGradingBalanceLocation, params.gradingBalance)
        GLES30.glUniform1f(locations.uGradingBlendingLocation, params.gradingBlending)
        ColorRecipeGl.bindLchAdjustments(
            locations.uLchHueAdjustmentsLocation,
            locations.uLchChromaAdjustmentsLocation,
            locations.uLchLightnessAdjustmentsLocation,
            ColorRecipeGl.lchAdjustments(params),
        )
        GLES30.glUniformMatrix3fv(
            locations.uPrimaryCalibrationMatrixLocation,
            1,
            false,
            CameraRawCalibrationMatrix.build(params),
            0,
        )
    }

    private fun initializeEgl(encoderSurface: Surface) {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(eglDisplay != EGL14.EGL_NO_DISPLAY) { "Cannot obtain EGL display" }
        val major = IntArray(1)
        val minor = IntArray(1)
        check(EGL14.eglInitialize(eglDisplay, major, 0, minor, 0)) {
            "Cannot initialize EGL display"
        }
        val candidates = buildList {
            if (encoderColorConfig.prefer10BitInputSurface) {
                chooseConfig(red = 10, green = 10, blue = 10, alpha = 2)
                    ?.let { add("RGB10_A2" to it) }
            }
            if (!encoderColorConfig.require10BitInputSurface) {
                chooseConfig(red = 8, green = 8, blue = 8, alpha = 8)
                    ?.let { add("RGBA8888" to it) }
            }
        }
        check(candidates.isNotEmpty()) { "Cannot choose recordable EGL config" }

        var lastError = EGL14.EGL_SUCCESS
        candidates.forEach { (label, config) ->
            eglContext = EGL14.eglCreateContext(
                eglDisplay,
                config,
                EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE),
                0,
            )
            if (eglContext == EGL14.EGL_NO_CONTEXT) {
                lastError = EGL14.eglGetError()
                PLog.w(TAG, "$label realtime EGL context unavailable: 0x${Integer.toHexString(lastError)}")
                return@forEach
            }

            encoderEglSurface = EGL14.eglCreateWindowSurface(
                eglDisplay,
                config,
                encoderSurface,
                intArrayOf(EGL14.EGL_NONE),
                0,
            )
            if (encoderEglSurface != EGL14.EGL_NO_SURFACE && makeCurrent()) {
                if (encoderColorConfig.prefer10BitInputSurface && label != "RGB10_A2") {
                    PLog.w(
                        TAG,
                        "10-bit encoder EGL surface unavailable; using RGBA8888 for " +
                            "${encoderColorConfig.debugName}"
                    )
                } else {
                    PLog.i(TAG, "Using $label recordable EGL surface for ${encoderColorConfig.debugName}")
                }
                return
            }

            lastError = EGL14.eglGetError()
            PLog.w(TAG, "$label encoder EGL surface unavailable: 0x${Integer.toHexString(lastError)}")
            if (encoderEglSurface != EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroySurface(eglDisplay, encoderEglSurface)
                encoderEglSurface = EGL14.EGL_NO_SURFACE
            }
            EGL14.eglDestroyContext(eglDisplay, eglContext)
            eglContext = EGL14.EGL_NO_CONTEXT
        }

        if (encoderColorConfig.prefer10BitInputSurface) {
            PLog.w(TAG, "10-bit encoder EGL surface unavailable; the Log path cannot preserve 10-bit precision")
        }
        throw IllegalStateException(
            "Cannot create encoder EGL surface: 0x${Integer.toHexString(lastError)}"
        )
    }

    private fun chooseConfig(red: Int, green: Int, blue: Int, alpha: Int): EGLConfig? {
        return chooseConfig(red, green, blue, alpha, EGL_OPENGL_ES3_BIT_KHR)
            ?: chooseConfig(red, green, blue, alpha, EGL14.EGL_OPENGL_ES2_BIT)
    }

    private fun chooseConfig(
        red: Int,
        green: Int,
        blue: Int,
        alpha: Int,
        renderableType: Int,
    ): EGLConfig? {
        val configs = arrayOfNulls<EGLConfig>(1)
        val count = IntArray(1)
        val attributes = intArrayOf(
            EGL14.EGL_RED_SIZE, red,
            EGL14.EGL_GREEN_SIZE, green,
            EGL14.EGL_BLUE_SIZE, blue,
            EGL14.EGL_ALPHA_SIZE, alpha,
            EGL14.EGL_RENDERABLE_TYPE, renderableType,
            EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE,
        )
        val success = EGL14.eglChooseConfig(
            eglDisplay,
            attributes,
            0,
            configs,
            0,
            configs.size,
            count,
            0,
        )
        return if (success && count[0] > 0) configs[0] else null
    }

    private fun makeCurrent(): Boolean {
        if (eglDisplay == EGL14.EGL_NO_DISPLAY ||
            eglContext == EGL14.EGL_NO_CONTEXT ||
            encoderEglSurface == EGL14.EGL_NO_SURFACE
        ) {
            return false
        }
        return EGL14.eglMakeCurrent(
            eglDisplay,
            encoderEglSurface,
            encoderEglSurface,
            eglContext,
        )
    }

    private fun initializeGeometry() {
        vertexBuffer = ByteBuffer.allocateDirect(Shaders.FULL_QUAD_VERTICES.size * Float.SIZE_BYTES)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply {
                put(Shaders.FULL_QUAD_VERTICES)
                position(0)
            }
        textureCoordinateBuffer =
            ByteBuffer.allocateDirect(Shaders.TEXTURE_COORDS.size * Float.SIZE_BYTES)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
                .apply {
                    put(Shaders.TEXTURE_COORDS)
                    position(0)
                }
        indexBuffer = ByteBuffer.allocateDirect(Shaders.DRAW_ORDER.size * Short.SIZE_BYTES)
            .order(ByteOrder.nativeOrder())
            .asShortBuffer()
            .apply {
                put(Shaders.DRAW_ORDER)
                position(0)
            }
    }

    private fun initializeLayerTextures() {
        layers.forEach { layer ->
            layer.lutConfig?.let { config ->
                layer.lutTextureId = GlUtils.create3DTexture(config)
                check(layer.lutTextureId != 0) {
                    "Cannot upload realtime video LUT ${config.title}"
                }
            }
            val params = layer.params
            val hasCurve = params.masterCurvePoints != null ||
                params.redCurvePoints != null ||
                params.greenCurvePoints != null ||
                params.blueCurvePoints != null
            if (hasCurve) {
                layer.curveTextureId = ColorRecipeGl.ensureCurveTextureUploaded(
                    textureId = 0,
                    pendingBuffer = CurveUtils.buildCurveTextureBuffer(
                        params.masterCurvePoints,
                        params.redCurvePoints,
                        params.greenCurvePoints,
                        params.blueCurvePoints,
                    ),
                )
                check(layer.curveTextureId != 0) {
                    "Cannot upload realtime video curve texture"
                }
            }
        }
    }

    private fun initializeIntermediateFramebuffer() {
        val target = createColorFramebuffer("intermediate")
        intermediateTextureId = target.first
        intermediateFboId = target.second
    }

    private fun createColorFramebuffer(label: String): Pair<Int, Int> {
        val maxTextureSize = IntArray(1)
        GLES30.glGetIntegerv(GLES30.GL_MAX_TEXTURE_SIZE, maxTextureSize, 0)
        check(
            encoderOutputSize.width in 1..maxTextureSize[0] &&
                encoderOutputSize.height in 1..maxTextureSize[0]
        ) {
            "Realtime video $label target ${encoderOutputSize.width}x${encoderOutputSize.height} " +
                "exceeds GL_MAX_TEXTURE_SIZE=${maxTextureSize[0]}"
        }
        check(GLES30.glGetError() == GLES30.GL_NO_ERROR) {
            "Realtime video $label framebuffer has an upstream GL error"
        }

        val textures = IntArray(1)
        GLES30.glGenTextures(1, textures, 0)
        val textureId = textures[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D,
            0,
            GLES30.GL_RGBA8,
            encoderOutputSize.width,
            encoderOutputSize.height,
            0,
            GLES30.GL_RGBA,
            GLES30.GL_UNSIGNED_BYTE,
            null,
        )

        val framebuffers = IntArray(1)
        GLES30.glGenFramebuffers(1, framebuffers, 0)
        val framebufferId = framebuffers[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, framebufferId)
        GLES30.glFramebufferTexture2D(
            GLES30.GL_FRAMEBUFFER,
            GLES30.GL_COLOR_ATTACHMENT0,
            GLES30.GL_TEXTURE_2D,
            textureId,
            0,
        )
        val status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER)
        val glError = GLES30.glGetError()
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        if (status != GLES30.GL_FRAMEBUFFER_COMPLETE || glError != GLES30.GL_NO_ERROR) {
            GLES30.glDeleteFramebuffers(1, intArrayOf(framebufferId), 0)
            GLES30.glDeleteTextures(1, intArrayOf(textureId), 0)
            error(
                "Realtime video $label framebuffer is incomplete: status=$status glError=$glError"
            )
        }
        return textureId to framebufferId
    }

    private fun drawSimpleQuad(programId: Int) {
        val positions = vertexBuffer ?: return
        val textureCoordinates = textureCoordinateBuffer ?: return
        val indices = indexBuffer ?: return
        val positionLocation = GLES30.glGetAttribLocation(programId, "aPosition")
        val textureLocation = GLES30.glGetAttribLocation(programId, "aTexCoord")
        positions.position(0)
        textureCoordinates.position(0)
        indices.position(0)
        GLES30.glEnableVertexAttribArray(positionLocation)
        GLES30.glVertexAttribPointer(positionLocation, 2, GLES30.GL_FLOAT, false, 0, positions)
        GLES30.glEnableVertexAttribArray(textureLocation)
        GLES30.glVertexAttribPointer(textureLocation, 2, GLES30.GL_FLOAT, false, 0, textureCoordinates)
        GLES30.glDrawElements(
            GLES30.GL_TRIANGLES,
            Shaders.DRAW_ORDER.size,
            GLES30.GL_UNSIGNED_SHORT,
            indices,
        )
        GLES30.glDisableVertexAttribArray(positionLocation)
        GLES30.glDisableVertexAttribArray(textureLocation)
    }

    @Synchronized
    fun pauseStabilization() {
        stabilizationSession?.stop()
        stabilizationSessionStarted = false
    }

    @Synchronized
    fun resumeStabilization() {
        if (!enhancedStabilizationEnabled || stabilizationSessionStarted) return
        stabilizationSessionStarted = stabilizationSession?.start() == true
    }

    /**
     * Camera2 closes and recreates its capture session during a physical lens switch. Restart the
     * EIS session against the new calibration so returning to a supported lens cannot leave the
     * encoder waiting forever on an inactive stabilization session.
     */
    @Synchronized
    fun restartStabilizationForCameraSwitch(sensorOrientationDegrees: Int) {
        if (!initialized || !enhancedStabilizationEnabled) return

        // A selected physical camera may expose a different cardinal sensor orientation.
        // Reset only the presentation transform; keep the encoder and stabilization lifecycle
        // intact so the existing no-freeze fix is not undone.
        mgcEisPresentationTransform.reset()
        if (mgcEisPresentationTransform.captureFromSensorOrientation(sensorOrientationDegrees)) {
            cameraTransformAxesSwapped = null
            updateCameraTransformGeometry(mgcEisPresentationTransform.matrix)
        } else {
            PLog.w(TAG, "Cannot refresh EIS presentation orientation: $sensorOrientationDegrees")
        }

        val session = stabilizationSession ?: return
        session.stop()
        stabilizationSessionStarted = false
        stabilizationSessionStarted = session.start()
        PLog.i(
            TAG,
            "MGC EIS recording session refreshed after camera switch: " +
                "sensorOrientation=$sensorOrientationDegrees, " +
                "started=$stabilizationSessionStarted, " +
                "cameraSupported=${stabilizationCoordinator?.isCurrentCameraSupported}",
        )
    }

    fun release() {
        stabilizationSession?.stop()
        stabilizationSession = null
        stabilizationSessionStarted = false
        requestFrameAvailable = null
        if (eglDisplay != EGL14.EGL_NO_DISPLAY &&
            eglContext != EGL14.EGL_NO_CONTEXT &&
            encoderEglSurface != EGL14.EGL_NO_SURFACE
        ) {
            makeCurrent()
        }
        cameraSurfaceTexture?.setOnFrameAvailableListener(null)
        cameraSurface?.release()
        cameraSurface = null
        cameraSurfaceTexture?.release()
        cameraSurfaceTexture = null
        standbyCameraSurfaceTexture?.setOnFrameAvailableListener(null)
        standbyCameraSurface?.release()
        standbyCameraSurface = null
        standbyCameraSurfaceTexture?.release()
        standbyCameraSurfaceTexture = null
        activeCameraInputIndex = 0

        layers.forEach { layer ->
            if (layer.lutTextureId != 0) {
                GLES30.glDeleteTextures(1, intArrayOf(layer.lutTextureId), 0)
                layer.lutTextureId = 0
            }
            if (layer.curveTextureId != 0) {
                GLES30.glDeleteTextures(1, intArrayOf(layer.curveTextureId), 0)
                layer.curveTextureId = 0
            }
        }
        if (cameraTextureId != 0) {
            GLES30.glDeleteTextures(1, intArrayOf(cameraTextureId), 0)
            cameraTextureId = 0
        }
        if (standbyCameraTextureId != 0) {
            GLES30.glDeleteTextures(1, intArrayOf(standbyCameraTextureId), 0)
            standbyCameraTextureId = 0
        }
        if (intermediateTextureId != 0) {
            GLES30.glDeleteTextures(1, intArrayOf(intermediateTextureId), 0)
            intermediateTextureId = 0
        }
        if (intermediateFboId != 0) {
            GLES30.glDeleteFramebuffers(1, intArrayOf(intermediateFboId), 0)
            intermediateFboId = 0
        }
        if (finalColorTextureId != 0) {
            GLES30.glDeleteTextures(1, intArrayOf(finalColorTextureId), 0)
            finalColorTextureId = 0
        }
        if (finalColorFboId != 0) {
            GLES30.glDeleteFramebuffers(1, intArrayOf(finalColorFboId), 0)
            finalColorFboId = 0
        }
        filmGrainGl.release()
        mgcEisHardwareBufferRenderer.release()
        mgcEisYuvRenderer.release()
        colorProgramCache.release()
        basicToneTextures.release()

        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(
                eglDisplay,
                EGL14.EGL_NO_SURFACE,
                EGL14.EGL_NO_SURFACE,
                EGL14.EGL_NO_CONTEXT,
            )
            if (encoderEglSurface != EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroySurface(eglDisplay, encoderEglSurface)
            }
            if (eglContext != EGL14.EGL_NO_CONTEXT) {
                EGL14.eglDestroyContext(eglDisplay, eglContext)
            }
        }
        encoderEglSurface = EGL14.EGL_NO_SURFACE
        eglContext = EGL14.EGL_NO_CONTEXT
        eglDisplay = EGL14.EGL_NO_DISPLAY
        initialized = false
    }
}

internal fun isTextureTransformAxesSwapped(matrix: FloatArray): Boolean {
    if (matrix.size < 6) return false
    val transformedXAxisFollowsY = abs(matrix[1]) > abs(matrix[0])
    val transformedYAxisFollowsX = abs(matrix[4]) > abs(matrix[5])
    return transformedXAxisFollowsY && transformedYAxisFollowsX
}

private fun resolveCenterCropRect(source: Size, target: Size): FloatArray =
    resolveCenterCropRect(source.width, source.height, target.width, target.height)

internal fun resolveCenterCropRect(
    sourceWidth: Int,
    sourceHeight: Int,
    targetWidth: Int,
    targetHeight: Int,
): FloatArray {
    val sourceAspect = sourceWidth.coerceAtLeast(1).toFloat() /
        sourceHeight.coerceAtLeast(1).toFloat()
    val targetAspect = targetWidth.coerceAtLeast(1).toFloat() /
        targetHeight.coerceAtLeast(1).toFloat()
    return when {
        sourceAspect > targetAspect -> {
            val visibleWidth = targetAspect / sourceAspect
            val inset = (1f - visibleWidth) / 2f
            floatArrayOf(inset, 0f, 1f - inset, 1f)
        }
        sourceAspect < targetAspect -> {
            val visibleHeight = sourceAspect / targetAspect
            val inset = (1f - visibleHeight) / 2f
            floatArrayOf(0f, inset, 1f, 1f - inset)
        }
        else -> floatArrayOf(0f, 0f, 1f, 1f)
    }
}
