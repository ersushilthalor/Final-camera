package com.hinnka.mycamera.raw

import kotlin.math.pow

internal object DngProfileToneCurve {
    const val PHOTON_PGTM_PROFILE_NAME = "Photon HDR"

    private const val POINT_TOLERANCE = 2e-4f
    private const val LUT_TOLERANCE = 2e-3f
    private const val DNG_PROFILE_TONE_CURVE_POINT_COUNT = 257
    private const val JPG_TONE_CURVE_MIDDLE_GRAY = 0.18f

    private val LINEAR_TONE_CURVE_POINTS = floatArrayOf(0f, 0f, 1f, 1f)

    private val GOOGLE_HDR_TONE_CURVE_Y = floatArrayOf(
        0f, 0.000817775668f, 0.00170822139f, 0.00267076469f, 0.0037048338f, 0.00480985641f, 0.00598525954f, 0.00723047229f,
        0.00854492188f, 0.00992803555f, 0.0113792419f, 0.0128979683f, 0.0144836418f, 0.0161356926f, 0.017853545f, 0.019636631f,
        0.021484375f, 0.0233962052f, 0.0253715515f, 0.0274098385f, 0.029510498f, 0.0316729546f, 0.0338966362f, 0.0361809731f,
        0.0385253914f, 0.0409293175f, 0.0433921814f, 0.0459134094f, 0.0484924316f, 0.0511286743f, 0.0538215637f, 0.0565705299f,
        0.0593749993f, 0.0622344017f, 0.0651481599f, 0.0681157112f, 0.0711364746f, 0.0742098764f, 0.0773353577f, 0.0805123299f,
        0.0837402344f, 0.0870184898f, 0.0903465226f, 0.093723774f, 0.0971496552f, 0.100623608f, 0.10414505f, 0.107713409f,
        0.111328125f, 0.11498861f, 0.118694305f, 0.12244463f, 0.126239017f, 0.130076885f, 0.133957669f, 0.137880802f,
        0.141845703f, 0.145851806f, 0.149898529f, 0.153985307f, 0.158111572f, 0.162276745f, 0.166480258f, 0.170721531f,
        0.174999997f, 0.17931509f, 0.183666229f, 0.188052848f, 0.192474365f, 0.196930215f, 0.20141983f, 0.205942631f,
        0.21049805f, 0.215085506f, 0.219704434f, 0.224354267f, 0.229034424f, 0.233744338f, 0.238483429f, 0.24325113f,
        0.248046875f, 0.252870083f, 0.257720172f, 0.262596607f, 0.267498791f, 0.272426128f, 0.277378082f, 0.282354057f,
        0.287353516f, 0.292375863f, 0.297420502f, 0.302486897f, 0.307574451f, 0.312682629f, 0.317810833f, 0.322958469f,
        0.328125f, 0.333309829f, 0.338512421f, 0.343732178f, 0.348968506f, 0.354220867f, 0.359488666f, 0.364771366f,
        0.370068371f, 0.375379086f, 0.380702972f, 0.386039436f, 0.391387939f, 0.396747887f, 0.402118683f, 0.40749979f,
        0.412890613f, 0.418290615f, 0.4236992f, 0.429115772f, 0.434539795f, 0.439970672f, 0.445407867f, 0.450850785f,
        0.456298828f, 0.461751461f, 0.467208087f, 0.472668171f, 0.478131115f, 0.483596325f, 0.489063263f, 0.494531333f,
        0.5f, 0.505468667f, 0.510936737f, 0.516403675f, 0.521868885f, 0.527331829f, 0.532791913f, 0.538248539f,
        0.543701172f, 0.549149215f, 0.554592133f, 0.560029328f, 0.565460205f, 0.570884228f, 0.5763008f, 0.581709385f,
        0.587109387f, 0.59250021f, 0.597881317f, 0.603252113f, 0.608612061f, 0.613960564f, 0.619297028f, 0.624620914f,
        0.629931629f, 0.635228634f, 0.640511334f, 0.645779133f, 0.651031494f, 0.656267822f, 0.661487579f, 0.666690171f,
        0.671875f, 0.677041531f, 0.682189167f, 0.687317371f, 0.692425549f, 0.697513103f, 0.702579498f, 0.707624137f,
        0.712646484f, 0.717645943f, 0.722621918f, 0.727573872f, 0.732501209f, 0.737403393f, 0.742279828f, 0.747129917f,
        0.751953125f, 0.756748855f, 0.761516571f, 0.766255677f, 0.770965576f, 0.775645733f, 0.780295551f, 0.784914494f,
        0.789501965f, 0.794057369f, 0.79858017f, 0.80306977f, 0.807525635f, 0.811947167f, 0.816333771f, 0.82068491f,
        0.824999988f, 0.829278469f, 0.833519757f, 0.837723255f, 0.841888428f, 0.846014678f, 0.850101471f, 0.854148209f,
        0.858154297f, 0.862119198f, 0.866042316f, 0.869923115f, 0.873760998f, 0.87755537f, 0.881305695f, 0.885011375f,
        0.888671875f, 0.892286599f, 0.89585495f, 0.899376392f, 0.90285033f, 0.906276226f, 0.909653485f, 0.91298151f,
        0.916259766f, 0.919487655f, 0.922664642f, 0.925790131f, 0.928863525f, 0.931884289f, 0.934851825f, 0.937765598f,
        0.940625012f, 0.94342947f, 0.946178436f, 0.948871315f, 0.951507568f, 0.954086602f, 0.956607819f, 0.959070683f,
        0.961474597f, 0.963819027f, 0.966103375f, 0.968327045f, 0.970489502f, 0.972590148f, 0.974628448f, 0.976603806f,
        0.978515625f, 0.980363369f, 0.982146442f, 0.983864307f, 0.985516369f, 0.987102032f, 0.988620758f, 0.990071952f,
        0.991455078f, 0.992769539f, 0.99401474f, 0.995190144f, 0.996295154f, 0.997329235f, 0.99829179f, 0.999182224f,
        1f
    )

    private val OPPO_EMBEDDED_TONE_CURVE_POINTS = floatArrayOf(
        0f, 0f, 0.00787f, 0.00371f, 0.01575f, 0.00959f, 0.02362f, 0.01712f,
        0.0315f, 0.02606f, 0.03937f, 0.03603f, 0.04724f, 0.04693f, 0.05512f, 0.05869f,
        0.06299f, 0.07129f, 0.07087f, 0.0846f, 0.07874f, 0.09835f, 0.08661f, 0.11247f,
        0.09449f, 0.12681f, 0.10236f, 0.14133f, 0.11024f, 0.15596f, 0.11811f, 0.17063f,
        0.12598f, 0.18528f, 0.13386f, 0.1999f, 0.14173f, 0.21448f, 0.14961f, 0.2291f,
        0.15748f, 0.24379f, 0.16535f, 0.25852f, 0.17323f, 0.27328f, 0.1811f, 0.28805f,
        0.18898f, 0.30285f, 0.19685f, 0.31765f, 0.20472f, 0.33242f, 0.2126f, 0.34714f,
        0.22047f, 0.36167f, 0.22835f, 0.37604f, 0.23622f, 0.39025f, 0.24409f, 0.40428f,
        0.25197f, 0.41815f, 0.25984f, 0.43177f, 0.26772f, 0.44515f, 0.27559f, 0.45831f,
        0.28346f, 0.47121f, 0.29134f, 0.48387f, 0.29921f, 0.49631f, 0.30709f, 0.50851f,
        0.31496f, 0.52048f, 0.32283f, 0.53223f, 0.33071f, 0.54377f, 0.33858f, 0.55507f,
        0.34646f, 0.56618f, 0.35433f, 0.57707f, 0.3622f, 0.58775f, 0.37008f, 0.59823f,
        0.37795f, 0.60852f, 0.38583f, 0.6186f, 0.3937f, 0.6285f, 0.40157f, 0.6382f,
        0.40945f, 0.64774f, 0.41732f, 0.65708f, 0.4252f, 0.66624f, 0.43307f, 0.67523f,
        0.44094f, 0.68405f, 0.44882f, 0.69268f, 0.45669f, 0.70115f, 0.46457f, 0.70948f,
        0.47244f, 0.71761f, 0.48031f, 0.72561f, 0.48819f, 0.73346f, 0.49606f, 0.74114f,
        0.50394f, 0.74865f, 0.51181f, 0.75605f, 0.51969f, 0.76326f, 0.52756f, 0.77034f,
        0.53543f, 0.77729f, 0.54331f, 0.7841f, 0.55118f, 0.79078f, 0.55906f, 0.79729f,
        0.56693f, 0.80371f, 0.5748f, 0.80997f, 0.58268f, 0.81611f, 0.59055f, 0.82213f,
        0.59843f, 0.828f, 0.6063f, 0.83377f, 0.61417f, 0.8394f, 0.62205f, 0.84491f,
        0.62992f, 0.85031f, 0.6378f, 0.8556f, 0.64567f, 0.86075f, 0.65354f, 0.86582f,
        0.66142f, 0.87076f, 0.66929f, 0.8756f, 0.67717f, 0.88035f, 0.68504f, 0.88497f,
        0.69291f, 0.88947f, 0.70079f, 0.89389f, 0.70866f, 0.89821f, 0.71654f, 0.90242f,
        0.72441f, 0.90656f, 0.73228f, 0.91055f, 0.74016f, 0.91449f, 0.74803f, 0.91832f,
        0.75591f, 0.92207f, 0.76378f, 0.92571f, 0.77165f, 0.92927f, 0.77953f, 0.93276f,
        0.7874f, 0.93616f, 0.79528f, 0.93947f, 0.80315f, 0.94268f, 0.81102f, 0.9458f,
        0.8189f, 0.94886f, 0.82677f, 0.95186f, 0.83465f, 0.95476f, 0.84252f, 0.9576f,
        0.85039f, 0.96034f, 0.85827f, 0.963f, 0.86614f, 0.96563f, 0.87402f, 0.96816f,
        0.88189f, 0.97061f, 0.88976f, 0.97302f, 0.89764f, 0.97537f, 0.90551f, 0.97762f,
        0.91339f, 0.97981f, 0.92126f, 0.98193f, 0.92913f, 0.98401f, 0.93701f, 0.98603f,
        0.94488f, 0.98796f, 0.95276f, 0.98987f, 0.96063f, 0.99169f, 0.9685f, 0.99349f,
        0.97638f, 0.99517f, 0.98425f, 0.99686f, 0.99213f, 0.99845f, 1f, 1f
    )

    // Larger toe power deepens the lowest shadows; toe width extends that behavior upward.
    // Mid power controls the body contrast. Larger shoulder power softens the approach to white.
    // Balance moves the curve vertically without changing either endpoint.
    private const val PHOTON_PGTM_TOE_POWER = 2.8
    private const val PHOTON_PGTM_TOE_WIDTH = 0.01
    private const val PHOTON_PGTM_MID_POWER = 1
    private const val PHOTON_PGTM_SHOULDER_POWER = 1.15
    private const val PHOTON_PGTM_BALANCE = 0.95

    private val PHOTON_PGTM_TONE_CURVE_LUT by lazy {
        DcpToneCurve(photonPgtmToneCurvePoints()).toLut(256)
    }

    private val GOOGLE_TO_PHOTON_MIDDLE_GRAY_INPUT by lazy {
        val googleMiddleGrayOutput = googleHdrToneCurveOutput(JPG_TONE_CURVE_MIDDLE_GRAY)
        photonPgtmInputForOutput(googleMiddleGrayOutput)
    }

    fun googleHdrToneCurvePoints(): FloatArray {
        return FloatArray(GOOGLE_HDR_TONE_CURVE_Y.size * 2) { index ->
            val pointIndex = index / 2
            if ((index and 1) == 0) {
                pointIndex.toFloat() / (GOOGLE_HDR_TONE_CURVE_Y.size - 1).toFloat()
            } else {
                GOOGLE_HDR_TONE_CURVE_Y[pointIndex]
            }
        }
    }

    fun linearToneCurvePoints(): FloatArray {
        return LINEAR_TONE_CURVE_POINTS.copyOf()
    }

    fun linearToneCurveLut(sampleCount: Int = 256): FloatArray {
        return DcpToneCurve(linearToneCurvePoints()).toLut(sampleCount)
    }

    fun photonPgtmToneCurvePoints(): FloatArray {
        return FloatArray(DNG_PROFILE_TONE_CURVE_POINT_COUNT * 2) { index ->
            val pointIndex = index / 2
            val input = pointIndex.toDouble() / (DNG_PROFILE_TONE_CURVE_POINT_COUNT - 1).toDouble()
            if ((index and 1) == 0) {
                input.toFloat()
            } else {
                photonPgtmToneCurve(input).toFloat()
            }
        }
    }

    private fun photonPgtmToneCurve(input: Double): Double {
        if (input <= 0.0) return 0.0
        if (input >= 1.0) return 1.0

        // n(x) is strictly increasing and s(x) is strictly decreasing for positive parameters.
        // Therefore n(x) / (n(x) + s(x)) is smooth and strictly increasing on (0, 1).
        val normalizedToeInput =
            (input + PHOTON_PGTM_TOE_WIDTH) / (1.0 + PHOTON_PGTM_TOE_WIDTH)
        val toeTransition = normalizedToeInput
            .pow(PHOTON_PGTM_MID_POWER - PHOTON_PGTM_TOE_POWER)
        val numerator = input.pow(PHOTON_PGTM_TOE_POWER) * toeTransition
        val shoulder = PHOTON_PGTM_BALANCE *
            (1.0 - input).pow(PHOTON_PGTM_SHOULDER_POWER)
        return numerator / (numerator + shoulder)
    }

    fun photonPgtmToneCurveLut(sampleCount: Int = 256): FloatArray {
        return if (sampleCount == PHOTON_PGTM_TONE_CURVE_LUT.size) {
            PHOTON_PGTM_TONE_CURVE_LUT.copyOf()
        } else {
            DcpToneCurve(photonPgtmToneCurvePoints()).toLut(sampleCount)
        }
    }

    internal fun photonPgtmInputForOutput(output: Float): Float {
        val target = output.coerceIn(0f, 1f)
        if (target <= 0f) return 0f
        if (target >= 1f) return 1f

        var lower = 0.0
        var upper = 1.0
        repeat(32) {
            val input = (lower + upper) * 0.5
            if (photonPgtmToneCurve(input) < target) {
                lower = input
            } else {
                upper = input
            }
        }
        return ((lower + upper) * 0.5).toFloat()
    }

    /**
     * Builds the input transform used before Photon LUT rendering for MGC-produced JPEGs.
     *
     * MGC's JPEG is sRGB-encoded after Google's profile tone curve. Each sample follows this
     * exact sequence:
     * sRGB -> linear -> inverse Google curve -> middle-gray alignment -> Photon curve -> sRGB.
     *
     * Middle-gray alignment is piecewise linear around 18% gray. It maps Google's linear
     * middle-gray output to the same Photon output while preserving black and white exactly.
     */
    fun googleToPhotonJpegToneCurveLut(sampleCount: Int = 4096): FloatArray {
        require(sampleCount >= 2) { "sampleCount must be at least 2" }
        return FloatArray(sampleCount) { index ->
            val encoded = index / (sampleCount - 1f)
            applyGoogleToPhotonJpegToneCurve(encoded)
        }
    }

    internal fun applyGoogleToPhotonJpegToneCurve(encoded: Float): Float {
        val googleOutputLinear = srgbToLinear(encoded.coerceIn(0f, 1f))
        val googleInputLinear = inverseUniformCurve(
            curve = GOOGLE_HDR_TONE_CURVE_Y,
            output = googleOutputLinear,
        )
        val photonInputLinear = alignGoogleAndPhotonMiddleGray(googleInputLinear)
        val photonOutputLinear = photonPgtmToneCurve(photonInputLinear.toDouble()).toFloat()
        return linearToSrgb(photonOutputLinear).coerceIn(0f, 1f)
    }

    internal fun googleHdrToneCurveOutput(input: Float): Float {
        return sampleUniformCurve(GOOGLE_HDR_TONE_CURVE_Y, input)
    }

    internal fun googleToPhotonMiddleGrayInput(): Float {
        return GOOGLE_TO_PHOTON_MIDDLE_GRAY_INPUT
    }

    private fun alignGoogleAndPhotonMiddleGray(input: Float): Float {
        val sourceMiddleGray = JPG_TONE_CURVE_MIDDLE_GRAY
        val targetMiddleGray = googleToPhotonMiddleGrayInput()
        val clamped = input.coerceIn(0f, 1f)
        return if (clamped <= sourceMiddleGray) {
            clamped * targetMiddleGray / sourceMiddleGray
        } else {
            targetMiddleGray +
                (clamped - sourceMiddleGray) *
                (1f - targetMiddleGray) /
                (1f - sourceMiddleGray)
        }.coerceIn(0f, 1f)
    }

    private fun sampleUniformCurve(curve: FloatArray, input: Float): Float {
        val position = input.coerceIn(0f, 1f) * (curve.size - 1)
        val lowerIndex = position.toInt().coerceIn(0, curve.lastIndex)
        val upperIndex = (lowerIndex + 1).coerceAtMost(curve.lastIndex)
        return curve[lowerIndex] +
            (curve[upperIndex] - curve[lowerIndex]) * (position - lowerIndex)
    }

    private fun inverseUniformCurve(curve: FloatArray, output: Float): Float {
        val target = output.coerceIn(0f, 1f)
        if (target <= curve.first()) return 0f
        if (target >= curve.last()) return 1f

        var lowerIndex = 0
        var upperIndex = curve.lastIndex
        while (lowerIndex + 1 < upperIndex) {
            val middleIndex = (lowerIndex + upperIndex) ushr 1
            if (curve[middleIndex] < target) {
                lowerIndex = middleIndex
            } else {
                upperIndex = middleIndex
            }
        }
        val lower = curve[lowerIndex]
        val upper = curve[upperIndex]
        val amount = if (upper > lower) {
            (target - lower) / (upper - lower)
        } else {
            0f
        }
        return (lowerIndex + amount) / curve.lastIndex.toFloat()
    }

    private fun srgbToLinear(value: Float): Float {
        return if (value <= 0.04045f) {
            value / 12.92f
        } else {
            ((value + 0.055f) / 1.055f).toDouble().pow(2.4).toFloat()
        }
    }

    private fun linearToSrgb(value: Float): Float {
        val clamped = value.coerceAtLeast(0f)
        return if (clamped <= 0.0031308f) {
            clamped * 12.92f
        } else {
            (1.055 * clamped.toDouble().pow(1.0 / 2.4) - 0.055).toFloat()
        }
    }

    fun oppoEmbeddedToneCurvePoints(): FloatArray {
        return OPPO_EMBEDDED_TONE_CURVE_POINTS.copyOf()
    }

    fun oppoEmbeddedToneCurveLut(sampleCount: Int = 256): FloatArray {
        return DcpToneCurve(oppoEmbeddedToneCurvePoints()).toLut(sampleCount)
    }

    fun isOppoEmbeddedToneCurve(toneCurve: DcpToneCurve?): Boolean {
        if (toneCurve?.isValid != true) return false
        val oppoPoints = OPPO_EMBEDDED_TONE_CURVE_POINTS
        if (toneCurve.points.size == oppoPoints.size) {
            return toneCurve.points.indices.all { index ->
                kotlin.math.abs(toneCurve.points[index] - oppoPoints[index]) <= POINT_TOLERANCE
            }
        }
        return isOppoEmbeddedToneCurveLut(toneCurve.toLut())
    }

    fun isLinearToneCurve(toneCurve: DcpToneCurve?): Boolean {
        if (toneCurve?.isValid != true) return false
        val linearPoints = LINEAR_TONE_CURVE_POINTS
        if (toneCurve.points.size == linearPoints.size) {
            return toneCurve.points.indices.all { index ->
                kotlin.math.abs(toneCurve.points[index] - linearPoints[index]) <= POINT_TOLERANCE
            }
        }
        return isLinearToneCurveLut(toneCurve.toLut())
    }

    fun isPhotonPgtmToneCurve(toneCurve: DcpToneCurve?): Boolean {
        if (toneCurve?.isValid != true) return false
        val photonPoints = photonPgtmToneCurvePoints()
        if (toneCurve.points.size == photonPoints.size) {
            return toneCurve.points.indices.all { index ->
                kotlin.math.abs(toneCurve.points[index] - photonPoints[index]) <= POINT_TOLERANCE
            }
        }
        return isPhotonPgtmToneCurveLut(toneCurve.toLut())
    }

    fun isOppoEmbeddedToneCurveLut(lut: FloatArray?): Boolean {
        if (lut == null || lut.isEmpty()) return false
        val oppoLut = oppoEmbeddedToneCurveLut(lut.size)
        return lut.indices.all { index ->
            kotlin.math.abs(lut[index] - oppoLut[index]) <= LUT_TOLERANCE
        }
    }

    fun isLinearToneCurveLut(lut: FloatArray?): Boolean {
        if (lut == null || lut.isEmpty()) return false
        val linearLut = linearToneCurveLut(lut.size)
        return lut.indices.all { index ->
            kotlin.math.abs(lut[index] - linearLut[index]) <= LUT_TOLERANCE
        }
    }

    fun isPhotonPgtmToneCurveLut(lut: FloatArray?): Boolean {
        if (lut == null || lut.isEmpty()) return false
        val photonLut = photonPgtmToneCurveLut(lut.size)
        return lut.indices.all { index ->
            kotlin.math.abs(lut[index] - photonLut[index]) <= LUT_TOLERANCE
        }
    }

}
