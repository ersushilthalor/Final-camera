package com.hinnka.mycamera.raw

import android.graphics.Bitmap
import androidx.annotation.Keep
import java.nio.ByteBuffer

/**
 * DNG RAW 数据容器
 *
 * 从 JNI 层返回，包含解析后的 DNG 文件 RAW 数据和元数据
 *
 * @param rawData RAW 像素数据的 ByteBuffer（注意：使用 native 堆内存，需要手动释放）
 * @param width 图像宽度
 * @param height 图像高度
 * @param rowStride 行跨度（字节）
 * @param samplesPerPixel 每像素样本数：1=CFA，3=LinearRaw RGB
 * @param whiteLevel 白电平值
 * @param blackLevel 黑电平值数组 [R, Gr, Gb, B]
 * @param whiteBalance 白平衡增益 [R, Gr, Gb, B]
 * @param colorMatrix 色彩校正矩阵 (3x3 = 9个元素，行主序)
 * @param cameraWhite DNG SDK 色彩规格在当前白点下计算出的相机空间白色 [R, G, B]
 * @param whitePointXy DNG SDK/LibRaw 相机矩阵与当前 CameraNeutral 解出的白点 xy
 * @param rotation 旋转角度 (0, 90, 180, 270)
 * @param shadowScale DNG ShadowScale，用于 Adobe DefaultBlackRender Auto 的暗部黑点计算
 * @param lensShadingMap Lens Shading Map (LSC) 增益表，null表示无LSC数据
 * @param lensShadingMapWidth LSC 表宽度
 * @param lensShadingMapHeight LSC 表高度
 * @param lensShadingMapGrid DNG GainMap 参数
 * [originH, originV, spacingH, spacingV, boundsLeft, boundsTop, boundsRight, boundsBottom]，
 * null 表示按 Camera2 UV 采样
 * @param defaultCrop DNG DefaultCrop [left, top, right, bottom]，相对于 rawData 有效区
 */
@Keep
data class DngRawData @Keep constructor(
    val rawData: ByteBuffer,
    val width: Int,
    val height: Int,
    val rowStride: Int,
    val samplesPerPixel: Int = 1,
    val whiteLevel: Float,
    val blackLevel: FloatArray,
    val preMul: FloatArray,
    val whiteBalance: FloatArray,
    val colorMatrix: FloatArray,
    val cameraWhite: FloatArray,
    val whitePointXy: FloatArray,
    val cameraMake: String,
    val cameraModel: String,
    val cfaPattern: Int, // 0..3=Bayer, 4..7=4x4 expanded Bayer, 8..11=8x8 expanded Bayer
    val rotation: Int,
    val baselineExposure: Float,
    val shadowScale: Float = 1.0f,
    val lensShadingMap: FloatArray?,
    val lensShadingMapWidth: Int,
    val lensShadingMapHeight: Int,
    val lensShadingMapGrid: FloatArray?,
    val exposureBias: Float,
    val iso: Int,
    val shutterSpeed: Long,
    val aperture: Float,
    val activeArray: IntArray?, // [left, top, right, bottom]
    val defaultCrop: IntArray?, // [left, top, right, bottom] relative to rawData
    val noiseProfile: FloatArray?, // NoiseProfile [S1, O1, S2, O2, ...]
    val warpRectilinear: FloatArray?, // repeated [k0, k1, k2, k3, t0, t1, centerH, centerV]
    val warpRectilinearFlags: IntArray?, // one DNG opcode flags value per warp
    val embeddedPreview: Bitmap? = null,
    /** Embedded source calibration only; null when neither ColorMatrix nor ForwardMatrix is present. */
    val cameraCalibration: RawCameraCalibration? = null,
    /** Provenance for FM-only interpolation: never infer this from LibRaw's matrix-derived xy. */
    val hasAsShotWhiteXy: Boolean = false,
) : AutoCloseable {

    @Volatile
    private var isClosed = false

    /**
     * 释放 native 堆内存
     *
     * 注意：DNG RAW 数据使用 native malloc 分配内存（约 25MB），
     * 处理完成后必须调用 close() 释放，否则会内存泄漏
     */
    override fun close() {
        if (!isClosed) {
            synchronized(this) {
                if (!isClosed) {
                    freeNativeBuffer(rawData)
                    isClosed = true
                }
            }
        }
    }

    /**
     * Native 方法：释放 ByteBuffer 的 native 内存
     */
    private external fun freeNativeBuffer(buffer: ByteBuffer)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as DngRawData

        if (rawData != other.rawData) return false
        if (width != other.width) return false
        if (height != other.height) return false
        if (rowStride != other.rowStride) return false
        if (samplesPerPixel != other.samplesPerPixel) return false
        if (whiteLevel != other.whiteLevel) return false
        if (!blackLevel.contentEquals(other.blackLevel)) return false
        if (!preMul.contentEquals(other.preMul)) return false
        if (!whiteBalance.contentEquals(other.whiteBalance)) return false
        if (!colorMatrix.contentEquals(other.colorMatrix)) return false
        if (!cameraWhite.contentEquals(other.cameraWhite)) return false
        if (!whitePointXy.contentEquals(other.whitePointXy)) return false
        if (cameraMake != other.cameraMake) return false
        if (cameraModel != other.cameraModel) return false
        if (cfaPattern != other.cfaPattern) return false
        if (rotation != other.rotation) return false
        if (baselineExposure != other.baselineExposure) return false
        if (shadowScale != other.shadowScale) return false
        if (lensShadingMap != null) {
            if (other.lensShadingMap == null) return false
            if (!lensShadingMap.contentEquals(other.lensShadingMap)) return false
        } else if (other.lensShadingMap != null) return false
        if (lensShadingMapWidth != other.lensShadingMapWidth) return false
        if (lensShadingMapHeight != other.lensShadingMapHeight) return false
        if (lensShadingMapGrid != null) {
            if (other.lensShadingMapGrid == null) return false
            if (!lensShadingMapGrid.contentEquals(other.lensShadingMapGrid)) return false
        } else if (other.lensShadingMapGrid != null) return false
        if (defaultCrop != null) {
            if (other.defaultCrop == null) return false
            if (!defaultCrop.contentEquals(other.defaultCrop)) return false
        } else if (other.defaultCrop != null) return false
        if (warpRectilinear != null) {
            if (other.warpRectilinear == null) return false
            if (!warpRectilinear.contentEquals(other.warpRectilinear)) return false
        } else if (other.warpRectilinear != null) return false
        if (warpRectilinearFlags != null) {
            if (other.warpRectilinearFlags == null) return false
            if (!warpRectilinearFlags.contentEquals(other.warpRectilinearFlags)) return false
        } else if (other.warpRectilinearFlags != null) return false
        if (embeddedPreview != null) {
            if (other.embeddedPreview == null) return false
            if (!embeddedPreview.sameAs(other.embeddedPreview)) return false
        } else if (other.embeddedPreview != null) return false
        if (cameraCalibration != other.cameraCalibration) return false
        if (hasAsShotWhiteXy != other.hasAsShotWhiteXy) return false

        return true
    }

    override fun hashCode(): Int {
        var result = rawData.hashCode()
        result = 31 * result + width
        result = 31 * result + height
        result = 31 * result + rowStride
        result = 31 * result + samplesPerPixel
        result = 31 * result + whiteLevel.hashCode()
        result = 31 * result + blackLevel.contentHashCode()
        result = 31 * result + preMul.contentHashCode()
        result = 31 * result + whiteBalance.contentHashCode()
        result = 31 * result + colorMatrix.contentHashCode()
        result = 31 * result + cameraWhite.contentHashCode()
        result = 31 * result + whitePointXy.contentHashCode()
        result = 31 * result + cameraMake.hashCode()
        result = 31 * result + cameraModel.hashCode()
        result = 31 * result + cfaPattern
        result = 31 * result + rotation
        result = 31 * result + baselineExposure.hashCode()
        result = 31 * result + shadowScale.hashCode()
        result = 31 * result + (lensShadingMap?.contentHashCode() ?: 0)
        result = 31 * result + lensShadingMapWidth
        result = 31 * result + lensShadingMapHeight
        result = 31 * result + (lensShadingMapGrid?.contentHashCode() ?: 0)
        result = 31 * result + (defaultCrop?.contentHashCode() ?: 0)
        result = 31 * result + (warpRectilinear?.contentHashCode() ?: 0)
        result = 31 * result + (warpRectilinearFlags?.contentHashCode() ?: 0)
        result = 31 * result + (embeddedPreview?.hashCode() ?: 0)
        result = 31 * result + (cameraCalibration?.hashCode() ?: 0)
        result = 31 * result + hasAsShotWhiteXy.hashCode()
        return result
    }

    protected fun finalize() {
        // 作为保险措施，如果忘记调用 close() 也能清理
        // 但不应该依赖 finalize，应该显式调用 close()
        if (!isClosed) {
            close()
        }
    }
}
