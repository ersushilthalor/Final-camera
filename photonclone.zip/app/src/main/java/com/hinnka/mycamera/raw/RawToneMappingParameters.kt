package com.hinnka.mycamera.raw

data class RawToneMappingParameters(
    val agxBlackRelativeExposure: Float = AGX_BLACK_RELATIVE_EXPOSURE_DEFAULT,
    val agxWhiteRelativeExposure: Float = AGX_WHITE_RELATIVE_EXPOSURE_DEFAULT,
    val agxToe: Float = AGX_TOE_DEFAULT,
    val agxShoulder: Float = AGX_SHOULDER_DEFAULT,
    val filmicBlackRelativeExposure: Float = FILMIC_BLACK_RELATIVE_EXPOSURE_DEFAULT,
    val filmicWhiteRelativeExposure: Float = FILMIC_WHITE_RELATIVE_EXPOSURE_DEFAULT,
    val useProfileToneMap: Boolean = true,
    val useOppoMasterToneMap: Boolean = false,
    val usePhotonHdr: Boolean = PHOTON_HDR_DEFAULT,
    val lumixPhotoStyle: LumixPhotoStyle = LumixPhotoStyle.Standard,
    val canonPictureStyle: CanonPictureStyle = CanonPictureStyle.Standard,
    val canonExposureCompensationEv: Float = CANON_EXPOSURE_COMPENSATION_DEFAULT,
    val lumixColorMatchingEnabled: Boolean = true,
    val hncsColorMatchingEnabled: Boolean = true,
    /** Use EOS R5 sensor calibration directly instead of the capture device calibration. */
    val canonUseR5ColorMatrix: Boolean = false,
    /** Use M9 sensor calibration directly instead of the capture device calibration. */
    val leicaUseM9ColorMatrix: Boolean = false,
) {
    /** Explicit engine adjustment, applied once after PGTM with the shared render exposure. */
    fun engineExposureCompensationEv(engine: RawRenderingEngine): Float =
        if (engine.isCanon) normalizeCanonExposureCompensation(canonExposureCompensationEv) else 0f

    fun colorMatchingEnabled(engine: RawRenderingEngine): Boolean = when {
        engine.isLumix -> lumixColorMatchingEnabled
        engine.isHncs -> hncsColorMatchingEnabled
        engine.isCanon -> !canonUseR5ColorMatrix
        engine.isLeica -> !leicaUseM9ColorMatrix
        else -> false
    }

    val profileToneMapMode: RawProfileToneMapMode
        get() = when {
            useOppoMasterToneMap -> RawProfileToneMapMode.OppoMaster
            useProfileToneMap -> RawProfileToneMapMode.Profile
            else -> RawProfileToneMapMode.Default
        }

    fun normalized(): RawToneMappingParameters {
        val blackAgx = agxBlackRelativeExposure.coerceIn(
            AGX_BLACK_RELATIVE_EXPOSURE_MIN,
            AGX_BLACK_RELATIVE_EXPOSURE_MAX
        )
        val whiteAgx = agxWhiteRelativeExposure.coerceIn(
            AGX_WHITE_RELATIVE_EXPOSURE_MIN,
            AGX_WHITE_RELATIVE_EXPOSURE_MAX
        )
        val blackFilmic = filmicBlackRelativeExposure.coerceIn(
            FILMIC_BLACK_RELATIVE_EXPOSURE_MIN,
            FILMIC_BLACK_RELATIVE_EXPOSURE_MAX
        )
        val whiteFilmic = filmicWhiteRelativeExposure.coerceIn(
            FILMIC_WHITE_RELATIVE_EXPOSURE_MIN,
            FILMIC_WHITE_RELATIVE_EXPOSURE_MAX
        )
        return copy(
            canonExposureCompensationEv = normalizeCanonExposureCompensation(canonExposureCompensationEv),
            agxBlackRelativeExposure = minOf(blackAgx, whiteAgx - MIN_DYNAMIC_RANGE_EV),
            agxWhiteRelativeExposure = maxOf(whiteAgx, blackAgx + MIN_DYNAMIC_RANGE_EV),
            agxToe = agxToe.coerceIn(AGX_TOE_MIN, AGX_TOE_MAX),
            agxShoulder = agxShoulder.coerceIn(AGX_SHOULDER_MIN, AGX_SHOULDER_MAX),
            filmicBlackRelativeExposure = minOf(blackFilmic, whiteFilmic - MIN_DYNAMIC_RANGE_EV),
            filmicWhiteRelativeExposure = maxOf(whiteFilmic, blackFilmic + MIN_DYNAMIC_RANGE_EV)
        )
    }

    fun withOppoMasterToneMap(enabled: Boolean): RawToneMappingParameters {
        return copy(
            useOppoMasterToneMap = enabled
        ).normalized()
    }

    fun withPhotonHdr(enabled: Boolean): RawToneMappingParameters {
        return copy(usePhotonHdr = enabled).normalized()
    }

    fun withProfileToneMapMode(mode: RawProfileToneMapMode): RawToneMappingParameters {
        return copy(
            useProfileToneMap = mode == RawProfileToneMapMode.Profile,
            useOppoMasterToneMap = mode == RawProfileToneMapMode.OppoMaster
        ).normalized()
    }

    companion object {
        const val CANON_EXPOSURE_COMPENSATION_DEFAULT = -0.5f
        const val CANON_EXPOSURE_COMPENSATION_MIN = -4f
        const val CANON_EXPOSURE_COMPENSATION_MAX = 4f

        fun normalizeCanonExposureCompensation(value: Float): Float =
            if (value.isFinite()) value.coerceIn(CANON_EXPOSURE_COMPENSATION_MIN, CANON_EXPOSURE_COMPENSATION_MAX)
            else CANON_EXPOSURE_COMPENSATION_DEFAULT

        const val PHOTON_HDR_DEFAULT = true
        const val MIN_DYNAMIC_RANGE_EV = 0.2f

        const val AGX_BLACK_RELATIVE_EXPOSURE_MIN = -20f
        const val AGX_BLACK_RELATIVE_EXPOSURE_MAX = -0.1f
        const val AGX_BLACK_RELATIVE_EXPOSURE_DEFAULT = -10f
        const val AGX_WHITE_RELATIVE_EXPOSURE_MIN = 0.1f
        const val AGX_WHITE_RELATIVE_EXPOSURE_MAX = 20f
        const val AGX_WHITE_RELATIVE_EXPOSURE_DEFAULT = 6.5f
        const val AGX_TOE_MIN = 0.01f
        const val AGX_TOE_MAX = 10f
        const val AGX_TOE_DEFAULT = 1.5f
        const val AGX_SHOULDER_MIN = 0.01f
        const val AGX_SHOULDER_MAX = 10f
        const val AGX_SHOULDER_DEFAULT = 3.3f

        const val FILMIC_BLACK_RELATIVE_EXPOSURE_MIN = -16f
        const val FILMIC_BLACK_RELATIVE_EXPOSURE_MAX = -0.1f
        const val FILMIC_BLACK_RELATIVE_EXPOSURE_DEFAULT = -7.65f
        const val FILMIC_WHITE_RELATIVE_EXPOSURE_MIN = 0.1f
        const val FILMIC_WHITE_RELATIVE_EXPOSURE_MAX = 16f
        const val FILMIC_WHITE_RELATIVE_EXPOSURE_DEFAULT = 4.56f

        val DEFAULT = RawToneMappingParameters()
    }
}
