package com.hinnka.mycamera.ui.camera

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.os.Environment
import android.os.SystemClock
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.paint
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import coil.compose.AsyncImage
import com.hinnka.mycamera.ui.theme.AccentColor
import com.hinnka.mycamera.ui.theme.accentContentColor
import com.hinnka.mycamera.MyCameraApplication
import com.hinnka.mycamera.R
import com.hinnka.mycamera.camera.AspectRatio
import com.hinnka.mycamera.camera.CameraInfo
import com.hinnka.mycamera.camera.CameraState
import com.hinnka.mycamera.camera.FocusPointSource
import com.hinnka.mycamera.camera.PhotoCaptureProgress
import com.hinnka.mycamera.data.CaptureButtonStyle
import com.hinnka.mycamera.data.DevelopAnimationStyle
import com.hinnka.mycamera.model.CameraPreset
import com.hinnka.mycamera.model.ColorRecipeParams
import com.hinnka.mycamera.model.LutSelectorMode
import com.hinnka.mycamera.raw.SpectralFilmSelection
import com.hinnka.mycamera.ui.components.*
import com.hinnka.mycamera.utils.OrientationObserver
import com.hinnka.mycamera.viewmodel.CameraViewModel
import com.hinnka.mycamera.viewmodel.GalleryViewModel
import com.hinnka.mycamera.video.CaptureMode
import com.hinnka.mycamera.video.VideoAspectRatio
import com.hinnka.mycamera.video.VideoFpsPreset
import com.hinnka.mycamera.video.VideoLogProfile
import com.hinnka.mycamera.video.VideoResolutionPreset
import com.hinnka.mycamera.video.VideoStabilizationMode
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.isActive
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.*
import com.hinnka.mycamera.ui.icons.AppIcons

/**
 * 主相机界面
 */
enum class ActivePanel {
    NONE,
    SETTINGS,
    FILTERS,
    EDIT,
    PRESETS
}

private enum class CameraShootingMode {
    PROFESSIONAL,
    PHOTO,
    VIDEO
}

private const val InitialPreviewTransitionDelayMillis = 150L
private const val PreviewTransitionRevealDurationMillis = 800
private const val ZoomStopAnimationCompletionThreshold = 0.001f
private const val RawCaptureTapDebounceMillis = 1000L
private const val DefaultShutterSpeedNs = 1_000_000_000f / 60f
private const val DefaultIso = 100f
private const val DefaultAwbTemperature = 5000f
private const val DefaultFocusDistance = 0f
private val CameraTopBarBaseTopPadding = 32.dp
private val CameraTopBarBaseHeight = 80.dp
private val VideoTopBarBaseHeight = 80.dp
private val VideoTopBarLoweredOffset = 36.dp
private val XpanViewfinderInnerBorder = 4.dp
private val XpanSideControlReservedWidth = 56.dp

private fun formatVirtualApertureFStop(aperture: Float): String {
    val rounded = aperture.roundToInt()
    return if (aperture == rounded.toFloat()) rounded.toString() else aperture.toString()
}

@Composable
private fun cameraTopSafePadding(): Dp {
    val density = LocalDensity.current
    val topInset = with(density) {
        maxOf(
            WindowInsets.statusBars.getTop(this).toDp(),
            WindowInsets.displayCutout.getTop(this).toDp()
        )
    }
    return (topInset - CameraTopBarBaseTopPadding).coerceAtLeast(0.dp)
}

private fun Bitmap.copyForCaptureAnimation(): Bitmap? {
    if (isRecycled) return null
    val copyConfig = if (config == Bitmap.Config.HARDWARE) {
        Bitmap.Config.ARGB_8888
    } else {
        config ?: Bitmap.Config.ARGB_8888
    }
    return copy(copyConfig, false) ?: copy(Bitmap.Config.ARGB_8888, false)
}

private fun Bitmap.recycleIfAlive() {
    if (!isRecycled) {
        recycle()
    }
}

@Composable
private fun PanelDismissPreviewOverlay(
    bounds: Rect?,
    parentBounds: Rect?,
    dimBackground: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bounds = bounds ?: return
    if (bounds.width <= 0f || bounds.height <= 0f) return

    val currentOnDismiss by rememberUpdatedState(onDismiss)
    val density = LocalDensity.current
    val parentLeft = parentBounds?.left ?: 0f
    val parentTop = parentBounds?.top ?: 0f
    val width = with(density) { bounds.width.toDp() }
    val height = with(density) { bounds.height.toDp() }

    Box(
        modifier = modifier
            .offset {
                IntOffset(
                    x = (bounds.left - parentLeft).roundToInt(),
                    y = (bounds.top - parentTop).roundToInt()
                )
            }
            .size(width = width, height = height)
            .then(
                if (dimBackground) {
                    Modifier.background(Color.Black.copy(alpha = 0.4f))
                } else {
                    Modifier
                }
            )
            .pointerInput(Unit) {
                detectTapGestures {
                    currentOnDismiss()
                }
            }
    )
}

private fun CameraParameter.defaultResetValue(): Float {
    return when (this) {
        CameraParameter.EXPOSURE_COMPENSATION -> 0f
        CameraParameter.SHUTTER_SPEED -> DefaultShutterSpeedNs
        CameraParameter.ISO -> DefaultIso
        CameraParameter.FOCUS -> DefaultFocusDistance
        CameraParameter.WHITE_BALANCE -> DefaultAwbTemperature
    }
}

@Composable
fun CameraScreen(
    viewModel: CameraViewModel,
    galleryViewModel: GalleryViewModel,
    onGalleryClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onFilterManagementClick: (String?) -> Unit,
    onFrameManagementClick: () -> Unit,
    onToolboxClick: () -> Unit,
    onPresetEditClick: (String?) -> Unit,
    onPresetManagementClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by viewModel.state.collectAsState()
    val uiStyle by viewModel.uiStyle.collectAsState()
    val isCameraInitialized by viewModel.isInitialized.collectAsState()
    val latestPhoto by galleryViewModel.latestPhoto.collectAsState()
    val showLevelIndicator by viewModel.showLevelIndicator.collectAsState(initial = false)
    val focusPeakingEnabled by viewModel.focusPeakingEnabled.collectAsState(initial = true)
    val eyeFocusEnabled by viewModel.eyeFocusEnabled.collectAsState()
    val keepScreenOn by viewModel.keepScreenOn.collectAsState(initial = false)
    val currentLutId by viewModel.currentLutId.collectAsState()
    val lutNameOverlayState = rememberLutNameOverlayState()
    val currentRecipeParams by viewModel.currentRecipeParams.collectAsState()
    val lutSelectorMode by viewModel.lutSelectorMode.collectAsState()
    val activePresetId by viewModel.activePresetId.collectAsState()
    val activePresetModified by viewModel.isActivePresetModified.collectAsState()
    val customPresets by viewModel.customPresets.collectAsState()
    val currentBaselineRecipeParams by viewModel.currentBaselineRecipeParams.collectAsState()
    val categoryOrder by viewModel.categoryOrder.collectAsState(emptyList())
    val useRaw by viewModel.useRaw.collectAsState()
    val useJpgMax by viewModel.useJpgMax.collectAsState()
    val useMultipleExposure by viewModel.useMultipleExposure.collectAsState()
    val useRawMax by viewModel.useRawMax.collectAsState()
    val ultraHdrEnabled by viewModel.ultraHdrGainMapEnabled.collectAsState()
    val useLivePhoto by viewModel.useLivePhoto.collectAsState()
    val enableDevelopAnimation by viewModel.enableDevelopAnimation.collectAsState()
    val developAnimationStyle by viewModel.developAnimationStyle.collectAsState()
    val phantomMode by viewModel.phantomMode.collectAsState()
    val topSheetAspectRatios by viewModel.topSheetAspectRatios.collectAsState()
    val videoCodec by viewModel.videoCodec.collectAsState()
    val videoAudioInputOptions by viewModel.videoAudioInputOptions.collectAsState()
    val phantomPipPreview by viewModel.phantomPipPreview.collectAsState()
    val rawDcpId by viewModel.rawDcpId.collectAsState()
    val rawDcpIdsByLens by viewModel.rawDcpIdsByLens.collectAsState()
    val rawHncsFilmCurveMode by viewModel.rawHncsFilmCurveMode.collectAsState()
    val rawColorEngine by viewModel.rawRenderingEngine.collectAsState()
    val rawToneMappingParameters by viewModel.rawToneMappingParameters.collectAsState()
    val rawSpectralFilmStock by viewModel.rawSpectralFilmStock.collectAsState()
    val rawSpectralFilmSelection by viewModel.rawSpectralFilmSelection.collectAsState()
    val rawSpectralFilmPrint by viewModel.rawSpectralFilmPrint.collectAsState()
    val multipleExposureState = viewModel.multipleExposureState
    val canStartShutterAnimation by viewModel.canStartShutterAnimation.collectAsState()
    val currentCaptureModeForEffects by rememberUpdatedState(state.captureMode)
    var previewRecipeParamsOverride by remember(currentLutId, activePresetId) {
        mutableStateOf<ColorRecipeParams?>(null)
    }
    var pendingCaptureAnimationBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var captureAnimationJob by remember { mutableStateOf<Job?>(null) }
    var cameraScreenBounds by remember { mutableStateOf<Rect?>(null) }
    var previewBounds by remember { mutableStateOf<Rect?>(null) }
    var viewfinderAreaBounds by remember { mutableStateOf<Rect?>(null) }
    var zoomBarBounds by remember { mutableStateOf<Rect?>(null) }
    var filterButtonBounds by remember { mutableStateOf<Rect?>(null) }
    var captureButtonBounds by remember { mutableStateOf<Rect?>(null) }
    var parameterRulerBounds by remember { mutableStateOf<Rect?>(null) }
    var galleryThumbnailBounds by remember { mutableStateOf<Rect?>(null) }
    var captureAnimationSnapshot by remember { mutableStateOf<CaptureAnimationSnapshot?>(null) }
    var previewTransitionActive by remember { mutableStateOf(true) }
    var previewTransitionRevealing by remember { mutableStateOf(false) }
    var previewTransitionToken by remember { mutableIntStateOf(0) }
    var previewTransitionAwaitingResume by remember { mutableStateOf(false) }
    var previewTransitionSawPause by remember { mutableStateOf(false) }
    var hasPlayedInitialPreviewTransition by remember { mutableStateOf(false) }
    var rawCaptureTapLocked by remember { mutableStateOf(false) }
    var zoomStopAnimationJob by remember { mutableStateOf<Job?>(null) }
    val lensSwitchTransition = remember(viewModel, scope) { LensSwitchTransitionState(scope, viewModel) }

    DisposableEffect(lensSwitchTransition) {
        onDispose { lensSwitchTransition.cancel() }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) {
        lensSwitchTransition.cancel()
    }

    fun discardTransientLookEdits() {
        previewRecipeParamsOverride = null
    }

    LaunchedEffect(currentRecipeParams) {
        if (previewRecipeParamsOverride?.isSameAs(currentRecipeParams) == true) {
            previewRecipeParamsOverride = null
        }
    }

    // Surface may become ready while persisted camera settings are still being restored.
    // Retain the exact instance and open only after initialization has completed.
    var previewSurfaceTexture by remember { mutableStateOf<SurfaceTexture?>(null) }
    var isCameraPrepared by remember { mutableStateOf(false) }

    LaunchedEffect(isCameraInitialized) {
        isCameraPrepared = isCameraInitialized && viewModel.prepareCamera()
    }

    LaunchedEffect(
        isCameraInitialized,
        isCameraPrepared,
        previewSurfaceTexture,
    ) {
        val surfaceTexture = previewSurfaceTexture ?: return@LaunchedEffect
        if (!isCameraInitialized || !isCameraPrepared) return@LaunchedEffect
        viewModel.openCamera(surfaceTexture)
    }

    // UI State
    var activePanel by remember { mutableStateOf(ActivePanel.NONE) }
    var selectedParameter by remember { mutableStateOf(CameraParameter.EXPOSURE_COMPENSATION) }
    var showParameterRuler by remember(state.captureMode, state.useRaw) { mutableStateOf(false) }
    val isXpan = state.aspectRatio == AspectRatio.XPAN
    val burstCapturingCount = viewModel.burstImageCount

    var isGhostPermissionFlowActive by remember { mutableStateOf(false) }
    val activity = remember(context) { context.findActivity() }

    val ghostLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
        onResult = { _ ->
            // Results are handled via the ON_RESUME lifecycle effect to avoid self-reference issues
        }
    )

    val dcpImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments(),
        onResult = { uris ->
            if (uris.isNotEmpty()) {
                viewModel.importRawDcps(uris) { _, _ -> }
            }
        }
    )

    // 当打开滤镜面板时，生成预览图
    LaunchedEffect(activePanel) {
        if (activePanel == ActivePanel.FILTERS) {
            viewModel.generateThumbnail()
        }
    }

    LaunchedEffect(state.useRaw, state.captureMode) {
        if (!state.useRaw || state.captureMode != CaptureMode.PHOTO) {
            rawCaptureTapLocked = false
        }
    }

    // 从后台返回时检查并恢复相机，刷新最新照片
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.checkAndRecoverCamera()
        viewModel.refreshLocationOnResume()
        galleryViewModel.refreshLatestPhoto()

        // Handle automated ghost mode permission sequence
        if (isGhostPermissionFlowActive) {
            val hasOverlay = Settings.canDrawOverlays(context)
            val hasFiles = Environment.isExternalStorageManager()

            if (hasOverlay && !hasFiles) {
                // Overlay granted, now request files
                ghostLauncher.launch(
                    Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        ("package:${context.packageName}").toUri()
                    )
                )
            } else if (hasOverlay) {
                // All permissions granted
                isGhostPermissionFlowActive = false
                if (!phantomMode) {
                    viewModel.togglePhantomMode()
                }
            } else {
                // If overlay is still missing after returning, user might have cancelled
                // We stop the automatic flow to avoid getting stuck
                isGhostPermissionFlowActive = false
            }
        }

        viewModel.updateLut()
    }

    DisposableEffect(Unit) {
        onDispose {
            pendingCaptureAnimationBitmap?.recycleIfAlive()
            pendingCaptureAnimationBitmap = null
            captureAnimationJob?.cancel()
        }
    }

    LaunchedEffect(enableDevelopAnimation, state.captureMode) {
        if (!enableDevelopAnimation || state.captureMode != CaptureMode.PHOTO) {
            pendingCaptureAnimationBitmap?.recycleIfAlive()
            pendingCaptureAnimationBitmap = null
            captureAnimationJob?.cancel()
            captureAnimationSnapshot = null
        }
    }

    // 监听照片保存完成事件，立即刷新缩略图
    LaunchedEffect(Unit) {
        viewModel.imageSavedEvent.collect {
            galleryViewModel.refreshLatestPhoto()
            MyCameraApplication.updateWidgets(context)
        }
    }

    // 显影在拍摄请求完成时开始，不等待图像处理或保存。
    LaunchedEffect(Unit) {
        viewModel.captureCompletedEvent.collect { metadata ->
            if (!enableDevelopAnimation || currentCaptureModeForEffects != CaptureMode.PHOTO) {
                pendingCaptureAnimationBitmap?.recycleIfAlive()
                pendingCaptureAnimationBitmap = null
                captureAnimationSnapshot = null
                return@collect
            }
            val rootOffset = cameraScreenBounds?.topLeft ?: androidx.compose.ui.geometry.Offset.Zero
            val sourceBounds = previewBounds?.translate(-rootOffset)
            val targetBounds = galleryThumbnailBounds?.translate(-rootOffset)
            val animationStyle = developAnimationStyle

            fun startCaptureAnimation(bitmap: Bitmap) {
                if (sourceBounds == null || targetBounds == null || !scope.isActive ||
                    !enableDevelopAnimation || currentCaptureModeForEffects != CaptureMode.PHOTO
                ) {
                    bitmap.recycleIfAlive()
                    return
                }
                captureAnimationJob?.cancel()
                captureAnimationJob = scope.launch {
                    var processedBitmap: Bitmap? = null
                    try {
                        processedBitmap = if (animationStyle == DevelopAnimationStyle.INSTANT_PRINT) {
                            viewModel.renderCaptureAnimationFrame(bitmap, metadata)
                        } else {
                            viewModel.applyLut(bitmap)
                        }
                        processedBitmap.copyForCaptureAnimation()?.let {
                            captureAnimationSnapshot = CaptureAnimationSnapshot(
                                bitmap = it.asImageBitmap(),
                                sourceBounds = sourceBounds,
                                targetBounds = targetBounds,
                                style = animationStyle
                            )
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        com.hinnka.mycamera.utils.PLog.e("CaptureAnimation", "Failed to prepare capture animation", e)
                    } finally {
                        processedBitmap?.recycleIfAlive()
                        if (processedBitmap !== bitmap) bitmap.recycleIfAlive()
                    }
                }
            }

            pendingCaptureAnimationBitmap?.let(::startCaptureAnimation)
                ?: viewModel.glSurfaceView?.capturePreviewFrame(::startCaptureAnimation)
            pendingCaptureAnimationBitmap = null
        }
    }

    val previewSize = state.currentPreviewSize
    val previewAspectRatio = state.getPreviewAspectRatio()
    val previewTransitionCoverFractionState = animateFloatAsState(
        targetValue = when {
            previewTransitionActive && !previewTransitionRevealing -> 1f
            previewTransitionActive -> 0f
            else -> 0f
        },
        animationSpec = if (previewTransitionActive && !previewTransitionRevealing) {
            snap()
        } else {
            tween(
                durationMillis = PreviewTransitionRevealDurationMillis,
                easing = FastOutSlowInEasing
            )
        },
        label = "previewTransitionCoverFraction"
    )
    val previewTransitionCoverFraction = previewTransitionCoverFractionState.value

    fun cancelZoomStopAnimation() {
        zoomStopAnimationJob?.cancel()
        zoomStopAnimationJob = null
    }

    fun animateCurrentLensToZoomStop(targetZoom: Float) {
        cancelZoomStopAnimation()
        val startZoom = viewModel.zoomRatioByMain
        if (abs(startZoom - targetZoom) <= ZoomStopAnimationCompletionThreshold) {
            viewModel.setZoomRatio(targetZoom)
            return
        }
        zoomStopAnimationJob = scope.launch {
            val progress = Animatable(0f)
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(
                    durationMillis = resolveZoomStopAnimationDurationMillis(startZoom, targetZoom),
                    easing = FastOutSlowInEasing
                )
            ) {
                viewModel.setZoomRatio(
                    interpolateZoomRatio(
                        startZoom = startZoom,
                        targetZoom = targetZoom,
                        progress = value
                    )
                )
            }
            viewModel.setZoomRatio(targetZoom)
        }
    }

    /**
     * Oppo-style zoom hand-off: animate the real Camera2 zoom value for one 400 ms
     * timeline and switch optical lenses only when their visible zoom stop is crossed.
     * The frozen preview overlay protects the short Camera2 session reconfiguration;
     * it does not replace the live zoom commands sent to the active camera.
     */
    fun animateZoomAcrossLensStops(targetZoom: Float, finalCameraHint: CameraInfo? = null) {
        cancelZoomStopAnimation()
        val currentCamera = state.getCurrentCameraInfo()
        val startZoom = viewModel.zoomRatioByMain
        if (currentCamera == null || !targetZoom.isFinite() || targetZoom <= 0f ||
            abs(startZoom - targetZoom) <= ZoomStopAnimationCompletionThreshold
        ) {
            if (finalCameraHint != null && finalCameraHint.cameraId != currentCamera?.cameraId) {
                lensSwitchTransition.switchLens(finalCameraHint.cameraId, targetZoom) {
                    viewModel.switchToLensAndSetZoomRatio(finalCameraHint.cameraId, targetZoom)
                }
            } else {
                animateCurrentLensToZoomStop(targetZoom)
            }
            return
        }

        val cameras = state.availableCameras.filter {
            it.lensFacing == currentCamera.lensFacing &&
                it.displayIntrinsicZoomRatio.isFinite() &&
                it.displayIntrinsicZoomRatio > 0f
        }
        val ascending = targetZoom > startZoom
        val candidateStops = cameras
            .map { it.displayIntrinsicZoomRatio }
            .distinctBy { (it * 100f).roundToInt() }
            .filter { stop ->
                if (ascending) {
                    stop > startZoom + 0.005f && stop <= targetZoom + 0.005f
                } else {
                    // Switch just below an optical stop when zooming out, preserving the
                    // same field of view on the outgoing and incoming sensors.
                    stop <= startZoom + 0.005f && stop > targetZoom + 0.01f
                }
            }
            // findOptimalLens allows a 0.01x tie tolerance. On zoom-out the boundary
            // must sit at least 0.02x below the old optical stop, otherwise the old lens
            // remains eligible and the switch is postponed until the final preset endpoint.
            .map { if (ascending) it else it - 0.02f }
            .filter { if (ascending) it <= targetZoom + 0.005f else it >= targetZoom - 0.005f }
            .sortedWith(if (ascending) compareBy<Float> { it } else compareByDescending<Float> { it })

        val steps = mutableListOf<Pair<Float, CameraInfo>>()
        var plannedCameraId = currentCamera.cameraId
        for (stopZoom in candidateStops) {
            val candidate = viewModel.findOptimalLens(stopZoom, cameras, plannedCameraId) ?: continue
            if (candidate.cameraId != plannedCameraId) {
                steps += stopZoom to candidate
                plannedCameraId = candidate.cameraId
            }
        }
        val finalCamera = finalCameraHint ?: viewModel.findOptimalLens(
            targetZoom,
            state.availableCameras,
            plannedCameraId
        )
        if (finalCamera != null && finalCamera.cameraId != plannedCameraId) {
            steps += targetZoom to finalCamera
        }
        if (steps.isEmpty()) {
            if (finalCamera != null && finalCamera.cameraId != currentCamera.cameraId) {
                lensSwitchTransition.switchLens(finalCamera.cameraId, targetZoom) {
                    viewModel.switchToLensAndSetZoomRatio(finalCamera.cameraId, targetZoom)
                }
            } else {
                animateCurrentLensToZoomStop(targetZoom)
            }
            return
        }

        val firstStep = steps.first()
        lensSwitchTransition.switchLens(firstStep.second.cameraId, targetZoom) {
            zoomStopAnimationJob = scope.launch {
                val progress = Animatable(0f)
                var nextStepIndex = 0
                var requestedCameraId = currentCamera.cameraId
                progress.animateTo(
                    targetValue = 1f,
                    animationSpec = tween(
                        durationMillis = 400,
                        easing = FastOutSlowInEasing
                    )
                ) {
                    val ratio = interpolateZoomRatio(startZoom, targetZoom, value)
                    // Keep the zoom continuous on the live sensor and process any optical
                    // boundary crossed by this frame before committing this frame's ratio.
                    while (nextStepIndex < steps.size) {
                        val (boundaryZoom, camera) = steps[nextStepIndex]
                        val crossed = if (ascending) {
                            ratio >= boundaryZoom - 0.005f
                        } else {
                            ratio <= boundaryZoom + 0.005f
                        }
                        if (!crossed) break

                        if (camera.cameraId != requestedCameraId) {
                            if (nextStepIndex == 0) {
                                // The first transition is already displaying the frozen outgoing
                                // frame and waiting for this camera; only hand over the device here.
                                viewModel.switchToLensAndSetZoomRatio(camera.cameraId, boundaryZoom)
                            } else {
                                // Additional physical stops (for example UW -> Main -> Tele)
                                // each get their own real camera hand-off, not just a UI zoom.
                                lensSwitchTransition.switchLens(camera.cameraId, targetZoom) {
                                    // This queued switch may run after the zoom timeline has advanced
                                    // past the boundary while the previous camera was reopening.
                                    // Preserve the live user-visible zoom instead of snapping back.
                                    viewModel.switchToLensAndSetZoomRatio(
                                        camera.cameraId,
                                        viewModel.zoomRatioByMain
                                    )
                                }
                            }
                            requestedCameraId = camera.cameraId
                        }
                        nextStepIndex++
                    }
                    // Reapply the interpolated value after any stop-triggered camera selection.
                    viewModel.setZoomRatio(ratio)
                }
                viewModel.setZoomRatio(targetZoom)
            }
        }
    }

    fun runPreviewTransition(onSwitch: () -> Unit) {
        cancelZoomStopAnimation()
        lensSwitchTransition.cancel()
        previewTransitionActive = true
        previewTransitionRevealing = false
        previewTransitionToken += 1
        previewTransitionAwaitingResume = true
        previewTransitionSawPause = false
        scope.launch {
            withFrameNanos { }
            onSwitch()
        }
    }

    fun switchToLensWithPreviewTransition(cameraId: String) {
        lensSwitchTransition.cancelPendingSwitch()
        if (cameraId == state.getCurrentCameraInfo()?.cameraId) return
        val targetCamera = state.availableCameras.firstOrNull { it.cameraId == cameraId } ?: return
        val targetZoom = targetCamera.displayIntrinsicZoomRatio.takeIf { it > 0f }
            ?: targetCamera.intrinsicZoomRatio.takeIf { it > 0f }
            ?: 1f
        if (viewModel.isVideoLensLocked()) {
            animateCurrentLensToZoomStop(targetZoom)
            return
        }
        cancelZoomStopAnimation()
        animateZoomAcrossLensStops(targetZoom, targetCamera)
    }

    fun setZoomWithPreviewTransition(targetZoom: Float) {
        lensSwitchTransition.cancelPendingSwitch()
        cancelZoomStopAnimation()
        if (viewModel.isVideoLensLocked()) {
            viewModel.setZoomRatio(targetZoom)
            return
        }
        if (viewModel.isCurrentLensCustomZoomRatioStop(targetZoom)) {
            viewModel.setZoomRatio(targetZoom)
            return
        }
        val currentCamera = state.getCurrentCameraInfo()
        val currentCameraId = currentCamera?.cameraId ?: "0"
        val camera = viewModel.findOptimalLens(
            targetZoom,
            state.availableCameras,
            currentCameraId
        )
        if (camera != null && camera.cameraId != currentCamera?.cameraId) {
            lensSwitchTransition.switchLens(camera.cameraId, targetZoom) {
                viewModel.switchToLensAndSetZoomRatio(camera.cameraId, targetZoom)
            }
        } else {
            viewModel.setZoomRatio(targetZoom)
        }
    }

    fun animateZoomStopWithPreviewTransition(targetZoom: Float) {
        lensSwitchTransition.cancelPendingSwitch()
        cancelZoomStopAnimation()
        if (viewModel.isVideoLensLocked() ||
            viewModel.isCurrentLensCustomZoomRatioStop(targetZoom)
        ) {
            animateCurrentLensToZoomStop(targetZoom)
            return
        }
        val currentCamera = state.getCurrentCameraInfo()
        val currentCameraId = currentCamera?.cameraId ?: "0"
        val camera = viewModel.findOptimalLens(
            targetZoom,
            state.availableCameras,
            currentCameraId
        )
        if (camera != null && camera.cameraId != currentCamera?.cameraId) {
            animateZoomAcrossLensStops(targetZoom, camera)
        } else {
            animateCurrentLensToZoomStop(targetZoom)
        }
    }

    fun switchCameraWithPreviewTransition() {
        runPreviewTransition { viewModel.switchCamera() }
    }

    fun setShootingModeWithPreviewTransition(mode: CameraShootingMode) {
        if (mode == CameraShootingMode.PROFESSIONAL && !state.isRawSupported) return

        val targetCaptureMode = when (mode) {
            CameraShootingMode.PROFESSIONAL,
            CameraShootingMode.PHOTO -> CaptureMode.PHOTO
            CameraShootingMode.VIDEO -> CaptureMode.VIDEO
        }
        val targetUseRaw = when (mode) {
            CameraShootingMode.PROFESSIONAL -> true
            CameraShootingMode.PHOTO -> false
            CameraShootingMode.VIDEO -> null
        }
        if (
            targetCaptureMode == state.captureMode &&
            (targetUseRaw == null || targetUseRaw == state.useRaw)
        ) {
            return
        }

        runPreviewTransition {
            if (targetCaptureMode == CaptureMode.VIDEO && state.aspectRatio == AspectRatio.XPAN) {
                viewModel.setAspectRatio(AspectRatio.RATIO_4_3)
            }
            viewModel.setShootingMode(targetCaptureMode, targetUseRaw)
        }
    }

    fun presetTargetAspectRatio(preset: CameraPreset?): AspectRatio {
        return try {
            AspectRatio.valueOf(preset?.aspectRatio ?: AspectRatio.RATIO_4_3.name)
        } catch (_: Exception) {
            AspectRatio.RATIO_4_3
        }
    }

    fun presetRequiresPreviewTransition(preset: CameraPreset?): Boolean {
        if (state.captureMode == CaptureMode.VIDEO) return false
        val targetAspectRatio = presetTargetAspectRatio(preset)
        return targetAspectRatio != state.aspectRatio
    }

    LaunchedEffect(previewTransitionToken, state.isPreviewActive, previewTransitionAwaitingResume) {
        if (!previewTransitionAwaitingResume) return@LaunchedEffect

        if (!state.isPreviewActive) {
            previewTransitionSawPause = true
            return@LaunchedEffect
        }

        if (previewTransitionSawPause) {
            delay(80)
            previewTransitionRevealing = true
            delay(220)
            previewTransitionActive = false
            previewTransitionAwaitingResume = false
            previewTransitionSawPause = false
        }
    }

    val shouldKeepScreenOn = keepScreenOn || state.videoRecordingState.isRecording

    DisposableEffect(activity, shouldKeepScreenOn) {
        if (shouldKeepScreenOn) {
            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }

        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    LaunchedEffect(previewTransitionToken) {
        if (previewTransitionToken == 0) return@LaunchedEffect
        delay(700)
        if (previewTransitionAwaitingResume) {
            previewTransitionRevealing = true
            delay(220)
            previewTransitionActive = false
            previewTransitionAwaitingResume = false
            previewTransitionSawPause = false
        }
    }

    LaunchedEffect(
        state.isPreviewActive,
        state.captureMode,
        hasPlayedInitialPreviewTransition,
        canStartShutterAnimation
    ) {
        val canRevealInitialPreview =
            canStartShutterAnimation ||
                state.captureMode == CaptureMode.VIDEO
        if (hasPlayedInitialPreviewTransition || !state.isPreviewActive || !canRevealInitialPreview) return@LaunchedEffect
        previewTransitionActive = true
        delay(InitialPreviewTransitionDelayMillis)
        previewTransitionRevealing = true
        delay(PreviewTransitionRevealDurationMillis.toLong())
        previewTransitionActive = false
        hasPlayedInitialPreviewTransition = true
    }

    var showGhostPermissionDialog by remember { mutableStateOf(false) }

    LaunchedEffect(viewModel.showGhostPermissions) {
        if (viewModel.showGhostPermissions) {
            showGhostPermissionDialog = true
            viewModel.showGhostPermissions = false
        }
    }

    if (viewModel.showPaymentDialog) {
        PaymentDialog(
            onDismiss = { viewModel.showPaymentDialog = false },
            onPurchase = {
                if (activity != null) {
                    viewModel.purchase(activity)
                }
                viewModel.showPaymentDialog = false
            }
        )
    }

    if (viewModel.showEnhancedStabilizationUnavailableDialog) {
        AlertDialog(
            onDismissRequest = viewModel::dismissEnhancedStabilizationUnavailableDialog,
            title = {
                Text(
                    text = stringResource(R.string.eis_plus_unavailable_title),
                    style = MaterialTheme.typography.titleLarge,
                )
            },
            text = {
                Text(
                    text = stringResource(R.string.eis_plus_unavailable_message),
                    style = MaterialTheme.typography.bodyMedium,
                )
            },
            confirmButton = {
                TextButton(onClick = viewModel::dismissEnhancedStabilizationUnavailableDialog) {
                    Text(stringResource(R.string.close))
                }
            },
        )
    }

    if (showGhostPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showGhostPermissionDialog = false },
            title = {
                Text(
                    text = stringResource(R.string.ghost_mode_dialog_title),
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Column {
                    Text(
                        text = stringResource(R.string.ghost_mode_dialog_description),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = stringResource(R.string.ghost_mode_permissions_required),
                        style = MaterialTheme.typography.titleSmall
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.ghost_mode_overlay_permission),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.ghost_mode_file_permission),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showGhostPermissionDialog = false
                        isGhostPermissionFlowActive = true
                        if (!Settings.canDrawOverlays(context)) {
                            ghostLauncher.launch(
                                Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    ("package:${context.packageName}").toUri()
                                )
                            )
                        } else if (!Environment.isExternalStorageManager()) {
                            ghostLauncher.launch(
                                Intent(
                                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                    ("package:${context.packageName}").toUri()
                                )
                            )
                        } else {
                            isGhostPermissionFlowActive = false
                            viewModel.togglePhantomMode()
                        }
                    }
                ) {
                    Text(stringResource(R.string.ghost_mode_dialog_confirm))
                }
            },
            dismissButton = {
                TextButton(onClick = { showGhostPermissionDialog = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .onGloballyPositioned { coordinates ->
                cameraScreenBounds = coordinates.boundsInRoot()
            }
    ) {

        val backgroundPainter = rememberBackgroundPainter(viewModel)

        val isVideoMode = state.captureMode == CaptureMode.VIDEO
        val isPhotoStyleMode = state.captureMode != CaptureMode.VIDEO
        val onParameterClick: (CameraParameter) -> Unit = { parameter ->
            val wasSelected = selectedParameter == parameter
            selectedParameter = parameter
            showParameterRuler = !wasSelected || !showParameterRuler
        }
        LaunchedEffect(showParameterRuler) {
            if (!showParameterRuler) {
                parameterRulerBounds = null
            }
        }
        val isOpenGateVideo =
            isVideoMode && state.videoConfig.aspectRatio == VideoAspectRatio.OPEN_GATE

        val density = LocalDensity.current
        val width = with(density) { constraints.maxWidth.toDp() }
        val height = with(density) { constraints.maxHeight.toDp() }
        val topSafePadding = cameraTopSafePadding()
        val topBarOffset = 0.dp
        val topBarBaseHeight = if (isVideoMode) {
            VideoTopBarBaseHeight
        } else {
            CameraTopBarBaseHeight
        }
        val topBarHeight = topBarBaseHeight + topSafePadding
        val topBarBottom = topBarHeight + topBarOffset - 4.dp
        val navigationBarHeight = with(density) {
            WindowInsets.navigationBars.getBottom(this).toDp()
        }
        val contentHeight = (height - navigationBarHeight).coerceAtLeast(0.dp)
        val viewfinderFramePadding = if (isXpan) XpanViewfinderInnerBorder * 2 else 0.dp
        val sideControlSpace = if (isXpan) XpanSideControlReservedWidth else 0.dp
        val maxCardWidth = (width - sideControlSpace * 2)
            .coerceAtLeast(viewfinderFramePadding)
        val maxCardHeight = if (isXpan) {
            (contentHeight - topBarBottom - CameraControlsLayoutDefaults.XpanViewfinderClearance)
                .coerceAtLeast(viewfinderFramePadding)
        } else {
            contentHeight
        }
        val maxViewfinderContentWidth = (maxCardWidth - viewfinderFramePadding)
            .coerceAtLeast(0.dp)
        val maxViewfinderContentHeight = (maxCardHeight - viewfinderFramePadding)
            .coerceAtLeast(0.dp)
        val viewfinderContentWidth = minOf(
            maxViewfinderContentWidth,
            maxViewfinderContentHeight * previewAspectRatio
        )
        val cardWidth = viewfinderContentWidth + viewfinderFramePadding
        val cardHeight = viewfinderContentWidth / previewAspectRatio + viewfinderFramePadding
        val xpanSideWidth = ((width - cardWidth) / 2).coerceAtLeast(0.dp)
        val placeViewfinderBelowTopBar = contentHeight - cardHeight >= topBarBottom
        // Balance small previews between the toolbar and collapsed controls. Reserving both
        // bars first prevents the downward shift from pushing parameters back into the image.
        val extraViewfinderTopSpacing = if (isXpan) {
            0.dp
        } else {
            ((contentHeight - topBarBottom - cardHeight -
                CameraControlsLayoutDefaults.CollapsedControlsHeight) / 2).coerceAtLeast(0.dp)
        }
        val viewfinderTop = if (placeViewfinderBelowTopBar) {
            topBarBottom + extraViewfinderTopSpacing
        } else {
            ((contentHeight - cardHeight) / 2).coerceAtLeast(0.dp)
        }
        val viewfinderTopOverlayPadding = (topBarBottom - viewfinderTop).coerceAtLeast(0.dp)

        val topBar = @Composable {
            CameraTopBar(
                captureMode = state.captureMode,
                isRecording = state.videoRecordingState.isRecording,
                recordingElapsedMs = state.videoRecordingState.elapsedMs,
                flashMode = state.flashMode,
                onFlashToggle = {
                    viewModel.toggleFlash()
                },
                timerSeconds = state.timerSeconds,
                onTimerToggle = { viewModel.toggleTimer() },
                showHistogram = viewModel.showHistogram,
                onHistogramToggle = {
                    viewModel.saveShowHistogram(!viewModel.showHistogram)
                },
                useLivePhoto = useLivePhoto,
                onLivePhotoToggle = { viewModel.setUseLivePhoto(!state.useLivePhoto) },
                videoConfig = state.videoConfig,
                videoCapabilities = state.videoCapabilities,
                onVideoTorchToggle = { viewModel.setVideoTorchEnabled(!state.videoConfig.torchEnabled) },
                onVideoStabilizationModeChange = viewModel::setVideoStabilizationMode,
                onVideoResolutionClick = {
                    cycleVideoResolution(state)?.let(viewModel::setVideoResolution)
                },
                onVideoFpsClick = {
                    cycleVideoFps(state)?.let(viewModel::setVideoFps)
                },
                onSettingsClick = {
                    activePanel = if (activePanel == ActivePanel.SETTINGS) ActivePanel.NONE else ActivePanel.SETTINGS
                },
                modifier = Modifier
                    .padding(top = topSafePadding)
                    .offset(y = topBarOffset)
            )
        }

        val zoomBar = @Composable {
            if (activePanel == ActivePanel.NONE && !isXpan) {
                ZoomControlBar(
                    viewModel = viewModel,
                    oppoStyle = uiStyle == "OPPO",
                    zoomRatio = viewModel.zoomRatioByMain,
                    availableCameras = state.availableCameras,
                    currentCameraId = state.getCurrentCameraInfo()?.cameraId ?: "0",
                    onZoomChange = { setZoomWithPreviewTransition(it) },
                    onZoomStopClick = { animateZoomStopWithPreviewTransition(it) },
                    onLensSwitch = { lensId -> switchToLensWithPreviewTransition(lensId) },
                    onFilterClick = {
                        // In Video + Log mode this button opens the live LUT picker.
                        // With Log disabled, preserve the existing direct Edit behavior.
                        val targetPanel = if (isVideoMode && state.videoConfig.logProfile.isEnabled) {
                            ActivePanel.FILTERS
                        } else {
                            ActivePanel.EDIT
                        }
                        activePanel = if (activePanel == targetPanel) ActivePanel.NONE else targetPanel
                    },
                    onFilterButtonBoundsChanged = { bounds ->
                        filterButtonBounds = bounds
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .onGloballyPositioned { coordinates ->
                            zoomBarBounds = coordinates.boundsInRoot()
                        }
                )
            } else {
                SideEffect {
                    zoomBarBounds = null
                }
            }
        }

        val parameterRuler = @Composable { rulerModifier: Modifier ->
            val whiteBalanceCurrentValue = if (
                state.awbMode == android.hardware.camera2.CameraMetadata.CONTROL_AWB_MODE_AUTO
            ) {
                state.actualAwbTemperature?.toFloat() ?: state.awbTemperature.toFloat()
            } else {
                state.awbTemperature.toFloat()
            }
            ParameterRuler(
                parameter = selectedParameter,
                currentValue = when (selectedParameter) {
                    CameraParameter.EXPOSURE_COMPENSATION -> state.exposureCompensation * state.getExposureCompensationStep()
                    CameraParameter.SHUTTER_SPEED -> state.shutterSpeed.toFloat()
                    CameraParameter.ISO -> state.iso.toFloat()
                    CameraParameter.FOCUS -> state.focusDistance
                    CameraParameter.WHITE_BALANCE -> whiteBalanceCurrentValue
                },
                minValue = when (selectedParameter) {
                    CameraParameter.EXPOSURE_COMPENSATION -> state.getExposureCompensationRange().lower * state.getExposureCompensationStep()
                    CameraParameter.SHUTTER_SPEED -> state.getManualShutterSpeedRange().lower.toFloat()
                    CameraParameter.ISO -> state.getIsoRange().lower.toFloat()
                    CameraParameter.FOCUS -> 0f
                    CameraParameter.WHITE_BALANCE -> state.awbTemperatureMin.toFloat()
                },
                maxValue = when (selectedParameter) {
                    CameraParameter.EXPOSURE_COMPENSATION -> state.getExposureCompensationRange().upper * state.getExposureCompensationStep()
                    CameraParameter.SHUTTER_SPEED -> state.getManualShutterSpeedRange().upper.toFloat()
                    CameraParameter.ISO -> state.getIsoRange().upper.toFloat()
                    CameraParameter.FOCUS -> state.minimumFocusDistance
                    CameraParameter.WHITE_BALANCE -> state.awbTemperatureMax.toFloat()
                },
                isAdjustable = when (selectedParameter) {
                    CameraParameter.EXPOSURE_COMPENSATION -> state.isAutoExposure
                    CameraParameter.SHUTTER_SPEED, CameraParameter.ISO -> true
                    CameraParameter.FOCUS -> state.minimumFocusDistance > 0f
                    CameraParameter.WHITE_BALANCE -> state.canAdjustWhiteBalance
                },
                isAutoMode = when (selectedParameter) {
                    CameraParameter.SHUTTER_SPEED -> state.isShutterSpeedAuto
                    CameraParameter.ISO -> state.isIsoAuto
                    CameraParameter.FOCUS -> state.isAutoFocus
                    CameraParameter.WHITE_BALANCE ->
                        state.awbMode == android.hardware.camera2.CameraMetadata.CONTROL_AWB_MODE_AUTO
                    CameraParameter.EXPOSURE_COMPENSATION -> false
                },
                showAutoButton = when (selectedParameter) {
                    CameraParameter.SHUTTER_SPEED, CameraParameter.ISO, CameraParameter.WHITE_BALANCE, CameraParameter.FOCUS -> true
                    else -> false
                },
                isAutoModeToggleEnabled = when (selectedParameter) {
                    CameraParameter.WHITE_BALANCE -> state.canAdjustWhiteBalance
                    CameraParameter.FOCUS -> state.minimumFocusDistance > 0f
                    else -> true
                },
                valueStep = state.getExposureCompensationStep(),
                resetValue = selectedParameter.defaultResetValue(),
                showHyperfocalButton = selectedParameter == CameraParameter.FOCUS && state.minimumFocusDistance > 0f,
                hyperfocalEnabled = state.isHyperfocalFocusEnabled,
                hyperfocalDistanceMeters = state.hyperfocalDistanceMeters,
                onHyperfocalToggle = { enabled ->
                    viewModel.setHyperfocalFocusEnabled(enabled)
                },
                onValueChange = { value ->
                    when (selectedParameter) {
                        CameraParameter.EXPOSURE_COMPENSATION -> viewModel.setExposureCompensation((value / state.getExposureCompensationStep()).roundToInt())
                        CameraParameter.SHUTTER_SPEED -> viewModel.setShutterSpeed(value.toLong())
                        CameraParameter.ISO -> viewModel.setIso(value.toInt())
                        CameraParameter.FOCUS -> viewModel.setFocusDistance(value)
                        CameraParameter.WHITE_BALANCE -> viewModel.setAwbTemperature(value.toInt())
                    }
                },
                onAutoModeToggle = {
                    when (selectedParameter) {
                        CameraParameter.SHUTTER_SPEED -> viewModel.setShutterSpeedAuto(!state.isShutterSpeedAuto)
                        CameraParameter.ISO -> viewModel.setIsoAuto(!state.isIsoAuto)
                        CameraParameter.WHITE_BALANCE -> {
                            if (state.canAdjustWhiteBalance) {
                                if (state.awbMode == android.hardware.camera2.CameraMetadata.CONTROL_AWB_MODE_AUTO) {
                                    viewModel.setAwbMode(android.hardware.camera2.CameraMetadata.CONTROL_AWB_MODE_OFF)
                                } else {
                                    viewModel.setAwbMode(android.hardware.camera2.CameraMetadata.CONTROL_AWB_MODE_AUTO)
                                }
                            }
                        }

                        CameraParameter.FOCUS -> viewModel.setAutoFocus(!state.isAutoFocus)
                        else -> {}
                    }
                },
                modifier = rulerModifier,
            )
        }

        val parameterBar = @Composable {
                activeParameter: CameraParameter?,
                onParameterClick: (CameraParameter) -> Unit ->
            CameraParameterBar(
                state = state,
                selectedParameter = activeParameter,
                onParameterClick = onParameterClick
            )
        }

        val viewfinder = @Composable {
            Card(
                modifier = Modifier
                    .animateContentSize(alignment = Alignment.Center)
                    .width(cardWidth)
                    .height(cardHeight),
                shape = RoundedCornerShape(if (isXpan) XpanViewfinderInnerBorder else 0.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Black)
            ) {
                Box(
                    modifier = Modifier
                        .padding(if (isXpan) XpanViewfinderInnerBorder else 0.dp)
                        .fillMaxSize()
                        .background(Color.Black)
                        .onGloballyPositioned { coordinates ->
                            previewBounds = coordinates.boundsInRoot()
                        }
                        .pointerInput(state.availableCameras) {
                            var totalDrag = 0f
                            awaitEachGesture {
                                var gestureStartedInPreviewControl: Boolean? = null
                                var childConsumedDrag = false
                                while (true) {
                                    val event = awaitPointerEvent()
                                    if (gestureStartedInPreviewControl == null) {
                                        val firstPressedChange =
                                            event.changes.firstOrNull { it.pressed }
                                        val currentPreviewBounds = previewBounds
                                        gestureStartedInPreviewControl =
                                            if (firstPressedChange != null && currentPreviewBounds != null) {
                                                val positionInRoot =
                                                    currentPreviewBounds.topLeft + firstPressedChange.position
                                                zoomBarBounds?.contains(positionInRoot) == true ||
                                                    parameterRulerBounds?.contains(positionInRoot) == true
                                            } else {
                                                false
                                            }
                                    }
                                    if (gestureStartedInPreviewControl == true) {
                                        if (event.changes.all { !it.pressed }) {
                                            viewModel.isZooming = false
                                            totalDrag = 0f
                                            break
                                        }
                                        continue
                                    }
                                    if (event.changes.size >= 2) {
                                        // Pinch to zoom
                                        childConsumedDrag = true
                                        totalDrag = 0f
                                        viewModel.isZooming = true
                                        val zoom = event.calculateZoom()
                                        if (zoom != 1f) {
                                            val nextZoom =
                                                (viewModel.zoomRatioByMain * zoom).coerceIn(
                                                    viewModel.globalMinZoom,
                                                    viewModel.globalMaxZoom
                                                )
                                            setZoomWithPreviewTransition(nextZoom)
                                        }
                                        event.changes.forEach { it.consume() }
                                    } else if (event.changes.size == 1) {
                                        // Single finger -> horizontal drag for LUT switch
                                        val change = event.changes[0]
                                        if (change.isConsumed && change.position != change.previousPosition) {
                                            childConsumedDrag = true
                                            totalDrag = 0f
                                        }
                                        if (change.pressed && !childConsumedDrag) {
                                            val dragAmount =
                                                change.position.x - change.previousPosition.x
                                            totalDrag += dragAmount
                                        } else if (!change.pressed) {
                                            // onDragEnd logic
                                            if (!childConsumedDrag && abs(totalDrag) > 100) {
                                                val selectedLut = if (totalDrag > 0) {
                                                    viewModel.switchToPreviousLut()
                                                } else {
                                                    viewModel.switchToNextLut()
                                                }
                                                selectedLut?.let {
                                                    lutNameOverlayState.show(it.getName())
                                                }
                                            }
                                            totalDrag = 0f
                                            viewModel.isZooming = false
                                        }
                                    }

                                    if (event.changes.all { !it.pressed }) {
                                        viewModel.isZooming = false
                                        totalDrag = 0f
                                        break
                                    }
                                }
                            }
                        },
                ) {
                    val currentCameraId = state.currentCameraId
                    val calibrationOffset by viewModel.getCameraOrientationOffset(currentCameraId)
                        .collectAsState(initial = 0)
                    val eyeFocusActive = eyeFocusEnabled &&
                        viewModel.isEyeFocusRuntimeAvailable &&
                        state.isAutoFocus &&
                        !state.isHyperfocalFocusEnabled &&
                        (state.focusPoint == null || state.focusPointSource == FocusPointSource.EYE)
                    val portraitMaskActive = state.captureMode == CaptureMode.PHOTO &&
                        state.useRaw &&
                        state.isRawSupported

                    // 相机准备完成后再创建 Surface，首次只打开最终选中的镜头。
                    if (isCameraPrepared) {
                        CameraPreviewGL(
                            aspectRatio = previewAspectRatio,
                            previewSize = previewSize,
                            captureSize = state.currentCaptureSize,
                            captureMode = state.captureMode,
                            sensorOrientation = state.getCurrentCameraInfo()?.sensorOrientation
                                ?: 0,
                            lensFacing = if (state.getCurrentCameraInfo()?.lensFacing == android.hardware.camera2.CameraCharacteristics.LENS_FACING_FRONT) 0 else 1,
                            calibrationOffset = calibrationOffset,
                            baselineLut = viewModel.currentBaselineLutConfig,
                            currentLut = viewModel.currentLutConfig,
                            enginePreviewPlan = viewModel.currentEnginePreviewPlan,
                            baselineColorRecipeParams = currentBaselineRecipeParams,
                            colorRecipeParams = previewRecipeParamsOverride ?: currentRecipeParams,
                            focusPoint = state.focusPoint,
                            meteringPoint = state.meteringPoint,
                            canMoveMeteringPoint = state.supportsPointMetering &&
                                !state.isCapturing && activePanel == ActivePanel.NONE,
                            onMeteringPointMove = viewModel::moveMeteringPoint,
                            onFocusPointMove = viewModel::moveFocusPoint,
                            onMeteringPointMerge = viewModel::mergeMeteringPoint,
                            focusPointSource = state.focusPointSource,
                            isFocusLocked = state.isFocusLocked,
                            isFocusing = state.isFocusing,
                            focusSuccess = state.focusSuccess,
                            meteringMode = state.effectiveMeteringMode,
                            onSurfaceTextureReady = { surfaceTexture ->
                                previewSurfaceTexture = surfaceTexture
                            },
                            onSurfaceDestroyed = { surfaceTexture ->
                                if (previewSurfaceTexture === surfaceTexture) {
                                    previewSurfaceTexture = null
                                }
                                viewModel.closeCamera(surfaceTexture)
                            },
                            onStandbySurfaceTextureReady = viewModel::setStandbyPreviewSurfaceTexture,
                            onStandbySurfaceTextureDestroyed = viewModel::clearStandbyPreviewSurfaceTexture,
                            onTap = { x, y, w, h ->
                                if (state.isFocusLocked) {
                                    viewModel.unlockFocus()
                                } else if (activePanel != ActivePanel.NONE) {
                                    activePanel = ActivePanel.NONE
                                } else {
                                    viewModel.focusOnPoint(x, y, w, h)
                                }
                            },
                            onLongPress = { x, y, w, h ->
                                if (activePanel != ActivePanel.NONE) {
                                    activePanel = ActivePanel.NONE
                                } else {
                                    viewModel.lockFocusOnPoint(x, y, w, h)
                                }
                            },
                            onHistogramUpdated = { viewModel.handleHistogramUpdate(it) },
                            onMeteringUpdated = { w, l -> viewModel.handleMeteringUpdate(w, l) },
                            onHighlightPointUpdated = { hx, hy ->
                                viewModel.handleHighlightPointUpdate(
                                    hx,
                                    hy
                                )
                            },
                            onEyeFocusInputAvailable = if (eyeFocusActive || portraitMaskActive) {
                                viewModel::handleEyeFocusInputUpdate
                            } else {
                                null
                            },
                            onFirstPreviewFrame = viewModel::onFirstPreviewFrame,
                            onGLSurfaceViewReady = {
                                viewModel.glSurfaceView = it
                            },
                            livePhotoRecorder = viewModel.livePhotoRecorder,
                            videoLogProfile = state.videoConfig.logProfile,
                            isEyeFocusBusy = viewModel.isEyeFocusBusy,
                            isAutoFocus = state.isAutoFocus,
                            focusPeakingEnabled = focusPeakingEnabled && !state.isHyperfocalFocusEnabled,
                            stabilizationCoordinator = viewModel.realtimeStabilizationCoordinator,
                            stabilizationInputSize = if (
                                state.captureMode == CaptureMode.VIDEO &&
                                state.videoConfig.stabilizationMode ==
                                    VideoStabilizationMode.ENHANCED
                            ) {
                                state.videoCapabilities
                                    .enhancedStabilizationInputSizesByResolution[
                                        state.videoConfig.resolution
                                    ] ?: previewSize
                            } else {
                                previewSize
                            },
                            photoPreviewStabilizationEnabled =
                                state.photoPreviewStabilizationEnabled,
                            videoPreviewStabilizationEnabled =
                                state.videoConfig.stabilizationMode ==
                                    VideoStabilizationMode.ENHANCED,
                            videoPreviewStabilizationStrength =
                                state.videoConfig.enhancedStabilizationStrength,
                            videoPreviewStabilizationLookahead =
                                state.videoConfig.enhancedStabilizationLookahead,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                alpha = if (previewTransitionActive || previewTransitionCoverFractionState.value > 0.001f) 1f else 0f
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(0.5f)
                                .align(Alignment.TopCenter)
                                .graphicsLayer {
                                    translationY = -size.height * (1f - previewTransitionCoverFractionState.value)
                                }
                                .background(Color.Black)
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(0.5f)
                                .align(Alignment.BottomCenter)
                                .graphicsLayer {
                                    translationY = size.height * (1f - previewTransitionCoverFractionState.value)
                                }
                                .background(Color.Black)
                        )
                    }

                    LensSwitchTransitionOverlay(lensSwitchTransition, Modifier.fillMaxSize())

                    val showLivePhotoIndicator =
                        state.captureMode == CaptureMode.PHOTO && useLivePhoto
                    val showVirtualApertureIndicator =
                        state.captureMode != CaptureMode.VIDEO &&
                            state.isVirtualApertureEnabled
                    if (showLivePhotoIndicator || showVirtualApertureIndicator) {
                        Column(
                            modifier = Modifier
                                .padding(
                                    top = viewfinderTopOverlayPadding + 8.dp,
                                    end = 12.dp
                                )
                                .align(Alignment.TopEnd),
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (showLivePhotoIndicator) {
                                Surface(
                                    color = Color.Black.copy(alpha = 0.8f),
                                    shape = CircleShape
                                ) {
                                    Icon(
                                        painterResource(R.drawable.ic_live_photo),
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier
                                            .padding(4.dp)
                                            .size(18.dp)
                                    )
                                }
                            }
                            if (showVirtualApertureIndicator) {
                                Surface(
                                    color = Color.Black.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = stringResource(
                                            R.string.virtual_aperture_viewfinder_hint,
                                            formatVirtualApertureFStop(state.virtualAperture)
                                        ),
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Medium,
                                        style = TextStyle(shadow = ViewfinderTextShadow),
                                        modifier = Modifier.padding(
                                            horizontal = 6.dp,
                                            vertical = 3.dp
                                        )
                                    )
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        multipleExposureState.previewBitmap?.let { previewBitmap ->
                            Image(
                                bitmap = previewBitmap.asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .autoRotate(matchParentSize = true),
                                alpha = 0.45f,
                                contentScale = ContentScale.Crop
                            )
                        }

                        // 实时直方图 (Overlaid on preview if enabled)
                        if (isPhotoStyleMode && state.histogram != null && viewModel.showHistogram) {
                            HistogramView(
                                histogram = state.histogram,
                                modifier = Modifier
                                    .padding(
                                        start = 8.dp,
                                        top = viewfinderTopOverlayPadding + 8.dp
                                    )
                                    .size(80.dp, 40.dp)
                                    .align(Alignment.TopStart)
                                    .autoRotate(dx = -20.dp, dy = 20.dp)
                            )
                        }

                        // 网格线覆盖
                        if (state.showGrid) {
                            GridOverlay(
                                aspectRatio = previewAspectRatio,
                                style = state.gridStyle,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // 水平仪覆盖
                        if (showLevelIndicator) {
                            LevelIndicatorOverlay(
                                aspectRatio = previewAspectRatio,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // 倒计时覆盖
                        if (state.countdownValue > 0) {
                            CountdownOverlay(
                                countdownValue = state.countdownValue,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        if (state.burstCapturing && burstCapturingCount > 0) {
                            BurstCaptureOverlay(
                                count = burstCapturingCount,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(top = viewfinderTopOverlayPadding)
                            )
                        }

                        if (useMultipleExposure && state.captureMode == CaptureMode.PHOTO) {
                            MultipleExposureOverlay(
                                state = multipleExposureState,
                                onFinish = { viewModel.finishMultipleExposureSession() },
                                onUndo = { viewModel.undoLastMultipleExposureFrame() },
                                onCancel = { viewModel.cancelMultipleExposureSession() },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(top = viewfinderTopOverlayPadding)
                            )
                        }

                    }

                    if (isXpan) {
                        CornerOverlay(
                            modifier = Modifier.fillMaxSize(),
                            radius = XpanViewfinderInnerBorder,
                            color = Color.Black
                        )
                    }

                    LutNameOverlay(
                        state = lutNameOverlayState,
                        modifier = Modifier.align(Alignment.Center),
                    )
                }
            }

            if (isXpan) {
                // Center both side bars in the space above the capture controls, which
                // overlap the lower part of the XPAN viewfinder.
                val sideControlsBottom = minOf(
                    viewfinderTop + cardHeight,
                    contentHeight - CameraControlsLayoutDefaults.CaptureAreaHeight -
                        CameraControlsLayoutDefaults.CaptureClearance
                )
                val sideControlsHeight = (sideControlsBottom - viewfinderTop)
                    .coerceIn(0.dp, cardHeight)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(cardHeight)
                        .padding(bottom = cardHeight - sideControlsHeight),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .width(xpanSideWidth),
                        contentAlignment = Alignment.Center
                    ) {
                        ZoomControlBarVerticel(
                            viewModel = viewModel,
                            zoomRatio = viewModel.zoomRatioByMain,
                            availableCameras = state.availableCameras,
                            currentCameraId = state.getCurrentCameraInfo()?.cameraId ?: "0",
                            onZoomChange = { setZoomWithPreviewTransition(it) },
                            onZoomStopClick = { animateZoomStopWithPreviewTransition(it) },
                            onLensSwitch = { lensId -> switchToLensWithPreviewTransition(lensId) },
                            onFilterClick = {
                                // Match the horizontal layout: Log video opens the live LUT picker;
                                // Log Off continues to open the Edit panel directly.
                                val targetPanel = if (isVideoMode && state.videoConfig.logProfile.isEnabled) {
                                    ActivePanel.FILTERS
                                } else {
                                    ActivePanel.EDIT
                                }
                                activePanel = if (activePanel == targetPanel) ActivePanel.NONE else targetPanel
                            },
                            onFilterButtonBoundsChanged = { bounds ->
                                filterButtonBounds = bounds
                            },
                        )
                    }
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .width(xpanSideWidth),
                        contentAlignment = Alignment.Center
                    ) {
                        // Manual parameter controls are intentionally hidden in the camera UI.
                    }
                }
            }
        }


        val controls = @Composable { modifier: Modifier ->
            Controls(
                state = state,
                uiStyle = uiStyle,
                viewModel = viewModel,
                galleryViewModel = galleryViewModel,
                latestPhoto = latestPhoto,
                useMultipleExposure = useMultipleExposure,
                multipleExposureState = multipleExposureState,
                onGalleryThumbnailBoundsChanged = { bounds ->
                    galleryThumbnailBounds = bounds
                },
                onCaptureButtonBoundsChanged = { bounds ->
                    captureButtonBounds = bounds
                },
                onSwitchCameraClick = ::switchCameraWithPreviewTransition,
                onCaptureModeSelected = ::setShootingModeWithPreviewTransition,
                modeSwitchEnabled = !previewTransitionActive && !lensSwitchTransition.isActive,
                onCaptureTap = {
                    val shouldDebounceRawCapture =
                        state.useRaw && state.captureMode == CaptureMode.PHOTO
                    if (shouldDebounceRawCapture) {
                        if (rawCaptureTapLocked) {
                            return@Controls
                        }
                        rawCaptureTapLocked = true
                        scope.launch {
                            delay(RawCaptureTapDebounceMillis)
                            rawCaptureTapLocked = false
                        }
                    }

                    if (enableDevelopAnimation && state.captureMode == CaptureMode.PHOTO) {
                        viewModel.glSurfaceView?.capturePreviewFrame(maxLongEdge = 1440) { bitmap ->
                            if (scope.isActive && enableDevelopAnimation &&
                                currentCaptureModeForEffects == CaptureMode.PHOTO
                            ) {
                                pendingCaptureAnimationBitmap?.recycleIfAlive()
                                pendingCaptureAnimationBitmap = bitmap
                            } else {
                                bitmap.recycleIfAlive()
                            }
                        }
                    }
                    viewModel.capture()
                },
                onGalleryClick = {
                    onGalleryClick()
                },
                sideControlInset = if (isXpan) {
                    (xpanSideWidth - CameraControlsLayoutDefaults.SideButtonSize) / 2
                } else {
                    null
                },
                modifier = modifier
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .paint(backgroundPainter, contentScale = ContentScale.Crop)
                .navigationBarsPadding(),
        ) {
            // The viewfinder is always the bottom layer. Its selected aspect ratio is fitted
            // to the full available area before camera controls are overlaid.
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(cardHeight)
                    .align(Alignment.TopCenter)
                    .offset(y = viewfinderTop)
                    .onGloballyPositioned { coordinates ->
                        viewfinderAreaBounds = coordinates.boundsInRoot()
                    },
                contentAlignment = Alignment.Center
            ) {
                viewfinder()
                if (uiStyle == "OPPO" && activePanel == ActivePanel.NONE && !isXpan) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .height(CameraControlsLayoutDefaults.ZoomBarHeight),
                        contentAlignment = Alignment.Center
                    ) {
                        zoomBar()
                    }
                }
            }

            topBar()

            CameraBottomControlsLayout(
                viewfinderBottom = viewfinderTop + cardHeight,
                modifier = Modifier.fillMaxSize(),
                zoomBar = {
                    // Panel visibility changes the zoom content, not the space used to
                    // position the parameter row beneath it. XPAN has no horizontal bar.
                    if (uiStyle != "OPPO" || isXpan) {
                        Box(
                            modifier = if (isXpan) Modifier else Modifier
                                .fillMaxWidth()
                                .height(CameraControlsLayoutDefaults.ZoomBarHeight)
                        ) {
                            zoomBar()
                        }
                    } else {
                        Spacer(modifier = Modifier.height(0.dp))
                    }
                },
                // Hide the manual controls (EV/Tv/ISO/AF/AWB and their value ruler)
                // in both Photo and Video modes without changing capture functionality.
                parameterRuler = {},
                parameterBar = {},
                captureControls = {
                    controls(Modifier.fillMaxWidth())
                }
            )
        }
        val panelDismissBounds = if (isXpan) {
            viewfinderAreaBounds ?: previewBounds
        } else {
            previewBounds
        }

        if (activePanel != ActivePanel.NONE) {
            PanelDismissPreviewOverlay(
                bounds = panelDismissBounds,
                parentBounds = cameraScreenBounds,
                dimBackground = activePanel == ActivePanel.SETTINGS,
                onDismiss = { activePanel = ActivePanel.NONE }
            )
        }

        // TopSheet for settings
        CameraTopSheet(
            visible = activePanel == ActivePanel.SETTINGS,
            captureMode = state.captureMode,
            aspectRatio = state.aspectRatio,
            topSheetAspectRatios = topSheetAspectRatios,
            onAspectRatioChange = { runPreviewTransition { viewModel.setAspectRatio(it) } },
            videoAspectRatio = state.videoConfig.aspectRatio,
            onVideoAspectRatioChange = { runPreviewTransition { viewModel.setVideoAspectRatio(it) } },
            videoLogProfile = state.videoConfig.logProfile,
            availableVideoLogProfiles = state.videoCapabilities.availableLogProfiles,
            onVideoLogProfileChange = { viewModel.setVideoLogProfile(it) },
            videoBitrate = state.videoConfig.bitrate,
            onVideoBitrateChange = { viewModel.setVideoBitrate(it) },
            videoCodec = videoCodec,
            onVideoCodecChange = { viewModel.setVideoCodec(it) },
            videoAudioInputId = state.videoConfig.audioInputId,
            videoAudioInputOptions = videoAudioInputOptions,
            onVideoAudioInputChange = { viewModel.setVideoAudioInputId(it) },
            useRaw = useRaw && state.isRawSupported,
            isRawSupported = state.isRawSupported,
            rawDcpId = rawDcpId,
            rawDcpIdsByLens = rawDcpIdsByLens,
            rawDcpLensOptions = rawDcpLensOptions(state.availableCameras),
            availableDcps = viewModel.availableDcps,
            rawHncsFilmCurveMode = rawHncsFilmCurveMode,
            rawRenderingEngine = rawColorEngine,
            rawToneMappingParameters = rawToneMappingParameters,
            rawSpectralFilmSelection = rawSpectralFilmSelection ?: SpectralFilmSelection(rawSpectralFilmStock ?: "kodak_portra_400"),
            rawSpectralFilmPrint = rawSpectralFilmPrint ?: "kodak_portra_endura",
            ultraHdrEnabled = ultraHdrEnabled,
            onUltraHdrToggle = viewModel::setUltraHdrGainMapEnabled,
            photoPreviewStabilizationEnabled =
                state.photoPreviewStabilizationEnabled,
            photoPreviewStabilizationAvailable =
                viewModel.realtimeStabilizationCoordinator.isCurrentCameraSupported,
            onPhotoPreviewStabilizationChange =
                viewModel::setPhotoPreviewStabilizationEnabled,
            onRawDcpChange = { viewModel.setRawDcpId(it) },
            onRawDcpIdsByLensChange = { viewModel.setRawDcpIdsByLens(it) },
            onRawHncsFilmCurveModeChange = { viewModel.setRawHncsFilmCurveMode(it) },
            onImportRawDcp = { dcpImportLauncher.launch(arrayOf("*/*")) },
            onDeleteRawDcp = { dcp ->
                viewModel.deleteRawDcp(dcp.id) { success ->
                    android.widget.Toast.makeText(
                        context,
                        if (success) R.string.raw_dcp_delete_success else R.string.raw_dcp_delete_failed,
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            },
            onRawColorEngineChange = { viewModel.setRawColorEngine(it) },
            onRawToneMappingParametersChange = { viewModel.setRawToneMappingParameters(it) },
            onRawSpectralFilmSelectionChange = { viewModel.setRawSpectralFilmSelection(it) },
            onRawSpectralFilmPrintChange = { viewModel.setRawSpectralFilmPrint(it) },
            meteringMode = state.meteringMode,
            onMeteringModeChange = { viewModel.setMeteringMode(it) },
            onFilterManageClick = {
                activePanel = ActivePanel.NONE
                onFilterManagementClick(null)
            },
            onFrameManageClick = {
                activePanel = ActivePanel.NONE
                onFrameManagementClick()
            },
            onPresetManageClick = {
                activePanel = ActivePanel.NONE
                onPresetManagementClick()
            },
            onToolboxClick = {
                activePanel = ActivePanel.NONE
                onToolboxClick()
            },
            onMoreSettingsClick = {
                activePanel = ActivePanel.NONE
                onSettingsClick()
            },
            useJpgMax = useJpgMax,
            onJpgMaxToggle = {
                viewModel.setUseJpgMax(it)
            },
            useMultipleExposure = useMultipleExposure,
            onMultipleExposureToggle = { viewModel.setUseMultipleExposure(it) },
            contentTopPadding = CameraTopBarBaseTopPadding + topSafePadding
        )

        // During navigation measurement or window resizing, the viewport can be
        // shorter than the toolbar. The panel then has no available vertical space.
        val filterPanelTop = minOf(
            if (!isXpan && !isVideoMode) topBarHeight else 0.dp,
            maxHeight
        )
        val fallbackFilterPanelBottom = when {
            isXpan -> maxHeight - 48.dp
            isVideoMode -> maxHeight - 170.dp
            else -> topBarHeight + cardHeight - 48.dp
        }
        val filterPanelAnchorY = if (isXpan) {
            captureButtonBounds?.top
        } else {
            filterButtonBounds?.bottom
        }
        val requestedFilterPanelBottom = filterPanelAnchorY?.let { anchorY ->
            val parentTop = cameraScreenBounds?.top ?: 0f
            with(density) { (anchorY - parentTop).toDp() - 8.dp }
        } ?: fallbackFilterPanelBottom
        val filterPanelBottom = requestedFilterPanelBottom.coerceIn(filterPanelTop, maxHeight)

        AnimatedVisibility(
            activePanel == ActivePanel.FILTERS ||
                (activePanel == ActivePanel.EDIT && isVideoMode && !state.videoConfig.logProfile.isEnabled),
            enter = if (isXpan) {slideInVertically(initialOffsetY = { it })} else fadeIn(),
            exit = if (isXpan) {slideOutVertically(targetOffsetY = { it })} else fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(filterPanelBottom)
                    .padding(top = filterPanelTop),
                contentAlignment = Alignment.BottomCenter
            ) {
                val allPresets by viewModel.allPresets.collectAsState()
                val defaultPresetName = stringResource(R.string.preset_new_preset_default)
                val isVideoLog = isVideoMode && state.videoConfig.logProfile.isEnabled

                // LUT 选择器 (内嵌 Presets 列表与统一控制，无多余背景遮挡)
                LutSelector(
                    availableLuts = if (isVideoLog) {
                        // Prefer the six requested Log looks when they are installed.
                        // Never hide every LUT when bundled/custom LUT IDs differ or
                        // those assets have not been added to this build yet.
                        val allLuts = viewModel.selectableLutList
                        val requestedLogLuts = allLuts.filter { lut ->
                            lut.id in setOf(
                                "romance_neutral",
                                "romance_soft1",
                                "summerdusk",
                                "tealandorange",
                                "truecinematic",
                                "weddingpack1"
                            )
                        }
                        requestedLogLuts.ifEmpty { allLuts }
                    } else viewModel.selectableLutList,
                    currentLutId = currentLutId,
                    thumbnail = viewModel.previewThumbnail,
                    onLutSelected = { viewModel.setLut(it) },
                    allPresets = allPresets,
                    presetModeEnabled = !isVideoLog,
                    activePresetId = activePresetId,
                    activePresetModified = activePresetModified,
                    selectedMode = if (isVideoLog) LutSelectorMode.Style else lutSelectorMode,
                    onModeSelected = { viewModel.setLutSelectorMode(it) },
                    availableFrames = viewModel.availableFrameList,
                    currentFrameId = viewModel.currentFrameId,
                    onFrameSelected = if (isVideoLog) null else viewModel::setFrame,
                    onFrameManagementClick = {
                        activePanel = ActivePanel.NONE
                        onFrameManagementClick()
                    },
                    onPresetSelected = { preset ->
                        discardTransientLookEdits()
                        if (presetRequiresPreviewTransition(preset)) {
                            runPreviewTransition { viewModel.applyPreset(preset) }
                        } else {
                            viewModel.applyPreset(preset)
                        }
                    },
                    onCreatePresetClick = {
                        viewModel.prepareCurrentSettingsPresetDraft(defaultPresetName)
                        onPresetEditClick(null)
                    },
                    onResetPresetClick = {
                        discardTransientLookEdits()
                        val preset = allPresets.firstOrNull { it.id == activePresetId }
                        if (presetRequiresPreviewTransition(preset)) {
                            runPreviewTransition { viewModel.resetActivePreset() }
                        } else {
                            viewModel.resetActivePreset()
                        }
                    },
                    onSavePresetClick = viewModel::saveCurrentSettingsToActivePreset,
                    onPresetManagementClick = onPresetManagementClick,
                    onEditClick = {
                        activePanel = ActivePanel.EDIT
                    },
                    onManageClick = { lutId ->
                        activePanel = ActivePanel.NONE
                        onFilterManagementClick(lutId)
                    },
                    categoryOrder = categoryOrder,
                    headerContent = if (isVideoLog) {
                        {
                            VideoLogLutModeSelector(
                                mode = state.videoConfig.logLutMode,
                                enabled = !state.videoRecordingState.isRecording &&
                                    !state.videoRecordingState.isProcessing,
                                onModeSelected = viewModel::setVideoLogLutMode
                            )
                        }
                    } else null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 6.dp, top = 10.dp, end = 6.dp)
                )
            }
        }

        if (activePanel == ActivePanel.EDIT) {
            LutEditBottomSheet(
                lutId = currentLutId,
                initialParams = previewRecipeParamsOverride ?: currentRecipeParams,
                onParamsPreviewChange = { previewRecipeParamsOverride = it },
                showEffects = true,
                onDismiss = {
                    previewRecipeParamsOverride = null
                    activePanel = ActivePanel.NONE
                }
            )
        }

        captureAnimationSnapshot?.let { snapshot ->
            CaptureAnimationOverlay(
                snapshot = snapshot,
                modifier = Modifier.fillMaxSize(),
                onFinished = {
                    if (captureAnimationSnapshot?.id == snapshot.id) {
                        captureAnimationSnapshot = null
                    }
                }
            )
        }

    }
}

@Composable
fun MultipleExposureOverlay(
    state: com.hinnka.mycamera.viewmodel.MultipleExposureSessionState,
    onFinish: () -> Unit,
    onUndo: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.padding(8.dp)) {
        Surface(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .wrapContentWidth(),
            color = Color.Transparent,
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(
                modifier = Modifier
                    .background(
                        brush = Brush.horizontalGradient(
                            listOf(
                                Color(0xD90D1117),
                                Color(0xB8141B22)
                            )
                        ),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = AppIcons.Layers,
                    contentDescription = null,
                    tint = AccentColor,
                    modifier = Modifier.size(16.dp)
                )

                Text(
                    text = "${state.capturedCount}/${state.targetCount}",
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge.copy(
                        shadow = ViewfinderTextShadow
                    )
                )

                if (state.isSessionActive) {
                    IconButton(
                        onClick = onUndo,
                        enabled = state.capturedCount > 0 && !state.isProcessing,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            AppIcons.AutoMirroredOutlinedUndo,
                            contentDescription = stringResource(R.string.multiple_exposure_undo),
                            modifier = Modifier.size(16.dp),
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = onFinish,
                        enabled = state.canFinish,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = stringResource(R.string.multiple_exposure_finish),
                            modifier = Modifier.size(16.dp),
                            tint = AccentColor
                        )
                    }

                    IconButton(
                        onClick = onCancel,
                        enabled = !state.isProcessing,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = stringResource(R.string.multiple_exposure_cancel),
                            modifier = Modifier.size(16.dp),
                            tint = Color.Red
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Controls(
    state: CameraState,
    uiStyle: String,
    viewModel: CameraViewModel,
    galleryViewModel: GalleryViewModel,
    latestPhoto: com.hinnka.mycamera.gallery.MediaData?,
    useMultipleExposure: Boolean,
    multipleExposureState: com.hinnka.mycamera.viewmodel.MultipleExposureSessionState,
    onGalleryThumbnailBoundsChanged: (Rect) -> Unit,
    onCaptureButtonBoundsChanged: (Rect) -> Unit,
    onSwitchCameraClick: () -> Unit,
    onCaptureModeSelected: (CameraShootingMode) -> Unit,
    modeSwitchEnabled: Boolean,
    onCaptureTap: () -> Unit,
    onGalleryClick: () -> Unit,
    sideControlInset: Dp?,
    modifier: Modifier = Modifier.fillMaxSize()
) {
    val captureButtonStyle by viewModel.captureButtonStyle.collectAsState()
    val captureButtonColor by viewModel.captureButtonColor.collectAsState()
    val captureButtonImagePath by viewModel.captureButtonImagePath.collectAsState()
    val captureProcessingState by viewModel.captureProcessingState.collectAsState()
    val capturedThumbnail by viewModel.capturedThumbnail.collectAsState()

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = CameraControlsLayoutDefaults.BottomPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(start = sideControlInset ?: 32.dp)
                        .onGloballyPositioned { coordinates ->
                            onGalleryThumbnailBoundsChanged(coordinates.boundsInRoot())
                        }
                        .autoRotate()
                ) {
                    GalleryThumbnail(
                        latestPhoto = latestPhoto,
                        viewModel = galleryViewModel,
                        capturedThumbnail = capturedThumbnail,
                        onCapturedThumbnailLoaded = viewModel::acknowledgeCapturedThumbnail,
                        onClick = onGalleryClick
                    )
                    key(capturedThumbnail?.captureId) {
                        GalleryProcessingOverlay(
                            pendingCount = if (capturedThumbnail == null || capturedThumbnail?.bitmap != null ||
                                capturedThumbnail?.finalThumbnailLoaded == true
                            ) {
                                captureProcessingState.pendingCount
                            } else {
                                0
                            },
                            completedCount = captureProcessingState.completedCount,
                            modifier = Modifier.matchParentSize()
                        )
                    }
                }

                CaptureButton(
                    captureMode = state.captureMode,
                    isProfessionalMode = state.useRaw && state.isRawSupported,
                    isCapturing = state.isCapturing,
                    photoCaptureProgress = state.photoCaptureProgress,
                    isBurstCapturing = state.burstCapturing,
                    isVideoRecording = state.videoRecordingState.isRecording,
                    isVideoProcessing = state.videoRecordingState.isProcessing,
                    isPaused = state.videoRecordingState.isPaused,
                    allowLongPress = state.captureMode == CaptureMode.PHOTO &&
                        !useMultipleExposure,
                    multipleExposureEnabled = useMultipleExposure && state.captureMode == CaptureMode.PHOTO,
                    multipleExposureProgress = multipleExposureState.capturedCount.toFloat() /
                            multipleExposureState.targetCount.coerceAtLeast(1).toFloat(),
                    customStyle = if (uiStyle == "OPPO" && state.captureMode != CaptureMode.VIDEO) {
                        CaptureButtonStyle.COLOR
                    } else {
                        captureButtonStyle
                    },
                    customColor = if (uiStyle == "OPPO" && state.captureMode != CaptureMode.VIDEO) {
                        0xFFFF8500.toInt()
                    } else {
                        captureButtonColor
                    },
                    customImagePath = captureButtonImagePath,
                    onTap = onCaptureTap,
                    onLongPressStart = { viewModel.startContinuousCapture() },
                    onLongPressEnd = { viewModel.stopContinuousCapture() },
                    modifier = Modifier.onGloballyPositioned { coordinates ->
                        onCaptureButtonBoundsChanged(coordinates.boundsInRoot())
                    },
                )

                if (state.videoRecordingState.isRecording) {
                    IconButton(
                        onClick = { viewModel.captureVideoFrame() },
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = sideControlInset ?: 40.dp)
                            .size(CameraControlsLayoutDefaults.SideButtonSize)
                            .autoRotate()
                    ) {
                        Icon(
                            imageVector = AppIcons.CameraAlt,
                            contentDescription = stringResource(R.string.take_photo),
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            if (state.videoRecordingState.isPaused) {
                                viewModel.resumeVideoRecording()
                            } else {
                                viewModel.pauseVideoRecording()
                            }
                        },
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = 100.dp)
                            .size(48.dp)
                            .autoRotate()
                    ) {
                        Icon(
                            imageVector = if (state.videoRecordingState.isPaused) Icons.Default.PlayArrow else AppIcons.Pause,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                } else {
                    PhysicalButton(
                        onClick = {
                            if (!state.videoRecordingState.isProcessing) {
                                onSwitchCameraClick()
                            }
                        },
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = sideControlInset ?: 40.dp)
                            .size(CameraControlsLayoutDefaults.SideButtonSize)
                            .autoRotate(),
                        shape = CircleShape
                    ) {
                        Icon(
                            imageVector = AppIcons.Cameraswitch,
                            contentDescription = stringResource(R.string.switch_camera),
                            tint = Color.White.copy(
                                alpha = if (state.videoRecordingState.isProcessing) 0.35f else 1f
                            ),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(CameraControlsLayoutDefaults.ModeSwitcherSpacing))

            CaptureModeSwitcher(
                oppoStyle = uiStyle == "OPPO",
                // Pro/RAW remains an internal capture option, but is no longer a
                // separate item in the visible Photo/Video mode switcher.
                shootingMode = if (state.captureMode == CaptureMode.VIDEO) {
                    CameraShootingMode.VIDEO
                } else {
                    CameraShootingMode.PHOTO
                },
                enabled = modeSwitchEnabled &&
                    !state.videoRecordingState.isRecording &&
                    !state.videoRecordingState.isProcessing,
                onModeSelected = onCaptureModeSelected
            )
        }
    }
}

/** Keeps render progress independent of the shutter and the optional photo fly-in animation. */
@Composable
private fun GalleryProcessingOverlay(
    pendingCount: Int,
    completedCount: Long,
    modifier: Modifier = Modifier
) {
    val completionAlpha = remember { Animatable(0f) }
    var lastAcknowledgedCompletion by remember { mutableLongStateOf(completedCount) }
    val thumbnailShape = RoundedCornerShape(10.dp)

    LaunchedEffect(pendingCount, completedCount) {
        if (pendingCount > 0) {
            completionAlpha.snapTo(0f)
        } else if (completedCount != lastAcknowledgedCompletion) {
            lastAcknowledgedCompletion = completedCount
            // A neutral highlight acknowledges completion without implying success on failure.
            completionAlpha.snapTo(0f)
            completionAlpha.animateTo(0.75f, tween(durationMillis = 120))
            completionAlpha.animateTo(0f, tween(durationMillis = 700))
        }
    }

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        AnimatedVisibility(
            visible = pendingCount > 0,
            enter = fadeIn(tween(durationMillis = 180)),
            exit = fadeOut(tween(durationMillis = 220)),
            modifier = Modifier.matchParentSize()
        ) {
            // Keep the photo visible beneath a soft diagonal reflection. The transition is
            // disposed after fade-out, so an idle thumbnail does not keep requesting frames.
            val transition = rememberInfiniteTransition(label = "thumbnailProcessing")
            val sweep = transition.animateFloat(
                initialValue = -1f,
                targetValue = 2f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 1800, delayMillis = 200, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "thumbnailLightSweep"
            )
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(thumbnailShape)
                    .border(1.dp, Color.White.copy(alpha = 0.14f), thumbnailShape)
            ) {
                drawRect(Color.Black.copy(alpha = 0.08f))
                val centerX = size.width * sweep.value
                val bandWidth = size.width * 0.65f
                drawRect(
                    brush = Brush.linearGradient(
                        0f to Color.Transparent,
                        0.3f to Color.White.copy(alpha = 0.03f),
                        0.5f to Color.White.copy(alpha = 0.24f),
                        0.7f to Color.White.copy(alpha = 0.03f),
                        1f to Color.Transparent,
                        start = Offset(centerX - bandWidth, 0f),
                        end = Offset(centerX + bandWidth, size.height * 0.7f)
                    )
                )
            }
        }
        if (completionAlpha.value > 0f) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clip(thumbnailShape)
                    .background(Color.White.copy(alpha = completionAlpha.value * 0.08f))
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = completionAlpha.value),
                        shape = thumbnailShape
                    )
            )
        }
    }
}


/**
 * 拍照按钮
 */
@Composable
fun CaptureButton(
    captureMode: CaptureMode,
    isProfessionalMode: Boolean,
    isCapturing: Boolean,
    photoCaptureProgress: PhotoCaptureProgress?,
    isBurstCapturing: Boolean,
    isVideoRecording: Boolean,
    isVideoProcessing: Boolean,
    isPaused: Boolean,
    allowLongPress: Boolean,
    multipleExposureEnabled: Boolean,
    multipleExposureProgress: Float,
    customStyle: CaptureButtonStyle,
    customColor: Int,
    customImagePath: String?,
    onTap: () -> Unit,
    onLongPressStart: () -> Unit,
    onLongPressEnd: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progressColor = AccentColor
    val showMultipleExposureProgress = captureMode == CaptureMode.PHOTO && multipleExposureEnabled
    val showCaptureProgress = captureMode == CaptureMode.PHOTO && isCapturing
    val showVideoProcessingProgress = captureMode == CaptureMode.VIDEO && isVideoProcessing
    val showActivityProgress = showCaptureProgress || showVideoProcessingProgress
    val progressRingCount = (if (showMultipleExposureProgress) 1 else 0) +
        (if (showActivityProgress) 1 else 0)
    val infiniteTransition = rememberInfiniteTransition(label = "infinite transition")
    var isPressed by remember { mutableStateOf(false) }
    val customImage = remember(customImagePath) {
        customImagePath
            ?.let(::File)
            ?.takeIf(File::isFile)
    }

    val scale by animateFloatAsState(
        targetValue = if (isPressed || isCapturing || isVideoRecording || isVideoProcessing) 0.95f else 1f,
        animationSpec = spring(dampingRatio = 0.5f),
        label = "captureScale"
    )

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "videoPulse"
    )

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1500)),
        label = "captureProgressRotation"
    )

    val captureProgress = rememberPhotoCaptureProgress(
        photoCaptureProgress.takeIf { isCapturing && captureMode == CaptureMode.PHOTO }
    )

    val currentDisabled by rememberUpdatedState(
        isCapturing ||
            isVideoProcessing ||
            (captureMode == CaptureMode.VIDEO && isVideoRecording)
    )

    PhysicalButton(
        modifier = modifier
            .size(CameraControlsLayoutDefaults.CaptureButtonSize)
            .scale(scale)
            .pointerInput(allowLongPress) {
                var isLongPressStarted = false
                detectTapGestures(
                    onTap = {
                        if (!isCapturing && !isVideoProcessing) {
                            onTap()
                        }
                    },
                    onLongPress = if (allowLongPress) {
                        {
                            if (!currentDisabled) {
                                isLongPressStarted = true
                                onLongPressStart()
                            }
                        }
                    } else null,
                    onPress = {
                        isPressed = true
                        isLongPressStarted = false
                        try {
                            tryAwaitRelease()
                        } finally {
                            isPressed = false
                            if (isLongPressStarted) {
                                onLongPressEnd()
                            }
                        }
                    }
                )
            },
        shape = CircleShape,
        contentAlignment = Alignment.Center
    ) {
        val ringColor = when {
            captureMode == CaptureMode.VIDEO && isVideoProcessing ->
                Color.White.copy(alpha = 0.5f)
            captureMode == CaptureMode.VIDEO && isVideoRecording -> {
                if (isPaused) Color.White.copy(alpha = 0.8f)
                else Color.Red.copy(alpha = pulseAlpha)
            }
            else -> Color.White.copy(alpha = 0.32f)
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .border(
                    width = 1.dp,
                    color = ringColor,
                    shape = CircleShape
                )
        )

        // Center shutter surface
        val centerPadding by animateDpAsState(
            targetValue = when {
                captureMode == CaptureMode.VIDEO && isVideoRecording -> 19.dp
                progressRingCount > 0 -> CaptureProgressRingDefaults.contentPadding(progressRingCount)
                else -> 2.dp
            },
            animationSpec = spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessLow),
            label = "centerPadding"
        )
        val centerCorner by animateDpAsState(
            targetValue = if (captureMode == CaptureMode.VIDEO && isVideoRecording) 8.dp else 36.dp,
            label = "centerCorner"
        )
        val defaultCenterBackground = when {
            captureMode == CaptureMode.VIDEO -> {
                Modifier.background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFFFF6668),
                            Color(0xFFE4383C)
                        )
                    )
                )
            }
            isProfessionalMode -> Modifier.background(AccentColor)
            else -> {
                Modifier.background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.White,
                            Color(0xFFD7D7D7)
                        )
                    )
                )
            }
        }
        val useCustomAppearance = captureMode != CaptureMode.VIDEO
        val centerBackgroundModifier = when {
            useCustomAppearance && customStyle == CaptureButtonStyle.COLOR ->
                Modifier.background(Color(customColor))
            else -> defaultCenterBackground
        }

        Box(
            modifier = Modifier
                .padding(centerPadding)
                .fillMaxSize()
                .clip(RoundedCornerShape(centerCorner))
                .then(centerBackgroundModifier)
        ) {
            if (
                useCustomAppearance &&
                customStyle == CaptureButtonStyle.IMAGE &&
                customImage != null
            ) {
                AsyncImage(
                    model = customImage,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .autoRotate(matchParentSize = true)
                )
            }
        }
        if (showMultipleExposureProgress) {
            CaptureProgressRing(
                color = progressColor,
                startAngle = -90f,
                sweepAngle = 360f * multipleExposureProgress.coerceIn(0f, 1f)
            )
        }
        if (showActivityProgress) {
            val isIndeterminate = isBurstCapturing || showVideoProcessingProgress
            CaptureProgressRing(
                color = progressColor,
                startAngle = if (isIndeterminate) rotation - 90f else -90f,
                sweepAngle = if (isIndeterminate) 90f else 360f * captureProgress.value,
                inset = CaptureProgressRingDefaults.OuterInset +
                    if (showMultipleExposureProgress) CaptureProgressRingDefaults.RingSpacing else 0.dp,
                modifier = if (isIndeterminate) Modifier.progressSemantics()
                    else Modifier.progressSemantics(captureProgress.value)
            )
        }
    }
}

@Composable
private fun rememberPhotoCaptureProgress(progress: PhotoCaptureProgress?): State<Float> {
    val fraction = remember(progress) {
        mutableFloatStateOf(progress?.fractionAt(SystemClock.elapsedRealtimeNanos()) ?: 0f)
    }
    LaunchedEffect(progress) {
        if (progress == null) return@LaunchedEffect
        while (isActive && fraction.floatValue < 1f) {
            withFrameNanos {
                fraction.floatValue = progress.fractionAt(SystemClock.elapsedRealtimeNanos())
            }
        }
    }
    return fraction
}

@Composable
private fun CaptureModeSwitcher(
    oppoStyle: Boolean,
    shootingMode: CameraShootingMode,
    enabled: Boolean,
    onModeSelected: (CameraShootingMode) -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier
            .width(228.dp)
            .height(CameraControlsLayoutDefaults.ModeSwitcherHeight)
            .clip(RoundedCornerShape(18.dp))
            .background(if (oppoStyle) Color(0xFF202020) else Color.Black.copy(alpha = 0.28f))
            .border(
                width = 0.5.dp,
                color = if (oppoStyle) Color(0xFF333333) else Color.White.copy(alpha = 0.18f),
                shape = RoundedCornerShape(18.dp)
            )
            .padding(3.dp)
    ) {
        // The visible switcher contains only Photo and Video. Pro/RAW capture
        // internals are preserved but are not exposed as a separate UI mode.
        val knobWidth = maxWidth / 2
        val selectedIndex = if (shootingMode == CameraShootingMode.VIDEO) 1 else 0
        val knobOffset by animateDpAsState(
            targetValue = knobWidth * selectedIndex,
            animationSpec = tween(durationMillis = 220),
            label = "modeSwitcher"
        )
        val selectedBackground by animateColorAsState(
            targetValue = if (oppoStyle) Color(0xFF303030) else Color.White,
            animationSpec = tween(durationMillis = 220),
            label = "modeSwitcherColor"
        )
        Box(
            modifier = Modifier
                .offset(x = knobOffset)
                .width(knobWidth)
                .fillMaxHeight()
                .clip(RoundedCornerShape(15.dp))
                .background(selectedBackground)
        )
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ModeSwitcherItem(
                label = stringResource(R.string.capture_mode_photo) +
                    if (oppoStyle && shootingMode != CameraShootingMode.VIDEO) " ▴" else "",
                selected = shootingMode != CameraShootingMode.VIDEO,
                enabled = enabled,
                onClick = { onModeSelected(CameraShootingMode.PHOTO) },
                modifier = Modifier.weight(1f),
                selectedContentColor = if (oppoStyle) Color(0xFFFF9A32) else Color.Black
            )
            ModeSwitcherItem(
                label = stringResource(R.string.capture_mode_video) +
                    if (oppoStyle && shootingMode == CameraShootingMode.VIDEO) " ▴" else "",
                selected = shootingMode == CameraShootingMode.VIDEO,
                enabled = enabled,
                onClick = { onModeSelected(CameraShootingMode.VIDEO) },
                modifier = Modifier.weight(1f),
                selectedContentColor = if (oppoStyle) Color(0xFFFF9A32) else Color.Black
            )
        }
    }
}

@Composable
private fun ModeSwitcherItem(
    label: String,
    selected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selectedContentColor: Color = Color.Black
) {
    Box(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(20.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = when {
                selected -> selectedContentColor.copy(alpha = 0.88f)
                enabled -> Color.White.copy(alpha = 0.82f)
                else -> Color.White.copy(alpha = 0.3f)
            },
            fontSize = 12.sp,
            lineHeight = 14.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            maxLines = 1
        )
    }
}

private fun cycleVideoResolution(state: CameraState): VideoResolutionPreset? {
    return nextOption(state.videoConfig.resolution, state.videoCapabilities.availableResolutions)
}

private fun cycleVideoFps(state: CameraState): VideoFpsPreset? {
    return nextOption(state.videoConfig.fps, state.videoCapabilities.availableFps)
}

private fun cycleVideoAspectRatio(state: CameraState): VideoAspectRatio? {
    return nextOption(state.videoConfig.aspectRatio, state.videoCapabilities.availableAspectRatios)
}

private fun cycleVideoLogProfile(state: CameraState): VideoLogProfile? {
    return nextOption(state.videoConfig.logProfile, state.videoCapabilities.availableLogProfiles)
}

private fun <T> nextOption(current: T, options: List<T>): T? {
    if (options.isEmpty()) return null
    val currentIndex = options.indexOf(current)
    return if (currentIndex == -1) {
        options.firstOrNull()
    } else {
        options[(currentIndex + 1) % options.size]
    }
}


fun Modifier.autoRotate(
    dx: Dp = 0.dp,
    dy: Dp = 0.dp,
    matchParentSize: Boolean = false
): Modifier = composed {
    val targetDegrees =
        if (OrientationObserver.rotationDegrees != 0f) OrientationObserver.rotationDegrees - 180 else 0f

    val animatedDegrees by animateFloatAsState(
        targetValue = targetDegrees,
        animationSpec = tween(durationMillis = 300),
        label = "rotationAnimation"
    )

    layout { measurable, constraints ->
        val rad = Math.toRadians(animatedDegrees.toDouble())
        val cos = abs(cos(rad))
        val sin = abs(sin(rad))

        // 核心优化：匹配父布局大小时，如果旋转接近 90 度，交换约束，
        // 从而让子组件（如 AsyncImage）按旋转后的方向进行测量，实现“铺满”效果。
        val modifiedConstraints = if (matchParentSize && sin > 0.5f) {
            Constraints(
                minWidth = constraints.minHeight,
                maxWidth = constraints.maxHeight,
                minHeight = constraints.minWidth,
                maxHeight = constraints.maxWidth
            )
        } else {
            constraints
        }

        val placeable = measurable.measure(modifiedConstraints)
        val width = placeable.width
        val height = placeable.height

        if (matchParentSize) {
            val visualWidth = width * cos + height * sin
            val visualHeight = width * sin + height * cos

            val containerWidth = constraints.maxWidth.toFloat()
            val containerHeight = constraints.maxHeight.toFloat()

            // 计算缩放：确保即使在动画中，内容也能刚好填满或不超出边界
            val scale = min(
                if (visualWidth > 0) containerWidth / visualWidth else 1.0,
                if (visualHeight > 0) containerHeight / visualHeight else 1.0
            ).toFloat().coerceAtMost(1.0f)

            layout(constraints.maxWidth, constraints.maxHeight) {
                placeable.placeRelativeWithLayer(
                    (constraints.maxWidth - width) / 2,
                    (constraints.maxHeight - height) / 2
                ) {
                    rotationZ = animatedDegrees
                    scaleX = scale
                    scaleY = scale
                }
            }
        } else {
            val newWidth = (placeable.width * cos + placeable.height * sin).toInt()
            val newHeight = (placeable.width * sin + placeable.height * cos).toInt()

            val nDx = dx.toPx() * sin
            val nDy = dy.toPx() * sin

            layout(newWidth, newHeight) {
                placeable.placeRelativeWithLayer(
                    x = (newWidth - placeable.width) / 2 + nDx.toInt(),
                    y = (newHeight - placeable.height) / 2 + nDy.toInt()
                ) {
                    rotationZ = animatedDegrees
                }
            }
        }
    }
}

@Composable
private fun CornerOverlay(
    modifier: Modifier = Modifier,
    radius: Dp,
    color: Color = Color.Black
) {
    Canvas(modifier = modifier) {
        val frame = Path().apply {
            addRect(Rect(0f, 0f, size.width, size.height))
        }
        val roundedContent = Path().apply {
            addRoundRect(
                RoundRect(
                    left = 0f,
                    top = 0f,
                    right = size.width,
                    bottom = size.height,
                    cornerRadius = CornerRadius(radius.toPx(), radius.toPx())
                )
            )
        }
        frame.op(frame, roundedContent, PathOperation.Difference)
        drawPath(frame, color)
    }
}


private fun Context.findActivity(): Activity? {
    var context = this
    while (context is ContextWrapper) {
        if (context is Activity) return context
        context = context.baseContext
    }
    return null
}
