package com.hinnka.mycamera.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.hinnka.mycamera.gallery.MediaData
import com.hinnka.mycamera.viewmodel.GalleryViewModel
import com.hinnka.mycamera.viewmodel.CapturedThumbnail
import com.hinnka.mycamera.ui.icons.AppIcons

/**
 * 相册入口缩略图组件
 * 显示最近拍摄的照片缩略图，点击进入相册
 */
@Composable
fun GalleryThumbnail(
    latestPhoto: MediaData?,
    viewModel: GalleryViewModel,
    onClick: () -> Unit,
    capturedThumbnail: CapturedThumbnail? = null,
    onCapturedThumbnailLoaded: (Long) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val refreshKey = latestPhoto?.id?.let { viewModel.getPreparedPhotoThumbnailRefreshKey(it) } ?: 0L
    val buttonShape = RoundedCornerShape(10.dp)
    val thumbnailShape = RoundedCornerShape(7.dp)
    var finalThumbnailLoaded by remember(capturedThumbnail?.captureId) { mutableStateOf(false) }
    val finalCaptureId = capturedThumbnail?.takeIf {
        it.processingFinished && it.savedPhotoId == latestPhoto?.id
    }?.captureId
    val capturePreview = capturedThumbnail?.bitmap?.takeUnless { finalThumbnailLoaded || it.isRecycled }

    PhysicalButton(
        modifier = modifier
            .size(48.dp),
        onClick = onClick,
        shape = buttonShape,
        contentShape = thumbnailShape
    ) {
        if (latestPhoto != null) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(latestPhoto.thumbnailUri)
                    .memoryCacheKey(
                        "gallery_thumbnail_${latestPhoto.id}_${latestPhoto.thumbnailUri}_${refreshKey}_${finalCaptureId}"
                    )
                    .crossfade(capturePreview == null)
                    .build(),
                onSuccess = {
                    if (finalCaptureId != null) {
                        finalThumbnailLoaded = true
                        onCapturedThumbnailLoaded(finalCaptureId)
                    }
                },
                contentDescription = "Gallery",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (latestPhoto.isVideo) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.08f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.14f)
                            )
                        )
                    )
            )
        } else {
            // 没有照片时显示图标
            Icon(
                imageVector = AppIcons.PhotoLibrary,
                contentDescription = "Gallery",
                tint = Color.White.copy(alpha = 0.7f),
                modifier = Modifier.size(24.dp)
            )
        }
        // Keep the shutter preview above the file-backed image until this same capture's
        // final file has decoded. Older saves and loading placeholders cannot replace it.
        if (capturePreview != null) {
            Image(
                bitmap = capturePreview.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
