package com.example.camera.ui.components

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.*

/**
 * Logarithmic zoom mapping helpers shared between MasterZoomCapsule and HorizontalRulerZoomSlider
 * so opening the slider via a swipe uses the exact same physical ruler scale.
 */
fun zoomToNormalizedLog(zoom: Float, minZ: Float, maxZ: Float): Float {
    val safeMin = minZ.coerceAtLeast(0.3f)
    val safeMax = maxZ.coerceAtLeast(safeMin + 0.05f)
    val logMin = ln(safeMin.toDouble())
    val logMax = ln(safeMax.toDouble())
    if (logMax <= logMin) return 0f
    val logZ = ln(zoom.coerceIn(safeMin, safeMax).toDouble())
    return ((logZ - logMin) / (logMax - logMin)).toFloat().coerceIn(0f, 1f)
}

fun normalizedToZoomLog(t: Float, minZ: Float, maxZ: Float): Float {
    val safeMin = minZ.coerceAtLeast(0.3f)
    val safeMax = maxZ.coerceAtLeast(safeMin + 0.05f)
    if (safeMax <= safeMin) return safeMin
    val logMin = ln(safeMin.toDouble())
    val logMax = ln(safeMax.toDouble())
    val logZ = logMin + t.coerceIn(0f, 1f) * (logMax - logMin)
    val rawZoom = exp(logZ).toFloat()
    return rawZoom.coerceIn(safeMin, safeMax)
}

const val RULER_TOTAL_TICKS = 120
val RULER_TICK_SPACING_DP = 6.5.dp
const val ZOOM_SLIDER_DRAG_SENSITIVITY = 1.35f

/**
 * Flagship Horizontal Ruler Zoom Slider matching the reference camera UI:
 * - Floating live zoom text in prominent gold/yellow (e.g. "5.0 x") centered above the capsule.
 * - Dark translucent horizontal pill with rounded corners.
 * - Continuous horizontal tick-mark ruler with major and minor markings.
 * - Prominent vertical yellow center indicator line marking the active zoom level.
 * - Circular dismiss ('✕') button on the right edge.
 * - Smooth logarithmic zoom mapping from minZoom (e.g. 0.5x) to maxZoom (e.g. 10x/20x/30x).
 */
@Composable
fun HorizontalRulerZoomSlider(
    currentZoom: Float,
    minZoom: Float = 0.5f,
    maxZoom: Float = 20.0f,
    onZoomChange: (Float) -> Unit,
    onClose: () -> Unit,
    isExternalDragging: Boolean = false,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var autoHideJob by remember { mutableStateOf<Job?>(null) }

    fun restartAutoHideTimer() {
        autoHideJob?.cancel()
        autoHideJob = coroutineScope.launch {
            delay(4000L) // Auto-hide after 4 seconds of inactivity
            onClose()
        }
    }

    LaunchedEffect(Unit) {
        restartAutoHideTimer()
    }

    DisposableEffect(Unit) {
        onDispose {
            autoHideJob?.cancel()
        }
    }

    val safeMinZoom = minZoom.coerceAtLeast(0.3f)
    val safeMaxZoom = maxZoom.coerceAtLeast(safeMinZoom + 0.05f)

    val onZoomChangeState = rememberUpdatedState(onZoomChange)
    val safeMinZoomState = rememberUpdatedState(safeMinZoom)
    val safeMaxZoomState = rememberUpdatedState(safeMaxZoom)

    val density = LocalDensity.current
    val totalTicks = RULER_TOTAL_TICKS
    val tickSpacingDp = RULER_TICK_SPACING_DP
    val tickSpacingPx = with(density) { tickSpacingDp.toPx() }
    val totalRulerWidthPx = totalTicks * tickSpacingPx

    var isDragging by remember { mutableStateOf(false) }
    var activeZoom by remember { mutableFloatStateOf(currentZoom.coerceIn(safeMinZoom, safeMaxZoom)) }
    var accumulatedNorm by remember {
        mutableFloatStateOf(zoomToNormalizedLog(currentZoom, safeMinZoom, safeMaxZoom))
    }
    var lastUserDragEndTimeMs by remember { mutableLongStateOf(0L) }

    // Keep accumulatedNorm anchored to activeZoom if minZoom/maxZoom bounds update mid-drag (e.g. lens switch)
    LaunchedEffect(safeMinZoom, safeMaxZoom) {
        activeZoom = activeZoom.coerceIn(safeMinZoom, safeMaxZoom)
        accumulatedNorm = zoomToNormalizedLog(activeZoom, safeMinZoom, safeMaxZoom)
    }

    // Synchronize active zoom with external updates:
    // - Always sync immediately while external capsule-opening drag is in progress
    // - When not dragging, ignore stale asynchronous background echoes within 220ms of drag release
    LaunchedEffect(currentZoom, isExternalDragging) {
        if (isExternalDragging) {
            restartAutoHideTimer()
            val clamped = currentZoom.coerceIn(safeMinZoom, safeMaxZoom)
            activeZoom = clamped
            accumulatedNorm = zoomToNormalizedLog(clamped, safeMinZoom, safeMaxZoom)
            lastUserDragEndTimeMs = SystemClock.uptimeMillis()
        } else if (!isDragging) {
            val now = SystemClock.uptimeMillis()
            val isWithinCooldown = (now - lastUserDragEndTimeMs) < 220L
            if (!isWithinCooldown) {
                val clamped = currentZoom.coerceIn(safeMinZoom, safeMaxZoom)
                activeZoom = clamped
                accumulatedNorm = zoomToNormalizedLog(clamped, safeMinZoom, safeMaxZoom)
            }
        }
    }

    Column(
        modifier = modifier
            .widthIn(min = 320.dp, max = 380.dp)
            .padding(horizontal = 8.dp)
            .testTag("horizontal_ruler_zoom_slider"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. Live Zoom Indicator (continuous float updates e.g. "0.51 x  •  16mm")
        val focalLengthMm = com.example.camera.engine.CameraOpticalCalibration.zoomToFocalLengthMm(activeZoom).roundToInt()
        val zoomDisplayStr = if (activeZoom < 2.0f) {
            String.format(java.util.Locale.US, "%.2f x  •  %dmm", activeZoom, focalLengthMm)
        } else {
            String.format(java.util.Locale.US, "%.1f x  •  %dmm", activeZoom, focalLengthMm)
        }
        Text(
            text = zoomDisplayStr,
            color = Color(0xFFFFD54F),
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.SansSerif,
            letterSpacing = 0.5.sp,
            modifier = Modifier
                .padding(bottom = 6.dp)
                .testTag("zoom_slider_value_text")
        )

        // 2. Translucent Ruler Capsule Container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Color(0xCC18191E))
                .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(26.dp))
                .padding(start = 12.dp, end = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Interactive Tick Ruler with unified zero-slop drag and tap handling.
                // Keyed only on totalRulerWidthPx so capability/lens updates never cancel an active swipe.
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .pointerInput(totalRulerWidthPx) {
                            val dragThresholdPx = 1.5f
                            awaitEachGesture {
                                val down = awaitFirstDown(requireUnconsumed = false)
                                restartAutoHideTimer()

                                val downX = down.position.x
                                var lastX = downX
                                var hasDragged = false
                                val pointerId = down.id

                                // Anchor normalized ruler position to the live displayed zoom at touch-down
                                accumulatedNorm = zoomToNormalizedLog(
                                    activeZoom,
                                    safeMinZoomState.value,
                                    safeMaxZoomState.value
                                )

                                while (true) {
                                    val event = awaitPointerEvent()
                                    val change = event.changes.firstOrNull { it.id == pointerId }
                                        ?: event.changes.firstOrNull()
                                        ?: break

                                    if (!change.pressed) {
                                        change.consume()
                                        break
                                    }

                                    val currentX = change.position.x
                                    val totalDx = currentX - downX

                                    if (!hasDragged && abs(totalDx) >= dragThresholdPx) {
                                        hasDragged = true
                                        isDragging = true
                                        // Apply the full initial finger movement from touch-down so zero drag distance is lost
                                        val minZ = safeMinZoomState.value
                                        val maxZ = safeMaxZoomState.value
                                        val deltaNorm = (-totalDx * ZOOM_SLIDER_DRAG_SENSITIVITY) / totalRulerWidthPx
                                        accumulatedNorm = (accumulatedNorm + deltaNorm).coerceIn(0f, 1f)
                                        val newZoom = normalizedToZoomLog(accumulatedNorm, minZ, maxZ)
                                        activeZoom = newZoom
                                        lastX = currentX
                                        change.consume()
                                        restartAutoHideTimer()
                                        onZoomChangeState.value(newZoom)
                                    } else if (hasDragged) {
                                        val stepDx = currentX - lastX
                                        lastX = currentX
                                        if (abs(stepDx) > 0.01f) {
                                            val minZ = safeMinZoomState.value
                                            val maxZ = safeMaxZoomState.value
                                            val deltaNorm = (-stepDx * ZOOM_SLIDER_DRAG_SENSITIVITY) / totalRulerWidthPx
                                            accumulatedNorm = (accumulatedNorm + deltaNorm).coerceIn(0f, 1f)
                                            val newZoom = normalizedToZoomLog(accumulatedNorm, minZ, maxZ)
                                            activeZoom = newZoom
                                            restartAutoHideTimer()
                                            onZoomChangeState.value(newZoom)
                                        }
                                        change.consume()
                                    }
                                }

                                if (hasDragged) {
                                    isDragging = false
                                    lastUserDragEndTimeMs = SystemClock.uptimeMillis()
                                    restartAutoHideTimer()
                                } else {
                                    // Touching or tapping on ruler without dragging: keep zoom level unchanged without resetting
                                    isDragging = false
                                    lastUserDragEndTimeMs = SystemClock.uptimeMillis()
                                    restartAutoHideTimer()
                                }
                            }
                        }
                        .testTag("zoom_ruler_canvas_container")
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val centerX = size.width / 2f
                        val centerY = size.height / 2f

                        val currentNorm = zoomToNormalizedLog(activeZoom, safeMinZoom, safeMaxZoom)
                        val currentScrollPx = currentNorm * totalRulerWidthPx

                        // Draw moving ticks with generous padding on both ends so ruler continues smoothly
                        // and never appears blank or abruptly truncated at 10x..20x or 0.5x
                        val extraVisibleTicks = ceil((size.width / 2f) / tickSpacingPx).toInt() + 15
                        val startTick = -extraVisibleTicks
                        val endTick = totalTicks + extraVisibleTicks

                        for (i in startTick..endTick) {
                            val tickX = centerX - currentScrollPx + (i * tickSpacingPx)

                            // Only draw visible ticks inside canvas
                            if (tickX in -10f..(size.width + 10f)) {
                                val distFromCenter = abs(tickX - centerX) / (size.width / 2f)
                                val alpha = (1f - distFromCenter.pow(1.8f)).coerceIn(0f, 1f)

                                if (alpha > 0.02f) {
                                    val isMajor = (abs(i) % 5 == 0)
                                    val tickHeight = if (isMajor) 18.dp.toPx() else 11.dp.toPx()
                                    val strokeW = if (isMajor) 1.5.dp.toPx() else 1.0.dp.toPx()
                                    val tickColor = if (isMajor) {
                                        Color.White.copy(alpha = alpha * 0.95f)
                                    } else {
                                        Color.White.copy(alpha = alpha * 0.45f)
                                    }

                                    drawLine(
                                        color = tickColor,
                                        start = Offset(tickX, centerY - tickHeight / 2f),
                                        end = Offset(tickX, centerY + tickHeight / 2f),
                                        strokeWidth = strokeW,
                                        cap = StrokeCap.Round
                                    )
                                }
                            }
                        }

                        // Fixed Center Indicator (Yellow vertical bar matching reference image)
                        val indicatorHeight = 24.dp.toPx()
                        val indicatorWidth = 2.5.dp.toPx()
                        drawLine(
                            color = Color(0xFFFFD54F),
                            start = Offset(centerX, centerY - indicatorHeight / 2f),
                            end = Offset(centerX, centerY + indicatorHeight / 2f),
                            strokeWidth = indicatorWidth,
                            cap = StrokeCap.Round
                        )
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Dismiss / Close Button ('✕')
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(0x33FFFFFF))
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() }
                        ) {
                            onClose()
                        }
                        .testTag("zoom_slider_close_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Zoom Slider",
                        tint = Color.White.copy(alpha = 0.9f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
