package com.example.camera.engine

import android.content.Context
import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import androidx.test.core.app.ApplicationProvider
import com.example.camera.model.LensInfo
import com.example.camera.model.LensType
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PhotonCameraLensSwitchingTest {

    private lateinit var context: Context
    private lateinit var engine: Camera2Engine

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        engine = Camera2Engine(context)
    }

    @Test
    fun testCameraDiscoveryCreatesCleanInventory() {
        val count = engine.detectHardwareLenses()
        assertTrue("Camera inventory should discover at least 1 lens", count >= 1)
        val lenses = engine.availableLenses.value
        assertTrue("Available lenses must not be empty", lenses.isNotEmpty())

        // Verify primary main lens exists and is marked as primary
        val mainLens = lenses.firstOrNull { it.isPrimaryMain }
        assertNotNull("Primary main lens should exist", mainLens)
        assertEquals(1.0f, mainLens!!.baseZoomRatio, 0.001f)
    }

    @Test
    fun testResolveSwitchStrategyDifferentiatesIndependentAndLogical() {
        val mainLens = LensInfo(
            cameraId = "0",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.WIDE,
            displayName = "1x Main",
            focalLengthMm = 5.0f,
            maxAperture = 1.8f,
            isPrimaryMain = true,
            isLogicalMultiCamera = true,
            isIndependentCamera = true,
            baseZoomRatio = 1.0f
        )

        val frontLens = LensInfo(
            cameraId = "1",
            facing = CameraCharacteristics.LENS_FACING_FRONT,
            lensType = LensType.FRONT,
            displayName = "Front Selfie",
            focalLengthMm = 3.5f,
            maxAperture = 2.0f,
            isIndependentCamera = true,
            baseZoomRatio = 1.0f
        )

        val physicalUltraWide = LensInfo(
            cameraId = "0",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.ULTRAWIDE,
            displayName = "0.5x Ultra Wide",
            focalLengthMm = 2.0f,
            maxAperture = 2.2f,
            isLogicalMultiCamera = true,
            supportsPhysicalStream = true,
            physicalCameraId = "2",
            baseZoomRatio = 0.5f
        )

        val logicalZoomUltraWide = LensInfo(
            cameraId = "0",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.ULTRAWIDE,
            displayName = "0.5x Ultra Wide",
            focalLengthMm = 2.0f,
            maxAperture = 2.2f,
            isLogicalMultiCamera = true,
            supportsPhysicalStream = false,
            baseZoomRatio = 0.5f
        )

        // Switch Back to Front -> INDEPENDENT_DEVICE
        val stratBackToFront = CameraDiscovery.resolveSwitchStrategy(mainLens, frontLens)
        assertEquals(LensSwitchStrategy.INDEPENDENT_DEVICE, stratBackToFront)

        // Switch Front to Back -> INDEPENDENT_DEVICE
        val stratFrontToBack = CameraDiscovery.resolveSwitchStrategy(frontLens, mainLens)
        assertEquals(LensSwitchStrategy.INDEPENDENT_DEVICE, stratFrontToBack)

        // Switch Main to Physical Stream UltraWide -> LOGICAL_PHYSICAL_STREAM
        val stratMainToPhys = CameraDiscovery.resolveSwitchStrategy(mainLens, physicalUltraWide)
        assertEquals(LensSwitchStrategy.LOGICAL_PHYSICAL_STREAM, stratMainToPhys)

        // Switch Main to Logical Zoom UltraWide -> LOGICAL_ZOOM
        val stratMainToLogZoom = CameraDiscovery.resolveSwitchStrategy(mainLens, logicalZoomUltraWide)
        assertEquals(LensSwitchStrategy.LOGICAL_ZOOM, stratMainToLogZoom)
    }

    @Test
    fun testZoomPreservationAcrossLensSwitches() {
        val mainLens = LensInfo(
            cameraId = "0",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.WIDE,
            displayName = "1x Main",
            focalLengthMm = 5.0f,
            maxAperture = 1.8f,
            isPrimaryMain = true,
            baseZoomRatio = 1.0f
        )

        val teleLens = LensInfo(
            cameraId = "0",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.TELEPHOTO,
            displayName = "2x Telephoto",
            focalLengthMm = 10.0f,
            maxAperture = 2.4f,
            isLogicalMultiCamera = true,
            supportsPhysicalStream = true,
            physicalCameraId = "3",
            baseZoomRatio = 2.0f
        )

        // Explicit lens selection without preserving zoom resets to lens base zoom
        engine.selectLens(mainLens, preserveZoom = false)
        assertEquals(1.0f, engine.currentZoom, 0.001f)

        // Switching with target zoom preserves the target zoom level
        engine.selectLens(teleLens, preserveZoom = true, targetZoom = 3.5f)
        assertEquals(3.5f, engine.currentZoom, 0.001f)
    }

    @Test
    fun testRapidRepeatedLensSwitchingDoesNotLockState() {
        val lenses = engine.availableLenses.value
        if (lenses.size >= 2) {
            val lens1 = lenses[0]
            val lens2 = lenses[1]

            // Simulate rapid user tapping back and forth between lenses
            for (i in 0..5) {
                engine.selectLens(lens1)
                engine.selectLens(lens2)
            }

            // Engine should still be alive and responsive
            assertNotNull(engine.selectedLens.value)
        }
    }

    @Test
    fun testOptimalPhotoSizeNeverFailsForAnyLens() {
        val lenses = engine.availableLenses.value
        for (lens in lenses) {
            val size = engine.getOptimalPhotoSizeForLens(lens, lens.cameraId)
            assertNotNull("Photo size should be resolved for ${lens.displayName}", size)
            assertTrue("Width should be positive", size.width > 0)
            assertTrue("Height should be positive", size.height > 0)
        }
    }

    @Test
    fun testKeepUltraWideReadyDefaultOn() {
        val prefs = com.example.camera.data.CameraPreferences(context)
        assertTrue("Keep Ultra Wide Ready must be ON by default in preferences", prefs.isKeepUltraWideReady)
        assertTrue("Keep Ultra Wide Ready must be ON by default in engine", engine.isKeepUltraWideReady.value)
    }

    @Test
    fun testKeepUltraWideReadyTogglePersistsAndUpdatesState() {
        val prefs = com.example.camera.data.CameraPreferences(context)
        engine.setKeepUltraWideReady(true)
        assertTrue("Setting Keep Ultra Wide Ready to true must update engine state", engine.isKeepUltraWideReady.value)
        assertTrue("Setting Keep Ultra Wide Ready to true must persist in preferences", prefs.isKeepUltraWideReady)

        engine.setKeepUltraWideReady(false)
        assertFalse("Setting Keep Ultra Wide Ready to false must update engine state", engine.isKeepUltraWideReady.value)
        assertFalse("Setting Keep Ultra Wide Ready to false must persist in preferences", prefs.isKeepUltraWideReady)
    }

    @Test
    fun testKeepUltraWideReadyInstantSwitchMainAndUltraWide() {
        engine.detectHardwareLenses()
        val lenses = engine.availableLenses.value
        val mainLens = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }
        val ultraWideLens = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }

        assertNotNull("Main lens should be detected", mainLens)
        engine.selectLens(mainLens!!)
        assertEquals(mainLens.id, engine.selectedLens.value?.id)

        // Enable Keep Ultra Wide Ready
        engine.setKeepUltraWideReady(true)
        assertTrue(engine.isKeepUltraWideReady.value)

        // If an ultra-wide lens is present, test instant digital switch
        if (ultraWideLens != null) {
            engine.selectLens(ultraWideLens)
            assertEquals(ultraWideLens.id, engine.selectedLens.value?.id)

            // Switch back to Main
            engine.selectLens(mainLens)
            assertEquals(mainLens.id, engine.selectedLens.value?.id)
        }
    }

    @Test
    fun testOneXToHalfXSmoothTransitionInterpolatesCorrectly() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.camera.viewmodel.CameraViewModel(app)
        viewModel.setZoom(1.0f, isPresetTap = false)
        assertEquals(1.0f, viewModel.currentZoom.value, 0.001f)

        // Trigger 0.5x preset tap from 1.0x
        viewModel.setZoom(0.5f, isPresetTap = true)

        // Smooth transition job should be active and current zoom smoothly transitioning down
        assertTrue(viewModel.currentZoom.value <= 1.0f)
    }

    @Test
    fun testSmoothTransitionBetweenHalfXAndOneXBothWays() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.camera.viewmodel.CameraViewModel(app)
        // Transition down from 1.0x to 0.5x
        viewModel.setZoom(1.0f, isPresetTap = false)
        viewModel.setZoom(0.5f, isPresetTap = true)
        assertTrue(viewModel.currentZoom.value <= 1.0f)

        // Transition up from 0.5x to 1.0x
        viewModel.startSmoothLensTransition(fromZoom = 0.5f, targetZoom = 1.0f)
        assertTrue(viewModel.currentZoom.value >= 0.5f)
    }

    @Test
    fun testSmoothTransitionOtherLensSwitches() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.camera.viewmodel.CameraViewModel(app)
        viewModel.setZoom(1.0f, isPresetTap = false)
        assertEquals(1.0f, viewModel.currentZoom.value, 0.001f)

        // Trigger 2.0x preset tap from 1.0x
        viewModel.setZoom(2.0f, isPresetTap = true)

        // Smooth transition should be active and current zoom smoothly transitioning up
        assertTrue(viewModel.currentZoom.value >= 1.0f)
    }

    @Test
    fun testKeepUltraWideReadyPhysicalSwitchVerified() {
        engine.detectHardwareLenses()
        val lenses = engine.availableLenses.value
        val mainLens = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }
        val ultraWideLens = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }

        assertNotNull("Main lens must exist", mainLens)
        engine.selectLens(mainLens!!)
        engine.setKeepUltraWideReady(true)

        if (ultraWideLens != null) {
            engine.selectLens(ultraWideLens)
            // Tapping 0.5x / selecting Ultra-Wide must genuinely set selected lens to Ultra-Wide
            assertEquals(ultraWideLens.id, engine.selectedLens.value?.id)
            assertEquals(LensType.ULTRAWIDE, engine.selectedLens.value?.lensType)

            // Switch back to 1x Main
            engine.selectLens(mainLens)
            assertEquals(mainLens.id, engine.selectedLens.value?.id)
            assertEquals(LensType.WIDE, engine.selectedLens.value?.lensType)
        }
    }

    @Test
    fun testSliderRangeInvariantToActiveLens() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.camera.viewmodel.CameraViewModel(app)
        viewModel.engine.detectHardwareLenses()
        val lenses = viewModel.engine.availableLenses.value
        val hasRealUltraWide = lenses.any { it.lensType == LensType.ULTRAWIDE }

        // Slider minimum must always be 0.5f if Ultra-wide exists, regardless of whether 1x or 2x is active
        if (hasRealUltraWide) {
            val minZoomAt1x = if (hasRealUltraWide) 0.5f else 1.0f
            assertEquals(0.5f, minZoomAt1x, 0.001f)

            // When at 1.0x, dragging backward below 1.0x must be valid and allowed
            viewModel.setZoom(1.0f, isPresetTap = false)
            assertEquals(1.0f, viewModel.currentZoom.value, 0.001f)

            viewModel.setZoom(0.8f, isPresetTap = false)
            assertEquals(0.8f, viewModel.currentZoom.value, 0.001f)

            viewModel.setZoom(0.5f, isPresetTap = false)
            assertEquals(0.5f, viewModel.currentZoom.value, 0.001f)

            // Dragging forward from 0.5x up to 10x must also be smooth and allowed
            viewModel.setZoom(1.5f, isPresetTap = false)
            assertEquals(1.5f, viewModel.currentZoom.value, 0.001f)
        }
    }

    @Test
    fun testNeverShowCroppedUltraWideAtOneX() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.camera.viewmodel.CameraViewModel(app)
        viewModel.engine.detectHardwareLenses()
        val lenses = viewModel.engine.availableLenses.value
        val hasRealUltraWide = lenses.any { it.lensType == LensType.ULTRAWIDE }

        if (hasRealUltraWide) {
            // At exactly 1.000x, target lens must strictly be Main Wide
            val resolvedAt1x = CameraOpticalCalibration.resolveTargetLensType(
                currentLensType = LensType.ULTRAWIDE,
                targetZoom = 1.000f,
                hasUltraWide = true,
                hasTelephoto2x = false,
                hasTelephoto3x = false,
                isPresetTap = false
            )
            assertEquals(LensType.WIDE, resolvedAt1x)

            // At 0.999x, Ultra-wide is allowed
            val resolvedAt0999x = CameraOpticalCalibration.resolveTargetLensType(
                currentLensType = LensType.ULTRAWIDE,
                targetZoom = 0.999f,
                hasUltraWide = true,
                hasTelephoto2x = false,
                hasTelephoto3x = false,
                isPresetTap = false
            )
            assertEquals(LensType.ULTRAWIDE, resolvedAt0999x)
        }
    }

    @Test
    fun testAutoSwitchToUltraWideSettingDefaultOff() {
        val prefs = com.example.camera.data.CameraPreferences(context)
        assertFalse("Auto switch to Ultra Wide must be OFF by default in preferences", prefs.isAutoSwitchToUltraWide)
        assertFalse("Auto switch to Ultra Wide must be OFF by default in engine", engine.isAutoSwitchToUltraWide.value)
    }

    @Test
    fun testAutoSwitchToUltraWideTogglePersistsAndUpdatesState() {
        val prefs = com.example.camera.data.CameraPreferences(context)
        engine.setAutoSwitchToUltraWide(true)
        assertTrue("Setting Auto Switch to true must update engine state", engine.isAutoSwitchToUltraWide.value)
        assertTrue("Setting Auto Switch to true must persist in preferences", prefs.isAutoSwitchToUltraWide)

        engine.setAutoSwitchToUltraWide(false)
        assertFalse("Setting Auto Switch to false must update engine state", engine.isAutoSwitchToUltraWide.value)
        assertFalse("Setting Auto Switch to false must persist in preferences", prefs.isAutoSwitchToUltraWide)
    }

    @Test
    fun testAutoLensSwitchOnCloseSubjectAndAwayWithHysteresis() {
        engine.detectHardwareLenses()
        val lenses = engine.availableLenses.value
        val mainLens = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }
        val ultraWideLens = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }

        if (mainLens != null && ultraWideLens != null) {
            engine.selectLens(mainLens)
            assertEquals(mainLens.id, engine.selectedLens.value?.id)

            // Enable Auto Switch to Ultra Wide
            engine.setAutoSwitchToUltraWide(true)
            assertTrue(engine.isAutoSwitchToUltraWide.value)

            // Simulate close subject (9.0 diopters) with struggling focus for 12 frames
            for (i in 1..12) {
                engine.simulateAfConditionForTesting(
                    afState = android.hardware.camera2.CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED,
                    focusDistance = 9.0f,
                    minFocusDistance = 10.0f
                )
            }

            // Must have auto-switched to the REAL ultra-wide lens
            assertTrue("Auto macro state should be active", engine.isAutoMacroActive.value)
            assertEquals("Should have switched to ultra wide lens", ultraWideLens.id, engine.selectedLens.value?.id)

            // Advance time past cooldown
            val nowMs = android.os.SystemClock.uptimeMillis() + 2500L
            // Simulate subject moving away (< 4.0 diopters) for 15 frames
            for (i in 1..16) {
                engine.processAfCondition(
                    afState = android.hardware.camera2.CaptureResult.CONTROL_AF_STATE_PASSIVE_FOCUSED,
                    focusDistance = 2.0f,
                    minFocusDistance = 10.0f,
                    currentLens = ultraWideLens,
                    mainLens = mainLens,
                    ultraWideLens = ultraWideLens,
                    nowMs = nowMs
                )
            }

            // Must have auto-switched back to the REAL main lens
            assertFalse("Auto macro state should be cleared", engine.isAutoMacroActive.value)
            assertEquals("Should have switched back to main lens", mainLens.id, engine.selectedLens.value?.id)
        }
    }

    @Test
    fun testTappingHalfXSwitchesToRealUltraWideLens() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.camera.viewmodel.CameraViewModel(app)
        viewModel.engine.detectHardwareLenses()
        val lenses = viewModel.engine.availableLenses.value
        val ultraWideLens = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }
        val mainLens = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }

        if (ultraWideLens != null && mainLens != null) {
            viewModel.engine.selectLens(mainLens)
            assertEquals(mainLens.id, viewModel.engine.selectedLens.value?.id)

            // Tap 0.5x preset
            viewModel.setZoom(0.5f, isPresetTap = true)

            // Selected lens must immediately be the real Ultra-Wide camera at .999x with no visible FOV jump
            assertEquals(ultraWideLens.id, viewModel.engine.selectedLens.value?.id)
            assertEquals(LensType.ULTRAWIDE, viewModel.engine.selectedLens.value?.lensType)
        }
    }

    @Test
    fun testOneXToHalfXTransitionFirstSwitchesToUltraWideAtPointNineNineNine() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.camera.viewmodel.CameraViewModel(app)
        viewModel.engine.detectHardwareLenses()
        val lenses = viewModel.engine.availableLenses.value
        val ultraWideLens = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }
        val mainLens = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }

        if (ultraWideLens != null && mainLens != null) {
            viewModel.engine.selectLens(mainLens)
            viewModel.setZoom(1.0f, isPresetTap = false)
            assertEquals(1.0f, viewModel.currentZoom.value, 0.001f)

            // Trigger 1x -> .5x transition
            viewModel.startSmoothOneXToHalfXTransition(fromZoom = 1.0f, targetZoom = 0.5f)

            // First action: must switch target to Ultra-Wide lens and smoothly transition zoom down
            assertEquals(ultraWideLens.id, viewModel.engine.selectedLens.value?.id)
            assertEquals(LensType.ULTRAWIDE, viewModel.engine.selectedLens.value?.lensType)
            assertTrue("Zoom must start and smoothly transition down", viewModel.currentZoom.value <= 1.0f && viewModel.currentZoom.value >= 0.5f)
        }
    }

    @Test
    fun testHalfXToOneXTransitionTransitionsToPointNineNineNineThenSwitchesToMainAtOneX() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.camera.viewmodel.CameraViewModel(app)
        viewModel.engine.detectHardwareLenses()
        val lenses = viewModel.engine.availableLenses.value
        val ultraWideLens = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }
        val mainLens = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }

        if (ultraWideLens != null && mainLens != null) {
            viewModel.engine.selectLens(ultraWideLens)
            viewModel.setZoom(0.5f, isPresetTap = false)
            assertEquals(0.5f, viewModel.currentZoom.value, 0.001f)

            // Trigger .5x -> 1x transition
            viewModel.startSmoothHalfXToOneXTransition(fromZoom = 0.5f)

            // During initial transition, must stay on Ultra-Wide lens and zoom towards .999x
            assertEquals(ultraWideLens.id, viewModel.engine.selectedLens.value?.id)
            assertTrue("Zoom must transition up from .5x towards .999x", viewModel.currentZoom.value >= 0.5f && viewModel.currentZoom.value <= 1.0f)
        }
    }

    @Test
    fun testKeepUltraWideReadyEnablesSmoothTransitionBetweenHalfXAndOneX() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.camera.viewmodel.CameraViewModel(app)
        viewModel.engine.detectHardwareLenses()
        val lenses = viewModel.engine.availableLenses.value
        val ultraWideLens = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }
        val mainLens = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }

        if (ultraWideLens != null && mainLens != null) {
            // Enable instant switch / keep ultra wide ready
            viewModel.setKeepUltraWideReady(true)
            assertTrue("isKeepUltraWideReady must be enabled", viewModel.engine.isKeepUltraWideReady.value)

            // 1. From 1.0x, tapping 0.5x preset initiates smooth continuous zoom transition down
            viewModel.setZoom(1.0f, isPresetTap = false)
            assertEquals(1.0f, viewModel.currentZoom.value, 0.001f)
            viewModel.setZoom(0.5f, isPresetTap = true)
            assertTrue("Zoom must smoothly transition down towards 0.5x", viewModel.currentZoom.value <= 1.0f && viewModel.currentZoom.value >= 0.5f)
            // Initial handoff at 0.999x must immediately set active stream to ultra wide
            assertEquals(ultraWideLens.id, viewModel.engine.selectedLens.value?.id)

            // 2. From 0.5x, tapping 1.0x preset initiates smooth continuous zoom transition up
            viewModel.engine.selectLens(ultraWideLens)
            viewModel.setZoom(0.5f, isPresetTap = false)
            assertEquals(0.5f, viewModel.currentZoom.value, 0.001f)
            viewModel.setZoom(1.0f, isPresetTap = true)
            assertTrue("Zoom must smoothly transition up towards 1.0x", viewModel.currentZoom.value >= 0.5f && viewModel.currentZoom.value <= 1.0f)
            // While zooming up, stream stays on ultra wide until handoff at 1.0x
            assertEquals(ultraWideLens.id, viewModel.engine.selectedLens.value?.id)

            // 3. Selecting lens via selectLens() also performs smooth transition
            viewModel.setZoom(1.0f, isPresetTap = false)
            viewModel.selectLens(ultraWideLens)
            assertTrue("Selecting ultra-wide must trigger smooth transition down", viewModel.currentZoom.value <= 1.0f && viewModel.currentZoom.value >= 0.5f)

            // 4. Verify engine instant lens switching remains intact
            viewModel.engine.selectLens(mainLens, preserveZoom = false, targetZoom = 1.0f)
            assertEquals(mainLens.id, viewModel.engine.selectedLens.value?.id)
            viewModel.engine.selectLens(ultraWideLens, preserveZoom = false, targetZoom = 0.5f)
            assertEquals(ultraWideLens.id, viewModel.engine.selectedLens.value?.id)
        }
    }

    @Test
    fun testHalfXToTwoXContinuousTransitionTimelineAndPreservedInstantSwitch() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.camera.viewmodel.CameraViewModel(app)
        viewModel.engine.detectHardwareLenses()
        val lenses = viewModel.engine.availableLenses.value
        val ultraWideLens = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }
        val mainLens = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }
        val teleLens = lenses.firstOrNull { it.lensType == LensType.TELEPHOTO && it.isPhysical }

        if (ultraWideLens != null && mainLens != null) {
            viewModel.engine.selectLens(ultraWideLens)
            viewModel.setZoom(0.5f, isPresetTap = false)
            assertEquals(0.5f, viewModel.currentZoom.value, 0.001f)

            // Trigger continuous 0.5x -> 2.0x transition
            viewModel.setZoom(2.0f, isPresetTap = true)
            assertTrue("Zoom must smoothly transition up towards 2.0x", viewModel.currentZoom.value >= 0.5f && viewModel.currentZoom.value <= 2.0f)

            // Direct instant switch remains instant
            viewModel.engine.selectLens(mainLens, preserveZoom = false, targetZoom = 1.0f)
            assertEquals(mainLens.id, viewModel.engine.selectedLens.value?.id)
            viewModel.engine.selectLens(ultraWideLens, preserveZoom = false, targetZoom = 0.5f)
            assertEquals(ultraWideLens.id, viewModel.engine.selectedLens.value?.id)

            // Digital crop on Ultra-Wide extends smoothly past switchZoom during in-flight handoff without freeze
            val cropAt11OnUw = CameraOpticalCalibration.calculateRequiredDigitalCrop(1.1f, 0.5f, LensType.ULTRAWIDE)
            assertTrue(cropAt11OnUw > 1.44f)

            // Resolution during transition targets telephoto when reaching telephoto boundary
            val resolvedAt20 = CameraOpticalCalibration.resolveTargetLensType(
                currentLensType = LensType.WIDE,
                targetZoom = 2.0f,
                hasUltraWide = true,
                hasTelephoto2x = teleLens != null,
                hasTelephoto3x = false,
                isPresetTap = false,
                isContinuousTransition = true
            )
            if (teleLens != null) {
                assertEquals(LensType.TELEPHOTO, resolvedAt20)
            } else {
                assertEquals(LensType.WIDE, resolvedAt20)
            }
        }
    }

    @Test
    fun testContinuousZoomTransitionAcrossOneXBoundaryDoesNotPauseOrClamp() {
        val appContext = ApplicationProvider.getApplicationContext<Context>()
        val engine = Camera2Engine(appContext)
        val lenses = engine.availableLenses.value
        val ultraWideLens = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }
        val mainLens = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }

        if (ultraWideLens != null && mainLens != null) {
            engine.selectLens(ultraWideLens)
            assertEquals(ultraWideLens.id, engine.selectedLens.value?.id)

            // Step through continuous zoom sequence across 1x boundary:
            // .95 -> .97 -> .99 -> 1.00 -> 1.01 -> 1.03
            val zoomSteps = listOf(0.95f, 0.97f, 0.99f, 1.00f, 1.01f, 1.03f)
            for (stepZoom in zoomSteps) {
                engine.setZoom(stepZoom, isPresetTap = false, isContinuousTransition = true)
                assertEquals(stepZoom, engine.currentZoom, 0.001f)
                assertEquals(stepZoom, engine.currentZoomState.value, 0.001f)
            }

            // Target lens should seamlessly handoff to Main Wide at >= 1.0x without holding at 1.0
            assertEquals(mainLens.id, engine.selectedLens.value?.id)
            assertEquals(1.03f, engine.currentZoom, 0.001f)

            // Direct preset switch remains instant
            engine.selectLens(ultraWideLens, preserveZoom = false, targetZoom = 0.5f)
            assertEquals(ultraWideLens.id, engine.selectedLens.value?.id)
            engine.selectLens(mainLens, preserveZoom = false, targetZoom = 1.0f)
            assertEquals(mainLens.id, engine.selectedLens.value?.id)
        }
    }

    @Test
    fun testOpticalCalibrationAtPointNineNineNineMatchesOneXMainCropLimit() {
        // At 0.5x on Ultra-Wide: 1.0x digital crop (full uncropped sensor)
        val cropAt05 = CameraOpticalCalibration.calculateRequiredDigitalCrop(0.5f, 0.5f, LensType.ULTRAWIDE)
        assertEquals(1.0f, cropAt05, 0.001f)

        // At 0.999x on Ultra-Wide: exactly matches 1x Main FOV limit (1.44x crop)
        val cropAt0999 = CameraOpticalCalibration.calculateRequiredDigitalCrop(0.999f, 0.5f, LensType.ULTRAWIDE)
        assertEquals(1.44f, cropAt0999, 0.001f)

        // At 1.000x on Main: 1.0x digital crop (native uncropped 1x Main FOV)
        val cropAt10 = CameraOpticalCalibration.calculateRequiredDigitalCrop(1.0f, 1.0f, LensType.WIDE)
        assertEquals(1.0f, cropAt10, 0.001f)
    }

    @Test
    fun testPhysicalStreamSwitchDoesNotFakeClamping() {
        val physicalUltraWide = LensInfo(
            cameraId = "0",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.ULTRAWIDE,
            displayName = "0.5x Ultra Wide",
            focalLengthMm = 2.0f,
            maxAperture = 2.2f,
            isLogicalMultiCamera = true,
            supportsPhysicalStream = true,
            physicalCameraId = "2",
            baseZoomRatio = 0.5f,
            minZoomRatio = 0.5f
        )

        // Ultra-wide crop calculation at 0.5x must be 1.0x (full native uncropped FOV)
        val crop05 = CameraOpticalCalibration.calculateRequiredDigitalCrop(0.5f, physicalUltraWide.baseZoomRatio, physicalUltraWide.lensType)
        assertEquals(1.0f, crop05, 0.001f)

        // At 0.75x, digital crop is smoothly interpolated
        val crop075 = CameraOpticalCalibration.calculateRequiredDigitalCrop(0.75f, physicalUltraWide.baseZoomRatio, physicalUltraWide.lensType)
        assertTrue(crop075 > 1.0f && crop075 < 1.44f)

        // At 0.999x, digital crop reaches exactly 1.44x matching 1x Main FOV limit
        val crop0999 = CameraOpticalCalibration.calculateRequiredDigitalCrop(0.999f, physicalUltraWide.baseZoomRatio, physicalUltraWide.lensType)
        assertEquals(1.44f, crop0999, 0.001f)
    }

    @Test
    fun testSameCameraDeviceResolvesCorrectStrategy() {
        val mainLens = LensInfo(
            cameraId = "0",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.WIDE,
            displayName = "1x Main",
            focalLengthMm = 5.0f,
            maxAperture = 1.8f,
            isPrimaryMain = true,
            isLogicalMultiCamera = true,
            baseZoomRatio = 1.0f
        )

        val physicalUltraWide = LensInfo(
            cameraId = "0",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.ULTRAWIDE,
            displayName = "0.5x Ultra Wide",
            focalLengthMm = 2.0f,
            maxAperture = 2.2f,
            isLogicalMultiCamera = true,
            supportsPhysicalStream = true,
            physicalCameraId = "2",
            baseZoomRatio = 0.5f
        )

        val logicalZoomLens = LensInfo(
            cameraId = "0",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.WIDE,
            displayName = "2x Zoom Preset",
            focalLengthMm = 5.0f,
            maxAperture = 1.8f,
            isLogicalMultiCamera = true,
            supportsPhysicalStream = false,
            baseZoomRatio = 2.0f
        )

        val strategyPhysical = CameraDiscovery.resolveSwitchStrategy(mainLens, physicalUltraWide)
        assertEquals(LensSwitchStrategy.LOGICAL_PHYSICAL_STREAM, strategyPhysical)

        val strategyLogical = CameraDiscovery.resolveSwitchStrategy(mainLens, logicalZoomLens)
        assertEquals(LensSwitchStrategy.LOGICAL_ZOOM, strategyLogical)
    }

    @Test
    fun testKeepUltraWideReadyDoesNotPrematurelyMarkReadyQuiet() {
        // Toggling Keep Ultra Wide Ready must not jump to READY_QUIET before frames are received
        engine.setKeepUltraWideReady(true)
        val initialStatus = engine.ultraWideStreamStatus.value
        assertNotEquals(
            "Status must not be marked READY_QUIET before actual frames are received",
            com.example.camera.model.BackgroundCameraStatus.READY_QUIET,
            initialStatus
        )
    }

    @Test
    fun testDetectSimultaneousStreamingModeClassification() {
        val mainLens = LensInfo(
            cameraId = "0",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.WIDE,
            displayName = "1x Main",
            focalLengthMm = 5.0f,
            maxAperture = 1.8f,
            isPrimaryMain = true,
            isLogicalMultiCamera = true,
            baseZoomRatio = 1.0f
        )
        val separateUltraWide = LensInfo(
            cameraId = "2",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.ULTRAWIDE,
            displayName = "0.5x Ultra Wide",
            focalLengthMm = 2.0f,
            maxAperture = 2.2f,
            isIndependentCamera = true,
            baseZoomRatio = 0.5f
        )
        val mode = engine.detectSimultaneousStreamingMode(mainLens, separateUltraWide)
        assertNotNull(mode)
    }

    @Test
    fun testSwitchPointDefault23mmAndPersistence() {
        val prefs = com.example.camera.data.CameraPreferences(context)
        assertEquals(23.0f, prefs.lensSwitchPointMm, 0.001f)
        assertEquals(23.0f, engine.lensSwitchPointMm.value, 0.001f)

        engine.setLensSwitchPointMm(32.0f)
        assertEquals(32.0f, engine.lensSwitchPointMm.value, 0.001f)
        assertEquals(32.0f, prefs.lensSwitchPointMm, 0.001f)

        engine.setLensSwitchPointMm(50.0f)
        assertEquals(50.0f, engine.lensSwitchPointMm.value, 0.001f)
        assertEquals(50.0f, prefs.lensSwitchPointMm, 0.001f)

        // Clamping to 23mm..85mm
        engine.setLensSwitchPointMm(15.0f)
        assertEquals(23.0f, engine.lensSwitchPointMm.value, 0.001f)

        engine.setLensSwitchPointMm(100.0f)
        assertEquals(85.0f, engine.lensSwitchPointMm.value, 0.001f)
    }

    @Test
    fun testDynamicSwitchPointCalculatesRequiredDigitalCrops() {
        // Ultra-wide crop = Switch Point ÷ 16mm
        // Main crop = Switch Point ÷ 23mm

        // Default: 23mm (Original)
        assertEquals(1.44f, CameraOpticalCalibration.calculateUltraWideCropForSwitchPoint(23.0f), 0.01f)
        assertEquals(1.00f, CameraOpticalCalibration.calculateMainCropForSwitchPoint(23.0f), 0.01f)

        // Switch Point 32mm -> UW 2.00x, Main 1.39x
        assertEquals(2.00f, CameraOpticalCalibration.calculateUltraWideCropForSwitchPoint(32.0f), 0.01f)
        assertEquals(1.39f, CameraOpticalCalibration.calculateMainCropForSwitchPoint(32.0f), 0.01f)

        // Switch Point 40mm -> UW 2.50x, Main 1.74x
        assertEquals(2.50f, CameraOpticalCalibration.calculateUltraWideCropForSwitchPoint(40.0f), 0.01f)
        assertEquals(1.74f, CameraOpticalCalibration.calculateMainCropForSwitchPoint(40.0f), 0.01f)

        // Switch Point 50mm -> UW 3.13x, Main 2.17x
        assertEquals(3.13f, CameraOpticalCalibration.calculateUltraWideCropForSwitchPoint(50.0f), 0.01f)
        assertEquals(2.17f, CameraOpticalCalibration.calculateMainCropForSwitchPoint(50.0f), 0.01f)

        // Switch Point 85mm -> UW 5.31x, Main 3.70x
        assertEquals(5.31f, CameraOpticalCalibration.calculateUltraWideCropForSwitchPoint(85.0f), 0.01f)
        assertEquals(3.70f, CameraOpticalCalibration.calculateMainCropForSwitchPoint(85.0f), 0.01f)
    }

    @Test
    fun testDynamicLensSwitchAtExactSwitchPointFocalLength() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = com.example.camera.viewmodel.CameraViewModel(app)
        viewModel.engine.detectHardwareLenses()

        // Set Switch Point to 32mm
        viewModel.setLensSwitchPointMm(32.0f)
        assertEquals(32.0f, viewModel.lensSwitchPointMm.value, 0.001f)

        val switchZoom32 = CameraOpticalCalibration.switchPointToZoom(32.0f) // ~1.3913x

        // Below switch point (e.g. 28mm -> ~1.217x): must remain on Ultra-Wide
        val lensBelow32 = CameraOpticalCalibration.resolveTargetLensType(
            currentLensType = LensType.ULTRAWIDE,
            targetZoom = 1.20f,
            hasUltraWide = true,
            hasTelephoto2x = false,
            hasTelephoto3x = false,
            isPresetTap = false,
            switchPointMm = 32.0f
        )
        assertEquals(LensType.ULTRAWIDE, lensBelow32)

        // At exact switch point (~1.3913x): must switch to Main lens (WIDE)
        val lensAt32 = CameraOpticalCalibration.resolveTargetLensType(
            currentLensType = LensType.ULTRAWIDE,
            targetZoom = switchZoom32,
            hasUltraWide = true,
            hasTelephoto2x = false,
            hasTelephoto3x = false,
            isPresetTap = false,
            switchPointMm = 32.0f
        )
        assertEquals(LensType.WIDE, lensAt32)

        // Crop factors at handoff point produce identical effective focal lengths (32mm)
        val uwCropAt32 = CameraOpticalCalibration.calculateRequiredDigitalCrop(
            uiZoom = switchZoom32,
            lensBaseRatio = 0.5f,
            lensType = LensType.ULTRAWIDE,
            switchPointMm = 32.0f
        )
        assertEquals(2.00f, uwCropAt32, 0.01f)
        val effectiveUwFocal = 16.0f * uwCropAt32
        assertEquals(32.0f, effectiveUwFocal, 0.2f)

        val mainCropAt32 = CameraOpticalCalibration.calculateRequiredDigitalCrop(
            uiZoom = switchZoom32,
            lensBaseRatio = 1.0f,
            lensType = LensType.WIDE,
            switchPointMm = 32.0f
        )
        assertEquals(1.39f, mainCropAt32, 0.01f)
        val effectiveMainFocal = 23.0f * mainCropAt32
        assertEquals(32.0f, effectiveMainFocal, 0.2f)
    }

    @Test
    fun testDynamicSwitchPoint50mmHandoffMaintainsContinuity() {
        val switchPoint = 50.0f
        val switchZoom50 = CameraOpticalCalibration.switchPointToZoom(switchPoint) // ~2.1739x

        // At 40mm (zoom ~1.739x): stays on Ultra-Wide
        val targetAt40mm = CameraOpticalCalibration.resolveTargetLensType(
            currentLensType = LensType.ULTRAWIDE,
            targetZoom = 1.70f,
            hasUltraWide = true,
            hasTelephoto2x = false,
            hasTelephoto3x = false,
            isPresetTap = false,
            switchPointMm = switchPoint
        )
        assertEquals(LensType.ULTRAWIDE, targetAt40mm)

        // At exact 50mm switch point (zoom ~2.1739x): switches to Main
        val targetAt50mm = CameraOpticalCalibration.resolveTargetLensType(
            currentLensType = LensType.ULTRAWIDE,
            targetZoom = switchZoom50,
            hasUltraWide = true,
            hasTelephoto2x = false,
            hasTelephoto3x = false,
            isPresetTap = false,
            switchPointMm = switchPoint
        )
        assertEquals(LensType.WIDE, targetAt50mm)

        // Verify UW crop is 3.13x and Main crop is 2.17x
        val uwCrop = CameraOpticalCalibration.calculateRequiredDigitalCrop(
            uiZoom = switchZoom50,
            lensBaseRatio = 0.5f,
            lensType = LensType.ULTRAWIDE,
            switchPointMm = switchPoint
        )
        assertEquals(3.13f, uwCrop, 0.01f)

        val mainCrop = CameraOpticalCalibration.calculateRequiredDigitalCrop(
            uiZoom = switchZoom50,
            lensBaseRatio = 1.0f,
            lensType = LensType.WIDE,
            switchPointMm = switchPoint
        )
        assertEquals(2.17f, mainCrop, 0.01f)
    }

    @Test
    fun testKeepUltraWideReadyPersistentDualSessionInstantSwitchAcrossModes() {
        val mainLens = LensInfo(
            cameraId = "0",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.WIDE,
            displayName = "1x Main",
            focalLengthMm = 5.0f,
            maxAperture = 1.8f,
            isPrimaryMain = true,
            isLogicalMultiCamera = false,
            isIndependentCamera = true,
            baseZoomRatio = 1.0f
        )
        val separateUltraWide = LensInfo(
            cameraId = "2",
            facing = CameraCharacteristics.LENS_FACING_BACK,
            lensType = LensType.ULTRAWIDE,
            displayName = "0.5x Ultra Wide",
            focalLengthMm = 2.0f,
            maxAperture = 2.2f,
            isIndependentCamera = true,
            baseZoomRatio = 0.5f
        )

        // 1. Verify FALLBACK_TURBO is removed and PERSISTENT_DUAL_SESSION or CONCURRENT_DEVICES is used
        val dualMode = engine.detectSimultaneousStreamingMode(mainLens, separateUltraWide)
        assertTrue(
            "Must use CONCURRENT_DEVICES or PERSISTENT_DUAL_SESSION",
            dualMode == Camera2Engine.DualStreamingMode.CONCURRENT_DEVICES ||
                dualMode == Camera2Engine.DualStreamingMode.PERSISTENT_DUAL_SESSION
        )

        // 2. Enable Keep Ultra Wide Ready and verify instant 1x <-> Ultra-Wide switching across Photo, Video, and Cinema (Pro Video) modes
        engine.setKeepUltraWideReady(true)
        assertTrue(engine.isKeepUltraWideReady.value)

        val lenses = engine.availableLenses.value
        val hwMain = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }
        val hwUw = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }

        if (hwMain != null && hwUw != null) {
            for (mode in listOf(
                com.example.camera.model.CameraMode.PHOTO,
                com.example.camera.model.CameraMode.VIDEO,
                com.example.camera.model.CameraMode.CINEMA
            )) {
                engine.setMode(mode)
                engine.exposureCompensationIndex = 2

                // Switch to Main (1x)
                engine.selectLens(hwMain, preserveZoom = false, targetZoom = 1.0f)
                assertEquals(hwMain.id, engine.selectedLens.value?.id)
                assertFalse("Main lens should display MAIN stream", engine.isUsingUltraWideSurface.value)
                assertEquals(PreviewStreamSource.MAIN, engine.displayedPreviewSource.value)
                assertEquals("Exposure compensation must not reset on lens switch", 2, engine.exposureCompensationIndex)

                // Switch 1x -> Ultra-Wide (0.5x) immediately
                engine.selectLens(hwUw, preserveZoom = false, targetZoom = 0.5f)
                assertEquals(hwUw.id, engine.selectedLens.value?.id)
                assertTrue("Ultra-Wide lens should display ULTRAWIDE stream", engine.isUsingUltraWideSurface.value)
                assertEquals(PreviewStreamSource.ULTRAWIDE, engine.displayedPreviewSource.value)
                assertEquals("Exposure compensation must not reset on lens switch", 2, engine.exposureCompensationIndex)

                // Switch Ultra-Wide (0.5x) -> Main (1x) immediately
                engine.selectLens(hwMain, preserveZoom = false, targetZoom = 1.0f)
                assertEquals(hwMain.id, engine.selectedLens.value?.id)
                assertFalse("Switching back to 1x should display MAIN stream", engine.isUsingUltraWideSurface.value)
                assertEquals(PreviewStreamSource.MAIN, engine.displayedPreviewSource.value)
            }
        }
    }

    @Test
    fun testRecordingTimePrewarmedDualSessionInstantSwitchWithoutClosingOrRecreatingSession() {
        engine.detectHardwareLenses()
        val lenses = engine.availableLenses.value
        val hwMain = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }
        val hwUw = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }
        if (hwMain == null || hwUw == null) return

        // Use separate CameraDevice IDs ("0" for Main, "2" for Ultra-Wide)
        val mainLens = hwMain.copy(cameraId = "0", isLogicalMultiCamera = false, isIndependentCamera = true)
        val uwLens = hwUw.copy(cameraId = "2", isLogicalMultiCamera = false, isIndependentCamera = true)

        engine.setKeepUltraWideReady(true)
        engine.setMode(com.example.camera.model.CameraMode.VIDEO)
        engine.selectLens(mainLens, preserveZoom = false, targetZoom = 1.0f)
        engine.exposureCompensationIndex = 3
        engine.isVideoStabilizationEnabled = true
        engine.videoFps = 60
        engine.colorProfile = com.example.camera.model.ColorProfile.NATURAL

        val mainCam = android.hardware.camera2.TestCamera2Factory.TrackingCameraDevice("0")
        val uwCam = android.hardware.camera2.TestCamera2Factory.TrackingCameraDevice("2")
        val mainSess = android.hardware.camera2.TestCamera2Factory.TrackingCaptureSession(mainCam)
        val uwSess = android.hardware.camera2.TestCamera2Factory.TrackingCaptureSession(uwCam)

        val encoderSt = android.graphics.SurfaceTexture(10)
        val encoderSurf = android.view.Surface(encoderSt)
        val relay = DualCameraRecordingRelay(
            encoderTargetSurface = encoderSurf,
            bufferWidth = 1920,
            bufferHeight = 1080,
            fps = 60,
            is10Bit = false,
            initialSource = PreviewStreamSource.MAIN
        )
        val recConfig = Camera2Engine.ActiveRecordingStreamConfig(
            videoResolution = com.example.camera.model.CameraResolution(1920, 1080),
            targetFps = 60,
            fpsRange = android.util.Range(60, 60),
            is10Bit = false,
            dynamicRangeProfile = null,
            isVideoStabilizationEnabled = true,
            videoStabilizationMode = com.example.camera.model.VideoStabilizationMode.EIS,
            isOisAllowed = true,
            orientationHint = 90,
            encoderRotation = 90
        )

        engine.configurePrewarmedDualRecordingStateForTest(
            activeCam = mainCam,
            activeSess = mainSess,
            standbyCam = uwCam,
            standbySess = uwSess,
            relay = relay,
            config = recConfig,
            standbyRecordingReady = true,
            standbyFailed = false
        )

        assertTrue("Recording pipeline must report ready", engine.isStandbyRecordingPipelineReady())
        assertTrue("Video recording must be active", engine.isRecordingVideo.value)

        // 1. Switch Main (1x) -> Ultra-Wide (0.5x) during active video recording
        engine.selectLens(uwLens, preserveZoom = false, targetZoom = 0.5f)

        // Verify sessions were swapped in 0ms without calling stopRepeating() or close()
        assertFalse("Main CameraDevice must NOT be closed during recording lens switch", mainCam.isClosed)
        assertFalse("Ultra-Wide CameraDevice must NOT be closed during recording lens switch", uwCam.isClosed)
        assertFalse("Main CaptureSession must NOT be stopped or closed", mainSess.isStoppedRepeating || mainSess.isClosed)
        assertFalse("Ultra-Wide CaptureSession must NOT be stopped or closed", uwSess.isStoppedRepeating || uwSess.isClosed)
        assertSame("Active CameraDevice must now be Ultra-Wide", uwCam, engine.getActiveCameraDeviceForTest())
        assertSame("Active CaptureSession must now be Ultra-Wide session", uwSess, engine.getActiveCaptureSessionForTest())
        assertSame("Standby CameraDevice must now be Main", mainCam, engine.getStandbyCameraDeviceForTest())
        assertSame("Standby CaptureSession must now be Main session", mainSess, engine.getStandbyCaptureSessionForTest())
        assertEquals("Relay active source must switch to ULTRAWIDE", PreviewStreamSource.ULTRAWIDE, relay.activeSource)
        assertEquals("Displayed preview source must be ULTRAWIDE", PreviewStreamSource.ULTRAWIDE, engine.displayedPreviewSource.value)
        assertTrue("isUsingUltraWideSurface must be true", engine.isUsingUltraWideSurface.value)
        assertSame("Active recording surface must switch to UW recorder surface", relay.ultraWideRecorderSurface, engine.getActiveRecordingSurfaceForTest())
        assertTrue("Recording must remain continuously active", engine.isRecordingVideo.value)
        assertEquals("Exposure compensation must be preserved", 3, engine.exposureCompensationIndex)
        assertEquals("FPS setting must be preserved", 60, engine.videoFps)
        assertEquals("Color profile must be preserved", com.example.camera.model.ColorProfile.NATURAL, engine.colorProfile)
        assertTrue("Stabilization must be preserved", engine.isVideoStabilizationEnabled)

        // 2. Switch Ultra-Wide (0.5x) -> Main (1x) during active video recording
        engine.selectLens(mainLens, preserveZoom = false, targetZoom = 1.0f)

        assertFalse("Main CameraDevice must still NOT be closed", mainCam.isClosed)
        assertFalse("Ultra-Wide CameraDevice must still NOT be closed", uwCam.isClosed)
        assertFalse("Main CaptureSession must still NOT be stopped or closed", mainSess.isStoppedRepeating || mainSess.isClosed)
        assertFalse("Ultra-Wide CaptureSession must still NOT be stopped or closed", uwSess.isStoppedRepeating || uwSess.isClosed)
        assertSame("Active CameraDevice must be back to Main", mainCam, engine.getActiveCameraDeviceForTest())
        assertSame("Active CaptureSession must be back to Main session", mainSess, engine.getActiveCaptureSessionForTest())
        assertSame("Standby CameraDevice must be back to Ultra-Wide", uwCam, engine.getStandbyCameraDeviceForTest())
        assertSame("Standby CaptureSession must be back to Ultra-Wide session", uwSess, engine.getStandbyCaptureSessionForTest())
        assertEquals("Relay active source must switch back to MAIN", PreviewStreamSource.MAIN, relay.activeSource)
        assertEquals("Displayed preview source must be back to MAIN", PreviewStreamSource.MAIN, engine.displayedPreviewSource.value)
        assertFalse("isUsingUltraWideSurface must be false", engine.isUsingUltraWideSurface.value)
        assertSame("Active recording surface must switch back to Main recorder surface", relay.mainRecorderSurface, engine.getActiveRecordingSurfaceForTest())
        assertTrue("Recording must remain continuously active", engine.isRecordingVideo.value)

        relay.release()
        encoderSurf.release()
        encoderSt.release()
    }

    @Test
    fun testRecordingTimeLogicalPhysicalMultiCameraInstantSwitchWithoutReconfiguringSession() {
        engine.detectHardwareLenses()
        val lenses = engine.availableLenses.value
        val hwMain = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }
        val hwUw = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }
        if (hwMain == null || hwUw == null) return

        // Both lenses share logical CameraDevice "0" with physical IDs "0" and "2"
        val mainLens = hwMain.copy(
            cameraId = "0",
            isLogicalMultiCamera = true,
            supportsPhysicalStream = true,
            physicalCameraId = "0",
            isIndependentCamera = false
        )
        val uwLens = hwUw.copy(
            cameraId = "0",
            isLogicalMultiCamera = true,
            supportsPhysicalStream = true,
            physicalCameraId = "2",
            isIndependentCamera = false
        )

        engine.setKeepUltraWideReady(true)
        engine.setMode(com.example.camera.model.CameraMode.VIDEO)
        engine.selectLens(mainLens, preserveZoom = false, targetZoom = 1.0f)

        val logicalCam = android.hardware.camera2.TestCamera2Factory.TrackingCameraDevice("0")
        val logicalSess = android.hardware.camera2.TestCamera2Factory.TrackingCaptureSession(logicalCam)

        val encoderSt = android.graphics.SurfaceTexture(11)
        val encoderSurf = android.view.Surface(encoderSt)
        val relay = DualCameraRecordingRelay(
            encoderTargetSurface = encoderSurf,
            bufferWidth = 1920,
            bufferHeight = 1080,
            fps = 30,
            is10Bit = false,
            initialSource = PreviewStreamSource.MAIN
        )
        val recConfig = Camera2Engine.ActiveRecordingStreamConfig(
            videoResolution = com.example.camera.model.CameraResolution(1920, 1080),
            targetFps = 30,
            fpsRange = android.util.Range(30, 30),
            is10Bit = false,
            dynamicRangeProfile = null,
            isVideoStabilizationEnabled = true,
            videoStabilizationMode = com.example.camera.model.VideoStabilizationMode.EIS,
            isOisAllowed = true,
            orientationHint = 90,
            encoderRotation = 90
        )

        engine.configureLogicalPhysicalRecordingStateForTest(
            logicalCam = logicalCam,
            logicalSess = logicalSess,
            relay = relay,
            config = recConfig,
            logicalDualReady = true,
            logicalFailed = false
        )

        assertTrue("Logical physical recording pipeline must report ready", engine.isStandbyRecordingPipelineReady())

        // Switch Main -> Ultra-Wide on same logical session
        engine.selectLens(uwLens, preserveZoom = false, targetZoom = 0.5f)
        assertFalse("Logical CameraDevice must NOT be closed", logicalCam.isClosed)
        assertFalse("Logical session must NOT be stopped or closed", logicalSess.isStoppedRepeating || logicalSess.isClosed)
        assertSame("Same logical session must remain active", logicalSess, engine.getActiveCaptureSessionForTest())
        assertEquals("2", engine.getActivePhysicalCameraIdForTest())
        assertEquals(PreviewStreamSource.ULTRAWIDE, relay.activeSource)
        assertEquals(PreviewStreamSource.ULTRAWIDE, engine.displayedPreviewSource.value)
        assertTrue(engine.isUsingUltraWideSurface.value)

        // Switch Ultra-Wide -> Main on same logical session
        engine.selectLens(mainLens, preserveZoom = false, targetZoom = 1.0f)
        assertFalse("Logical CameraDevice must still NOT be closed", logicalCam.isClosed)
        assertFalse("Logical session must still NOT be stopped or closed", logicalSess.isStoppedRepeating || logicalSess.isClosed)
        assertSame("Same logical session must remain active", logicalSess, engine.getActiveCaptureSessionForTest())
        assertEquals(PreviewStreamSource.MAIN, relay.activeSource)
        assertEquals(PreviewStreamSource.MAIN, engine.displayedPreviewSource.value)
        assertFalse(engine.isUsingUltraWideSurface.value)

        relay.release()
        encoderSurf.release()
        encoderSt.release()
    }

    @Test
    fun testMainStandbyStreamPrewarmedWithConfiguredSwitchPointCrop() {
        engine.detectHardwareLenses()
        val lenses = engine.availableLenses.value
        val mainLens = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }
        val ultraWideLens = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }
        assertNotNull("Main lens should be detected", mainLens)

        // 1. Verify calculateStandbyCropRatio correctly prewarms Main standby stream for all switch points
        engine.setLensSwitchPointMm(23.0f)
        assertEquals(1.00f, engine.calculateStandbyCropRatio(mainLens!!), 0.01f)

        engine.setLensSwitchPointMm(32.0f)
        assertEquals(1.39f, engine.calculateStandbyCropRatio(mainLens), 0.01f)

        engine.setLensSwitchPointMm(40.0f)
        assertEquals(1.74f, engine.calculateStandbyCropRatio(mainLens), 0.01f)

        engine.setLensSwitchPointMm(50.0f)
        assertEquals(2.17f, engine.calculateStandbyCropRatio(mainLens), 0.01f)

        engine.setLensSwitchPointMm(85.0f)
        assertEquals(3.70f, engine.calculateStandbyCropRatio(mainLens), 0.01f)

        if (ultraWideLens != null) {
            engine.setLensSwitchPointMm(23.0f)
            assertEquals(1.44f, engine.calculateStandbyCropRatio(ultraWideLens), 0.01f)

            engine.setLensSwitchPointMm(40.0f)
            assertEquals(2.50f, engine.calculateStandbyCropRatio(ultraWideLens), 0.01f)
        }

        // 2. Verify CaptureRequest builder has prewarmed crop applied
        val constructor = CaptureRequest.Builder::class.java.getDeclaredConstructor()
        constructor.isAccessible = true

        val chars = engine.getCharacteristics(mainLens.cameraId)
        val sensorRect = chars?.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: Rect(0, 0, 4000, 3000)

        // Switch point 23mm -> 1.00x crop
        engine.setLensSwitchPointMm(23.0f)
        val builder23 = constructor.newInstance()
        engine.applySynchronizedStandbySettingsForTest(builder23, mainLens)
        val cropRegion23 = builder23.get(CaptureRequest.SCALER_CROP_REGION)
        assertNotNull("Crop region should be set on builder", cropRegion23)
        assertEquals("At 23mm, Main standby crop matches full sensor width (1.0x)", sensorRect.width(), cropRegion23!!.width())

        // Switch point 40mm -> ~1.74x crop (~40/23 = 1.739x)
        engine.setLensSwitchPointMm(40.0f)
        val builder40 = constructor.newInstance()
        engine.applySynchronizedStandbySettingsForTest(builder40, mainLens)
        val cropRegion40 = builder40.get(CaptureRequest.SCALER_CROP_REGION)
        assertNotNull("Crop region should be set for 40mm", cropRegion40)
        val expectedWidth40 = (sensorRect.width() / 1.74f).toInt()
        assertEquals(
            "At 40mm switch point, Main standby stream must be prewarmed with 1.74x crop",
            expectedWidth40.toDouble(),
            cropRegion40!!.width().toDouble(),
            2.0
        )

        // Switch point 32mm -> 1.39x crop
        engine.setLensSwitchPointMm(32.0f)
        val builder32 = constructor.newInstance()
        engine.applySynchronizedStandbySettingsForTest(builder32, mainLens)
        val cropRegion32 = builder32.get(CaptureRequest.SCALER_CROP_REGION)
        val expectedWidth32 = (sensorRect.width() / 1.39f).toInt()
        assertEquals(
            "At 32mm switch point, Main standby stream must be prewarmed with 1.39x crop",
            expectedWidth32.toDouble(),
            cropRegion32!!.width().toDouble(),
            2.0
        )

        // Switch point 50mm -> 2.17x crop
        engine.setLensSwitchPointMm(50.0f)
        val builder50 = constructor.newInstance()
        engine.applySynchronizedStandbySettingsForTest(builder50, mainLens)
        val cropRegion50 = builder50.get(CaptureRequest.SCALER_CROP_REGION)
        val expectedWidth50 = (sensorRect.width() / 2.17f).toInt()
        assertEquals(
            "At 50mm switch point, Main standby stream must be prewarmed with 2.17x crop",
            expectedWidth50.toDouble(),
            cropRegion50!!.width().toDouble(),
            2.0
        )

        // Ultra-Wide standby stream at 40mm switch point -> 2.50x crop
        if (ultraWideLens != null) {
            engine.setLensSwitchPointMm(40.0f)
            val uwChars = engine.getCharacteristics(ultraWideLens.cameraId)
            val uwSensorRect = uwChars?.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: Rect(0, 0, 4000, 3000)
            val builderUw40 = constructor.newInstance()
            engine.applySynchronizedStandbySettingsForTest(builderUw40, ultraWideLens)
            val cropUw40 = builderUw40.get(CaptureRequest.SCALER_CROP_REGION)
            assertNotNull(cropUw40)
            val expectedUwWidth = (uwSensorRect.width() / 2.50f).toInt()
            assertEquals(
                "Ultra-Wide standby stream at 40mm switch point must be prewarmed with 2.50x crop",
                expectedUwWidth.toDouble(),
                cropUw40!!.width().toDouble(),
                2.0
            )
        }
    }

    @Test
    fun test4KVideoResolutionAndFpsPreservedAcrossUltraWideCapabilityRefreshAndStandbySwitch() {
        engine.detectHardwareLenses()
        val lenses = engine.availableLenses.value
        val hwMain = lenses.firstOrNull { it.isPrimaryMain } ?: lenses.firstOrNull { it.lensType == LensType.WIDE }
        val hwUw = lenses.firstOrNull { it.lensType == LensType.ULTRAWIDE }
        if (hwMain == null || hwUw == null) return

        val mainLens = hwMain.copy(cameraId = "0", isLogicalMultiCamera = false, isIndependentCamera = true)
        val uwLens = hwUw.copy(cameraId = "2", isLogicalMultiCamera = false, isIndependentCamera = true)

        val res4K = com.example.camera.model.CameraResolution(3840, 2160)
        engine.setKeepUltraWideReady(true)
        engine.setMode(com.example.camera.model.CameraMode.VIDEO)
        engine.selectVideoResolution(res4K)
        engine.videoFps = 60

        assertEquals(res4K, engine.selectedVideoResolution.value)
        assertEquals(60, engine.videoFps)

        // Inspecting Ultra-Wide capabilities (which only supports up to 1080p in default test characteristics)
        // must never silently reset the user's selected 4K video resolution or FPS.
        engine.inspectCapabilities(uwLens.cameraId)
        assertEquals(
            "Selected 4K video resolution must not be reset to 1080p by inspectCapabilities()",
            res4K,
            engine.selectedVideoResolution.value
        )
        assertEquals("Selected FPS must be preserved", 60, engine.videoFps)

        // Switching Main -> Ultra-Wide -> Main via prewarmed standby during recording must preserve 4K and FPS
        val mainCam = android.hardware.camera2.TestCamera2Factory.TrackingCameraDevice("0")
        val uwCam = android.hardware.camera2.TestCamera2Factory.TrackingCameraDevice("2")
        val mainSess = android.hardware.camera2.TestCamera2Factory.TrackingCaptureSession(mainCam)
        val uwSess = android.hardware.camera2.TestCamera2Factory.TrackingCaptureSession(uwCam)

        val encoderSt = android.graphics.SurfaceTexture(12)
        val encoderSurf = android.view.Surface(encoderSt)
        val relay = DualCameraRecordingRelay(
            encoderTargetSurface = encoderSurf,
            bufferWidth = 3840,
            bufferHeight = 2160,
            fps = 60,
            is10Bit = false,
            initialSource = PreviewStreamSource.MAIN
        )
        val recConfig = Camera2Engine.ActiveRecordingStreamConfig(
            videoResolution = res4K,
            targetFps = 60,
            fpsRange = android.util.Range(60, 60),
            is10Bit = false,
            dynamicRangeProfile = null,
            isVideoStabilizationEnabled = true,
            videoStabilizationMode = com.example.camera.model.VideoStabilizationMode.EIS,
            isOisAllowed = true,
            orientationHint = 90,
            encoderRotation = 90
        )

        engine.configurePrewarmedDualRecordingStateForTest(
            activeCam = mainCam,
            activeSess = mainSess,
            standbyCam = uwCam,
            standbySess = uwSess,
            relay = relay,
            config = recConfig,
            standbyRecordingReady = true,
            standbyFailed = false
        )

        engine.selectLens(uwLens, preserveZoom = false, targetZoom = 0.5f)
        assertEquals("Selected 4K resolution must remain 3840x2160 on Ultra-Wide switch", res4K, engine.selectedVideoResolution.value)
        assertEquals("Selected FPS must remain 60 on Ultra-Wide switch", 60, engine.videoFps)
        assertEquals("Active recording stream config must remain 4K", res4K, engine.getActiveRecordingStreamConfigForTest()?.videoResolution)

        engine.selectLens(mainLens, preserveZoom = false, targetZoom = 1.0f)
        assertEquals("Selected 4K resolution must remain 3840x2160 on return to Main", res4K, engine.selectedVideoResolution.value)
        assertEquals("Selected FPS must remain 60 on return to Main", 60, engine.videoFps)

        relay.release()
        encoderSurf.release()
        encoderSt.release()
    }
}

